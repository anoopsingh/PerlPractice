use ATS;
use Data::Dumper;
$ENV{TERM}= "DUMP";
my $ssh = Genband::SBC->new(
                                                -obj_host => "172.23.58.6",
                                                -obj_user => 'root',
                                                -obj_password => 'shipped!!',
                                                -comm_type => "SSH", -sessionlog => 1, -obj_hostname => "NXTEST6");


$ssh->execShellCmd("mkdir -p /home/test/resultDirectory");
$ssh->execShellCmd("chown -R test:users /home/test/resultDirectory");


print Dumper($ssh);
