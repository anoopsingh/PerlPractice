use MIME::Entity;

my $content = '<table border="1" align="center"><tr>';
$content .= '<th>Test Case</th><th>Result</th></tr>';
$content .= "</table>";
print "$content\n";
&sendMail(-mailId => 'Ramesh.Pateel@genband.com', -status => 'Test', -externalBody => $content);

sub sendMail {
    my %args = @_;
    my $sub_name = 'sendMail()';

    my $data = "Hi,<br/></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thanks for using genSmart<br/></br>";
    
    $data .= $args{-externalBody} if (defined $args{-externalBody});
    
    $data .= "<br/></br>Path Regression execution logs - $args{-nxtestLog}<br/></br>" if (defined $args{-nxtestLog});
    
    $data .= "<br/></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: This is an auto generated mail from genSMART(Genband Scheduler Manager for Automated Regression Testing). Please do not reply. For queries contact Ramesh.Pateel\@genabnd.com (or) Anoop.Kumar\@globallogic.com";
    
    my $mail = MIME::Entity->build(
                Type    => "text/html charset=\"iso-8859-1\"",
                To      => "$args{-mailId}",
                Cc      => 'ramesh.pateel@genband.com',
                From    => 'gensmart@genband.com',
                Subject => "Regression execution - $args{-status}",
                Data    => $data,
    );

    $mail->attach( Path        => "/tmp/summary.xls", Type        => "application/vnd.ms-excel" );
    open MAIL, "| /usr/sbin/sendmail -t -i" or die "open: $!";
    $mail->print(\*MAIL);
    close MAIL;
    return 1;
}
