use ATS;

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["sbc13", "sbc14"], -sessionlog =>1);

print $obj->verifyLicense() . "\n";
