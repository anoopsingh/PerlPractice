use ATS;
use Data::Dumper;
$ENV{TERM}= "DUMP";
my $ssh = Genband::SIPP->new(
                                                -obj_host => "172.23.59.71",
                                                -obj_user => 'root',
                                                -obj_password => 'shipped!!',
                                                -comm_type => "SSH");

#my @result = $ssh->{conn}->cmd('sudo /opt/nextest/bin/sipp -sn uas -bg');
Genband::Base::forcedDestroy();

$ssh->{conn}->cmd('ls');

