use Genband::ATSHELPER;
use Data::Dumper;

my @TESTBED = ( [BL-S1R6-SBC31, BL-E2R1-SBC33] );


my %testbed = Genband::ATSHELPER::resolveHashFromAliasArray( -input_array  => \@TESTBED );

print Dumper(\%testbed);
