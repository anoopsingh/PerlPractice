use ATS;
use Data::Dumper;

#my @any = ('183_to_180_conversion','adaptive_fax_routing','advancedTrunkGroupRouting','allowdestarqall','alternate_gk','ani_dnis_loopdetection','bt_feature','call_routing','causecode','causecode_2','cdr','cg_cd_party','codecFiltering','codecProfile','codeMappingReasonText','default_ptime','diversion_header','domain_based_routing','dropCall_Invalid_DNIS','dynamicCallHunting','e164_numbering','ec911','ep_isdn_local','extended_header_manipulation_80','functional','gw_selection','h225messages','h245messages','h323registration','handling_forked_request','host_manipulation','hunt_isdn_cc_global','hunting_within_cp','ibasis_enhancement','in-egress-maxcalls','info_based_reachability','interim_cdr_enhancement','last_reg_time','kopt_configurable_sessid_verid','kopt_paid_header_manipulation_fmm','kopt_split_sip_header','leadingplusremoval','maddr','mastergk','media_interrealm','media_intrarealm','media_routing','negative_protos','negative_sip_torture','negative_sipcallflow','no_source_address','obpxfactor','out_of_dialogue_sip_option_message','outgoing_prefix','outofband-dtmf','perf','pilot_number_registration','policing_indicator','priority_route_precedence','privacy_enhancements','privacy_iw','q931','qos','ratelimiting_callgapping','ratelimiting_firewall','rba','rcse_header_manipulation','rdn_diversion_iwf','reason_header','reject_route','restricted_ani','rogue-rtp','routing_hunting_options','sdp_offer_answer','sdp_pass_thru','sip_options','sipi_peerless','sip_port_mapping','sip_prack','sip_update','sip3xxRelay','sipi_sipt_80','sipt','source_lookup','src_port_selection','sticky_route','subnet_cac','surrogate_registration','system_security','tcs_rfc_2833','tcst38_fax','tel_uri','tel_uri_rcse','timerc','to_based_routing','trunkgroup','zone','nexunit_130846','nexunit_59562','nexunit_addcodec','nexunit_pheader','nexunit_relay3xx','nexunit_rsmips',
my @any = ('detect_endpoint_availability','multiple_DNS','out_of_dialogue_sip_option_message','phonecontext','reg_event_support','sdp_manipulation','sip_session_timer'); 

#my @real = ('path_route_based_routing','nexunit_maddr','nexunit_pathheader','nexunit_relay_in_call_subscribe','nexunit_serviceroute','nexunit_sip_stack','nexunit_siptxn_tie_up','im_presence','tls','cdr_start_stop','ciscoGTD','h323_radius','number_manipulation','privacy_manipulation','rad_accounting','radius','radius_pod','radius_prepaid','radius_x_route','sip_trans','tcp','x_route_tag','nexunit_aaa','3xx','ayt_info_msg','dtmf_tone_generation','enum','functional_basic','gare','history_info','invite_based_reachability','media_cac','media_inactivity_timer','mirrorproxy','multiple_sip_ports','nat','nat_enhancements','obp','pem_removal_183_to_180_conversion','ptime_removal','rmaip','sanity','sip_local_refer','snmp','msud');

my %suiteType = ();
map {$suiteType{$_ . '.qms'} = 'Any'} @any;
#map {$suiteType{$_ . '.qms'} = 'Real'} @real;

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN71"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/production_components.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep --color=never -v "dsp.qms" | grep --color=never  "scm.qms"');

chomp @result;

my %data = ();
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);

    my $name =  join('-', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = 'production_components.qms/' . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    next if (defined $suiteType{$temp[0]});
    $data{$name}{type} = 'Real';
    
    print "$data{$name}{type}==\n";
}

#print Dumper(\%data);

my $tTests = 0;
my $anyTest = 0;

foreach my $suiteName (keys %data) {
    next unless (defined $data{$suiteName}{type});
    my $suiteId = &getUUID();
    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.3.0,V8.3.1,V8.3.2', 'sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'SMOKE', '$data{$suiteName}{path}')\n";

    print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.1.1,V8.2.1,V8.3.0,V8.3.1,V8.3.2,V8.4.0,V9.0.0', 'annapolis,jarell,sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'FULL', '$data{$suiteName}{path}', 'NONSCM', '$data{$suiteName}{type}')\n";

    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.1.1,V8.2.1,V8.3.0,V8.3.1,V8.3.2,V8.4.0,V9.0.0,V9.1.0', 'annapolis,jarell,sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'FULL', '$data{$suiteName}{path}', 'SCM', '$data{$suiteName}{type}')");
    
    #print "INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')\n";
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    
    $anyTest += scalar(@{$data{$suiteName}{tests}}) if ($data{$suiteName}{type} eq 'Real');
    $tTests += scalar(@{$data{$suiteName}{tests}});
#    sleep(1); 
}

print "$anyTest = $tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
