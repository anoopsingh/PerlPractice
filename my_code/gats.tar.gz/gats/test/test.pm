package test;


our @t = (1,2,3);

1;
