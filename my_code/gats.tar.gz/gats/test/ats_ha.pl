use ATS;
our %TESTBED;
use Genband::PERF::PerfUtils;
use Data::Dumper;
#$ENV{'TERM'} = 'DUMP';
my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ['BL-S1R6-SBC31','BL-E2R1-SBC33'], -sessionlog =>1);


#print Dumper($obj);


#unless (Genband::PERF::PerfUtils::bulkConfig($obj, 'Realms:3,Calling Routes:10,Calling Plans:10,Vnets:2,End Points:32')) {
#	print "failed-------------\n";


#}

=pod

my @TESTBED = ( [sbc32, sbc34], NXTEST21);


%TESTBED = Genband::ATSHELPER::resolveHashFromAliasArray( -input_array  => \@TESTBED ); 
my $profileData = &Genband::PERF::PerfUtils::loadXMLData("/gats/perf/test/88489_granite-tc-15-dev/profile.xml"); 


my @clients = ();
foreach my $i (0..($profileData->{clients} - 1)) {
   $clients[$i] = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{$profileData->{"client" . ($i+1)}}, -sessionlog =>1);
    
}

my %rfactor = Genband::PERF::PerfUtils::getCdrAndRfactor($obj,  ( -profile => $profileData, -clients => \@clients));



Genband::PERF::PerfUtils::generateReport(%rfactor, -profile => $profileData, -log_dir => '/gats/perf/logs/rpateel/88489/20131104-174531', -webDir => '/gats/test/', -testId => 88489, -testName => 'granite-tc-15-dev', -callHoldTime => 80000, -callDuration => 600);

my @cmdOut = $obj->execCmd("cdr.pl -t /var/cdrs/D20131029.CDT");

print Dumper(\@cmdOut);

my %result = ();
foreach (@cmdOut) {
	chomp $_;
	next if ($_ =~ /time/i);
    my @temp = split(/\s+/, $_);
    $result{max_call} = $temp[1] if ( not defined $result{max_call} or ($result{max_call} < $temp[1]));
    $result{max_cps} = $temp[2] if ( not defined $result{max_cps} or ($result{max_cps} < $temp[2]));
}

print Dumper(\%result);


#print $obj->validateCmdOutput( -cmd =>"lstat" , -pattern => ['Used Media Routed VPORTS\s*(3|4)0\d\d'] );

# print $obj->{STANDBY}->promptConfirmExecCmd(-cmd => 'nxconfig.pl -m /root/mdevices.xml',
#                                        -prompts => ['Please enter the hostname for mdevices.xml.*:', '(y/n).*:', 'iServer restart (y/n).*:'],
#                                        -confirm => ['','y','y']);
#print $obj->sbcInit(-skipLicence => 1);
