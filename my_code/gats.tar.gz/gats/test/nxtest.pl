use ATS;
use Data::Dumper;
use Genband::SBC;

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => "NXTEST6", -sessionlog =>1);

print Dumper($obj);
