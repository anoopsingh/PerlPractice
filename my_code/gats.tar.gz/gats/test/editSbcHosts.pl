use ATS;
use Data::Dumper;

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-SQAR1-SBC2"], -sessionlog =>1);

unless ($obj->execLinuxCmd('grep -w "hk" /etc/hosts')) {
	print "hk Not found\n";
       $obj->execLinuxCmd('echo "169.254.0.2     hk" >>/etc/hosts');
}


