use Genband::Utils;
use Data::Dumper;

my $a = &dbCmd('select * from loadJob');

print Dumper($a);

sub dbCmd{
    my($query) = @_;
    my($databaseConn);

    unless(defined($query)){
        print "dbCmd QUERY ARGUMENT WAS LEFT EMPTY";
        return 0;
    }
    if($query=~ m/SELECT/i){unless($databaseConn=Genband::Utils::db_connect('RODATABASE')){
        print "ERROR IN CONNECTING TO READ DB!";
        return 0;
    }}
    else{unless($databaseConn=Genband::Utils::db_connect('DATABASE')){
        print "ERROR IN CONNECTING TO WRITE DB!";
        return 0;
    }}
	
    my ($queryHandler,$key, $value,$row, $arrayref);
    eval{
        $queryHandler = $databaseConn->prepare($query);
        $queryHandler->execute();
    };
    if($@){
        print "DB ERROR: ".$queryHandler->{Statement};
        return 0;
    }
	
    print "Database Query: $query\n";
    if($query=~ m/SELECT/i){
        $arrayref = $queryHandler->fetchall_arrayref();
    }
    
    $databaseConn->disconnect();
    $databaseConn=undef;
	  
    return $arrayref;
}
