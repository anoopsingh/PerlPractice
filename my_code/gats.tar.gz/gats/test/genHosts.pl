use ATS;
use Data::Dumper;

my $gen = Genband::ATSHELPER::newFromAlias(-testbed_alias => ['BL-S1R6-VMGEN75'], -sessionlog =>1);


#my $scpCmd = "scp /etc/hosts root\@172.23.54.205:/tmp/";

#$gen->scpFile( -scpCmd => $scpCmd,  -password => 'shipped!!');

my $sbc = Genband::ATSHELPER::newFromAlias(-testbed_alias => ['BL-E2R1-SBC9','BL-E2R1-SBC10'], -sessionlog =>1);

print Dumper($sbc);

$gen->execLinuxCmd('hostname');
my $hostname = $gen->{CMDRESULTS}->[0];
my ($eth2, $eth3) = ($gen->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}, $gen->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP});

my ($eth2Nw, $eth3Nw) = ($eth2, $eth3);
$eth2Nw =~ s/(.+)\..+?$/$1/;
$eth3Nw =~ s/(.+)\..+?$/$1/;
my $mgmtNw = $gen->{TESTBED_ALIAS_DATA}->{MGMT}->{1}->{IP};
$mgmtNw =~ s/(.+)\..+?$/$1/;

open(my $hosts, '>hosts');

my $content = '############ Auto Generated ############
#
#
# hosts         This file describes a number of hostname-to-address
#               mappings for the TCP/IP subsystem.  It is mostly
#               used at boot time, when no name servers are running.
#               On small systems, this file can be used instead of a
#               "named" name server.
# Syntax:
#    
# IP-Address  Full-Qualified-Hostname  Short-Hostname
#
 
127.0.0.1       localhost
 
# special IPv6 addresses
::1             localhost ipv6-localhost ipv6-loopback
 
fe00::0         ipv6-localnet
 
ff00::0         ipv6-mcastprefix
ff02::1         ipv6-allnodes
ff02::2         ipv6-allrouters
ff02::3         ipv6-allhosts
169.254.0.1     hhn
169.254.0.2     hk

';

$content .= $sbc->{TESTBED_ALIAS_DATA}->{MGMT}->{1}->{IP} ."\tmymsw\n";
$content .= $sbc->{STANDBY}->{OBJ_HOSTS}->[0] ."\tbkupmsw\n" if (defined $sbc->{STANDBY});
$content .= $gen->{TESTBED_ALIAS_DATA}->{MGMT}->{1}->{IP} ."\tmygen $hostname\n\n\n";

$content .= "${eth2Nw}.101     pub_rsa staticrealm pub_test.com
${eth3Nw}.101     prv_rsa dynamic_realm qanextest.com qanextest.com.
${eth2Nw}.7       rh_realm_c enum_realm
${eth3Nw}.8       rh_realm_psx
##Proxy realm entry
${eth3Nw}.110     proxy_realm
##
 
# Public addresses
${eth2Nw}.119     public1 ps1.abc.com
${eth2Nw}.112     public2
${eth2Nw}.113     public3 tr_sip_ep1
${eth2Nw}.114     public4
${eth2Nw}.115     public5
${eth2Nw}.116     public6
${eth2Nw}.117     public7
${eth2Nw}.118     public8 ast_sipproxy sipproxy.e164.com openser
${eth2Nw}.129     public9
${eth2Nw}.18      public10
${eth2Nw}.11      public11
${eth2Nw}.12      public12
${eth2Nw}.13      public13
${eth2Nw}.14      public14
${eth2Nw}.15      public15
${eth2Nw}.16      public16 nxgenIP4
${eth2Nw}.17      public17 nxgenIP1
 
${eth2Nw}.20      chicago
${eth2Nw}.21      seattle
${eth2Nw}.22      portland
${eth2Nw}.23      newyork
${eth2Nw}.24      boston
${eth2Nw}.25      maryland
 
# Private addresses
${eth3Nw}.127     private1
${eth3Nw}.112     private2
${eth3Nw}.113     private3 tr_sip_ep2
${eth3Nw}.114     private4
${eth3Nw}.115     private5
${eth3Nw}.116     private6
${eth3Nw}.117     private7
${eth3Nw}.118     private8
${eth3Nw}.119     private9
${eth3Nw}.18      private10
${eth3Nw}.11      private11
${eth3Nw}.12      private12
${eth3Nw}.3       private13
${eth3Nw}.14      private14
${eth3Nw}.15      private15
${eth3Nw}.16      private16 nxgenIP3
${eth3Nw}.17      private17 nxgenIP2
 
 
${eth3Nw}.20      sandiego
${eth3Nw}.21      phoenix
${eth3Nw}.22      atlanta
${eth3Nw}.23      miami
${eth3Nw}.24      london
${eth3Nw}.25      texas
 
#CODENOMICON
${eth2Nw}.28      codenomicon1
${eth2Nw}.29      codenomicon2
${eth2Nw}.30      codenomicon3
${eth2Nw}.31      codenomicon4
 
# CLIENT AND SERVER
${eth3Nw}.30      client
${eth3Nw}.31      server
 
# IP ADDRESSES USED BY GNUGK, NXGEN (FOR MEDIA) AND SER
${eth2Nw}.32      gatekeeper1
${eth3Nw}.32      gatekeeper2
${eth2Nw}.34      sipproxy proxy.e164.com
#IP ADDRESSES USED BY SER for 8.3 OBP scenarios
${eth2Nw}.38       sipproxy2 

# nxgenIP1, nxgenIP2 and nxgenIP3 are defined above
 
# IP ADDRESSES USED BY RADIUS SERVER
${mgmtNw}.221  radiusprimary
${mgmtNw}.222  radiussecondary
${mgmtNw}.223  radiusthird
${mgmtNw}.224  radiusfourth
${mgmtNw}.225  radiusfifth radiusfifthbackup
${mgmtNw}.226  radiussixth
${mgmtNw}.227  radiusfirst
${mgmtNw}.228  radiussecond
 
 
# IP ADDRESSES USED BY NAT - NOT TO BE CHANGED
192.168.0.100   nat_public1
192.168.0.101   nat_public2
192.168.2.100   nat_public3
192.168.1.100   nat_private1
192.168.1.101   nat_private2
192.168.3.100   nat_private3
192.168.4.100   nat_private4
 
# IP ADDRESSES USED BY NAT - SHOULD BE UNIQUE
${eth2Nw}.26      pub_nat
${eth2Nw}.27      pub_nat1
${eth2Nw}.40      pub_nat2
${eth3Nw}.26      prv_nat
${eth3Nw}.65      prv_nat1
${eth3Nw}.66      prv_nat2

# MAIL PARAMETER
192.168.15.37   mail.nextone.com
$eth2       eth2
$eth3       eth3\n";

print $hosts $content;
close $hosts ;
