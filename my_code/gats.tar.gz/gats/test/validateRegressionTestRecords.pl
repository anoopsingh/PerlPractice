use ATS;
use Data::Dumper;

my %suiteType = ();

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-Nextest-19"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/smoke.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep --color=never -v "dsp.qms"');

my @any = ('advanced_trunk_group_routing', 'ayt_info_msg', 'call_routing', 'cdr', 'cdr_start_stop', 'codec_filtering', 'codec_profile', 'default_ptime', 'detect_endpoint_availability', 'drop_call_invalid_dnis', 'e164_numbering', 'enum', 'ep_isdn_local', 'extended_header_manipulation', 'fmm', 'functional', 'functional_basic', 'history_info', 'host_manipulation', 'hunt_isdn_cc_global', 'hunting_within_cp', 'info_based_reachability', 'interim_cdr_enhancement', 'invite_based_reachability', 'kopt_configurable_sessid_verid', 'kopt_paid_header_manipulation_fmm', 'kopt_split_sip_header', 'last_reg_time', 'leadingplusremoval', 'maddr', 'media_inactivity_timer', 'mirrorproxy', 'msud', 'multiple_dns', 'nat_enhancements', 'number_manipulation', 'lawfullIntercept', 'outofband-dtmf', 'path_route_based_routing', 'pem_removal_183_to_180_conversion', 'pilot_number_registration', 'policing_indicator', 'privacy_enhancements', 'privacy_manipulation', 'provision', 'ptime_removal', 'q931', 'radius', 'radius_x_route', 'ratelimiting_callgapping', 'ratelimiting_firewall', 'rdn_diversion_iwf', 'reg_event_support', 'routing_hunting_options', 'sanity', 'sdp_manipulation', 'sdp_pass_thru', 'sip_port_mapping', 'sip_session_timer', 'sip_trans', 'sip_update', 'sipi_peerless', 'sipi_sipt_80', 'tcp', 'tcst38_fax');

chomp @result;

my %suiteType = ();
map {$suiteType{$_ . '.qms'} = 'Any'} @any;

my %data = ();
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;

    my @temp = split('/', $line);
    next unless (defined $suiteType{$temp[0]});

    #my $name =  join('-', @temp[0..($#temp-1)]);
    #$name =~ s/\.qms//g;
    my $name = 'smoke.qms/' . join('/',@temp[0..($#temp-1)]);
    $data{$name} = 1;
    #push (@{$data{$name}{tests}}, $temp[-1]);
}


my $dbh=Genband::Utils::db_connect('DATABASE') or die "failed make database connection";

my $suites = $dbh->selectall_hashref( "select regressionsuite_path from regressionsuite where regressionsuite_type = 'SMOKE'",'regressionsuite_path');

foreach (keys %data) {
    print $_ . " = Not found in db\n" unless defined $suites->{$_};
}

foreach (keys %{$suites}) {
    print $_ . " = Not found in box\n" unless defined $data{$_};
}
