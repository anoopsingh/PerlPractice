#!/gats/bin/perl 
use ATS;
use Data::Dumper;
use XML::Simple;
use Log::Log4perl qw(get_logger :easy);

# /var/opt/nextest/tdb/production_components.qms/
my $gen = Genband::Base->new(
                                 -obj_host => "172.23.58.6",
                                 -obj_user => 'root',
                                 -obj_password => 'shipped!!',
                                 -comm_type => "SSH", -sessionlog => 1);

my $xs = XML::Simple->new();

$gen->execLinuxCmd("su test");
$gen->execLinuxCmd("cd /opt/nextest/bin/RegressionExecution");

$gen->execLinuxCmd("cat suites_smoke.txt");

my $listCmd = "find . -name '*.qmt' |grep -v bkup";
my $suiteList = $gen->{CMDRESULTS};
my $finalhash ={};
$gen->execLinuxCmd("cd /var/opt/nextest/tdb/smoke.qms");

foreach my $suite ( @$suiteList ) {

    if ( $suite !~ /provision/ ) {
        my $suiteDir = $suite.'.qms';
        #print "suite name is  $suiteDir\n";
        unless ( $gen->execLinuxCmd("cd $suiteDir") ) {
        } else {
            $gen->execLinuxCmd("$listCmd"); 
            $finalhash->{$suite} = $gen->{CMDRESULTS};
            $gen->execLinuxCmd("cd ..");
        } 

    }
}

print Dumper $finalhash; 
my $xml = $xs->XMLout($finalhash, outputfile =>'smoke.xml',rootname => 'suite_name',xmldecl => 1);
