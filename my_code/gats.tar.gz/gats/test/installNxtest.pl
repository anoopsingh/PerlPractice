use Genband::Installer;
use strict;
#$ENV{TERM} = 'dump';
my %args = ( -location => 'BL', -build => 'r9-1-pre06-unified', -nxtest => 'BL-SQAR6-AutomationVM12');
 
unless (&Genband::Installer::installNxtest(%args)) {
        print "Failed to install \'$args{-build}\'\n";
} else {
        print "successfully installed \'$args{-build}\'\n";
}
