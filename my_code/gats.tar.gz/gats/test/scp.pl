use ATS;
use Data::Dumper;
$ENV{'TERM'} = 'DUMP';
#my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["sbc32", "sbc34"], -sessionlog =>1);
my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["NXTEST6"], -sessionlog =>1);

#my $cmd = "scp \'/tmp/totalmem.log\' root\@172.23.54.205:/tmp/";

#my $cmd = "scp root\@172.23.54.205:/root/ats_user/logs/SBC-SBC34-20130913-155805-sessionInput.log /tmp/";
my $cmd = "scp /tmp/nextest.log root\@172.23.54.205:/tmp/";
$obj->scpFile( -scpCmd => $cmd, -password => 'shipped!!');
