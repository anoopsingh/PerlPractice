use ATS;
use Genband::SEAGULL;
my $ssh = Genband::SEAGULL->new(
                                                -obj_host => "172.23.59.71",
                                                -obj_user => 'root',
                                                -obj_password => 'shipped!!',
                                                -comm_type => "SSH");
