use strict;
use Spreadsheet::WriteExcel;

# Create a new workbook called simple.xls and add a worksheet
my $workbook   = Spreadsheet::WriteExcel->new("images.xls");
my $worksheet1 = $workbook->add_worksheet('Image 1');

# Insert a basic image
$worksheet1->write('A10', "Image inserted into worksheet.");
$worksheet1->insert_image('A1', '/gats/perf/logs/rpateel/88487/20131023-163639/memory.png', 32, 10)
