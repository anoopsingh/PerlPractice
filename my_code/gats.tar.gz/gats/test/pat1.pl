use Data::Dumper;

my $out = 'PING 23.6.7.201 (23.6.7.201) from 23.6.7.10 eth3: 56(84) bytes of data.

--- 23.6.7.201 ping statistics ---
4 packets transmitted, 0 received,10% packet loss, time 2999ms';

my @result = split(/\n/, $out);
chomp @result;

if (grep/\D+0\% packet loss/i, @result) {
	print "Match\n";
}
