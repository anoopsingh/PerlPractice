use Genband::Utils;
use Data::Dumper;

my $conf = qq |
    log4perl.logger                      = DEBUG, ScreenApp
    log4perl.appender.ScreenApp          = Log::Log4perl::Appender::Screen
    log4perl.appender.ScreenApp.stderr   = 0
    log4perl.appender.ScreenApp.layout   = PatternLayout
    log4perl.appender.ScreenApp.layout.ConversionPattern = %d %-5p %-4L %m%n
    |;

Log::Log4perl->init(\$conf);

#my $a= Genband::Utils::resolve_alias('SBC13');

#print Dumper($a);

my $a = &Genband::Utils::executeSqlCmd("update sched_job_queue set Qslot = 10 where  JobId = 10");

print scalar($a);
