use strict;
use Spreadsheet::WriteExcel;

# Create a new workbook called simple.xls and add a worksheet
my $workbook   = Spreadsheet::WriteExcel->new("stats.xls");
my $worksheet = $workbook->add_worksheet('Test Stats');

# Insert a basic image
my %formats = ();
    
$formats{mergeHeader} = $workbook->add_format(bold => 1, bg_color => 'yellow', border  => 1);
$formats{header1} = $workbook->add_format(bold => 1, bg_color => 'green', border  => 1);
$formats{header2} = $workbook->add_format(bold => 1, bg_color => 27, border  => 1);
$formats{header3} = $workbook->add_format(bold => 1, bg_color => 50, border  => 1);


$worksheet->merge_range('A1:U1', 'SUT Platform : S2000',$formats{mergeHeader});
$worksheet->merge_range('A2:U2', 'Profile info : Test',$formats{header1});
$worksheet->merge_range('A3:U3', 'Results(directory Path) : /test/',$formats{header1});
$worksheet->merge_range('A4:C4', 'Codec',$formats{header2});
$worksheet->merge_range('A5:C5', 'Mode',$formats{header2});
$worksheet->merge_range('A6:C6', 'Call Duration',$formats{header2});
$worksheet->merge_range('A7:C7', 'Test Duration',$formats{header2});
$worksheet->merge_range('A8:C8', 'Profile info',$formats{header2});

$worksheet->write_row(8,0, ['Build', 'Max CPS', 'Max Concurrent Calls', 'CPU Active Max (%)', 'Virtual  max', 'Memory  Max (%)', 'Test Status', 'Rfactor', 'Remarks'] ,$formats{header3});



my $col = 0;
foreach ('Date Time', 'Gis CPU Usage (Active)', 'Gis  Mem  Usage (Active)', 'Gis CPU Usage (StandBy)', 'Gis  Mem  Usage (StandBy)', 'Gis Virtual Memory Usage (Active)', 'Gis Virtual Memory Usage (StandBy)', 'Free Memory in GB (Active)', 'Free Memory in GB (StandBy)', 'System CPU (Active)', 'System CPU (StandBy)') {
    $worksheet->merge_range(12,$col++,10,$col++, $_, $formats{mergeHeader});
}

$worksheet->freeze_panes(13,0);

my @files = ('timeStamp', 'pcpu-active', 'mem-active', 'pcpu-standby', 'mem-standby', 'ver-active', 'ver-standby', 'fm-active', 'fm-standby', 'sc-active', 'sc-standby');

my $row = 13;
$col = 0;
my $timeStampRow = 13;
my $dir = '/gats/perf/logs/rpateel/88489/20131104-144707';
my %max = ();
foreach my $file (@files) {
    $row = 11;
    my $fh;
    eval {
        open ($fh, '<', "$dir/$file");
    };
    if ($@) {
        print "failed to open $file - $@\n";
    }
    foreach my $line (<$fh>) {
        chomp $line;
        $worksheet->write($row,$col, $line);
        $worksheet->merge_cells($row,$col,$row,($col+1));        
        $row++;
        $max{cpu} = $line if ($file eq 'pcpu-active' and $line > $max{cpu});
        $max{virtual} = $line if ($file eq 'ver-active' and $line > $max{virtual});
        $max{mem} = $line if ($file eq 'mem-active' and $line > $max{mem});
            
        if ($file eq 'timeStamp') {
            $timeStampRow++;
        } else {
            last if ($row >= $timeStampRow);
        }
    }
    $col+=  2;
    close $fh;
}

$worksheet->write(9,3, $max{cpu});
$worksheet->write(9,4, $max{virtual});
$worksheet->write(9,5, $max{mem});
$workbook->close();
    
