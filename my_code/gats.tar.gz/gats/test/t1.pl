my @a = ('xrt_22','xrt_40_88069','xrt_35','xrt_13','xrt_29','xrt_55_95527','xrt_18','xrt_15','xrt_34','xrt_32','xrt_38_88065','xrt_10','xrt_27','xrt_31','xrt_33','xrt_51_88091','xrt_07','xrt_19','xrt_17','xrt_25','xrt_14','xrt_26','xrt_50_88089','xrt_45_88079','xrt_02_04_05','xrt_08','xrt_37','xrt_44_88077','xrt_11','xrt_24','xrt_23','xrt_21','xrt_43_88075','xrt_16','xrt_36','xrt_54_95224','xrt_20','xrt_28','xrt_30','xrt_42_88073','xrt_12','xrt_53_95222','xrt_39_88067');

my $tc = 'xrt_14';

print "hi\n"  if (grep(/^$tc$/, @a))
