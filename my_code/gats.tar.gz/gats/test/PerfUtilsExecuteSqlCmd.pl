use Genband::PERF::PerfUtils;
use strict;
use Data::Dumper;

my $jobData = &Genband::Utils::executeSqlCmd("SELECT regressionjob_testbedtopologyuuid, regressionjob_release, regressionjob_username, regressionjob_build, regressionjob_type, regressionjob_debugmode, regressionjob_name, regressionjob_platform, regressionjob_flags, regressionjob_skipbaseconfig, regressionjob_executeonly  FROM regressionjob where regressionjob_uuid ='2fce72c9-1ce9-11e4-a96a-00155d361715'");

print Dumper($jobData);

print "$jobData->[0]->[10]=\n"
