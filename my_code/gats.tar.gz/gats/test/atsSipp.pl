use ATS;
use Data::Dumper;

my $gen = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["OTT-SB1-GEN1B"], -sessionlog =>1);

$gen->execLinuxCmd('ifconfig eth2 | grep "Mask:"');
    my $mask = $gen->{CMDRESULTS}->[0];

print Dumper($gen->{CMDRESULTS});
    $mask =~ s/.*Mask:\D*(\d+?\.\d+?\.\d+?\.\d+)/$1/;
    print "$1\n";
    my $maskBit = ($mask eq '255.255.255.0') ? 24 :16;


print "$maskBit\n";
