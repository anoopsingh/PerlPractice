use strict;
use Genband::PERF::PerfUtils;
use Data::Dumper;
use XML::Simple;

#my $xml = "<promptConfirmExecCmd>
#	<args>
#	<cmd>cli iedge edit sip-ingress-gw1 0 type sipgw static <testbeddata>nxtest:1:ce0->PUB_RSA->1->IP</testbeddata> realm rsa-1 sip enable xcalls 0</cmd>
#	<prompts>['Please enter the hostname for mdevices.xml.*:', '(y/n).*:', 'iServer restart (y/n).*:']</prompts>
#	<confirm>['','y','y']</confirm>
#	</args>
#</promptConfirmExecCmd>";
=pod
my $xml = "<promptConfirmExecCmd>
       <args>
       <cmd>cli iedge edit sip-ingress-gw1 0 type sipgw static realm rsa-1 sip enable xcalls 0</cmd>
       <prompts>['Please enter the hostname for mdevices.xml.*:', '(y/n).*:', 'iServer restart (y/n).*:']</prompts>
       <confirm>['','y','y']</confirm>
       </args>
</promptConfirmExecCmd>";
=cut

my $xml = '<?xml version="1.0" encoding="utf-8" ?>
<!-- CDR descriptions v0.1 -->
<!-- Whenever anyone needs to add a new entry to the CDR, in any branch,
     it is incumbent upon them to define that entry in the mainline version of
     of cdrdict.xml first (e.g., by defining the next available entry). It is
     is then up to the developer to ensure that a consistent CDR representation
     is used on the branch in question. This might entail, for example, adding
     unused enteries prior to the new entry in the version of cdrdict.xml on the
     branch. When it comes time to merge into mainline, no renumbering will be
     required, and therefore there will be no customer disruption
-->
<CDR>
<field no="1" name="start-time" fmt="string"/>
<field no="2" name="start-time" fmt="uint32"/>
<field no="3" name="call-duration" fmt="HH:MM:SS"/>
<field no="4" name="call-source" fmt="A.B.C.D"/>
<field no="5" name="call-source-q931sig-port" fmt="uint32"/>
<field no="6" name="call-dest" fmt="A.B.C.D"/>
<field no="7"/>
<field no="8" name="call-source-custid" fmt="string"/>
<field no="9" name="called-party-on-dest" fmt="string"/>
<field no="10" name="called-party-from-src" fmt="string"/>
<field no="11" name="call-type" fmt="{ IF|IV|IM }"/>
<field no="12"/>
<field no="13" name="disconnect-error-type" fmt="{A|B|N|E}"/>
<field no="14" name="call-error" fmt="uint32"/>
<field no="15" name="call-error" fmt="string"/>
<field no="16"/>
<field no="17"/>
<field no="18" name="ani" fmt="string"/>
<field no="19" name="mediaType" fmt="{AD|VD|FX|IM|FT|MB}"/>
<field no="20" name="data-volume-tx-src" fmt="string"/>
<field no="21" name="data-volume-tx-dst" fmt="string"/>
<field no="22" name="cdr-seq-no" fmt="uint32"/>
<field no="23" name="transcoder_id" fmt="uint32"/>
<field no="24" name="callid" fmt="string"/>
<field no="25" name="call-hold-time" fmt="HH:MM:SS"/>
<field no="26" name="call-source-regid" fmt="string"/>
<field no="27" name="call-source-uport" fmt="uint32"/>
<field no="28" name="call-dest-regid" fmt="string"/>
<field no="29" name="call-dest-uport" fmt="uint32"/>
<field no="30" name="isdn-cause-code" fmt="uint32"/>
<field no="31" name="called-party-after-src-calling-plan" fmt="string"/>
<field no="32" name="call-error-dest" fmt="uint32"/>
<field no="33" name="call-error-dest" fmt="string"/>
<field no="34" name="call-error-event-str" fmt="string#string"/>
<field no="35" name="new-ani" fmt="string"/>
<field no="36" name="call-duration" fmt="uint32"/>
<field no="37" name="incoming-leg-callid" fmt="string"/>
<field no="38" name="protocol" fmt="{sip|h323}"/>
<field no="39" name="cdr-type" fmt="{start1|start2|end1|end2|hunt|interim}"/>
<field no="40" name="hunting-attempts" fmt="uint32"/>
<field no="41" name="caller-trunk-group" fmt="string"/>
<field no="42" name="call-pdd" fmt="uint32"/>
<field no="43" name="h323-dest-ras-error" fmt="uint32"/>
<field no="44" name="h323-dest-h225-error" fmt="uint32"/>
<field no="45" name="sip-dest-respcode" fmt="uint32"/>
<field no="46" name="dest-trunk-group" fmt="string"/>
<field no="47" name="call-duration-fractional" fmt="float(3)"/>
<field no="48" name="timezone" fmt="string"/>
<field no="49" name="msw-name" fmt="string"/>
<field no="50" name="called-party-after-transit-route" fmt="string"/>
<field no="51" name="called-party-on-dest-num-type" fmt="uint32"/>
<field no="52" name="called-party-from-src-num-type" fmt="uint32"/>
<field no="53" name="call-source-realm-name" fmt="string"/>
<field no="54" name="call-dest-realm-name" fmt="string"/>
<field no="55" name="call-dest-crname" fmt="string"/>
<field no="56" name="call-dest-custid" fmt="string"/>
<field no="57" name="call-zone-data" fmt="string"/>
<field no="58" name="calling-party-on-dest-num-type" fmt="uint32"/>
<field no="59" name="calling-party-from-src-num-type" fmt="uint32"/>
<field no="60" name="original-isdn-cause-code" fmt="uint32"/>
<field no="61" name="packets-received-on-src-leg" fmt="string" />
<field no="62" name="packets-lost-on-src-leg" fmt="uint32" />
<field no="63" name="packets-discarded-on-src-leg" fmt="uint32" />
<field no="64" name="pdv-on-src-leg" fmt="uint32" />
<field no="65" name="codec-on-src-leg" fmt="string" />
<field no="66" name="latency-on-src-leg" fmt="uint32" />
<field no="67" name="rfactor-on-src-leg" fmt="uint32" />
<field no="68" name="packets-received-on-dest-leg" fmt="string" />
<field no="69" name="packets-lost-on-dest-leg" fmt="uint32" />
<field no="70" name="packets-discarded-on-dest-leg" fmt="uint32" />
<field no="71" name="pdv-on-dest-leg" fmt="uint32" />
<field no="72" name="codec-on-dest-leg" fmt="string" />
<field no="73" name="latency-on-dest-leg" fmt="uint32" />
<field no="74" name="rfactor-on-dest-leg" fmt="uint32" />
<field no="75" name="sip-src-respcode" fmt="uint32"/>
<field no="76" name="peer-protocol" fmt="{sip|h323}"/>
<field no="77" name="src-private-ip" fmt="string"/>
<field no="78" name="dest-private-ip" fmt="string"/>
<field no="79" name="src-igrp-name" fmt="string"/>
<field no="80" name="dest-igrp-name" fmt="string"/>
<field no="81" name="diversion-info" fmt="string"/>
<field no="82" name="custom-contact-tag" fmt="string"/>
<field no="83" name="e911-call" fmt="string"/>
<field no="84" name="reserved" fmt="string"/>
<field no="85" name="reserved" fmt="string"/>
<field no="86" name="call-release-source" fmt="string"/>
<field no="87" name="hunt-attempts-including-LCF-tries" fmt="uint32"/>
<field no="88" name="call-gapping-error" fmt="uint32"/>
<field no="89" name="error-code-in-reason-header" fmt="uint32"/>
<field no="90" name="ocl-object-type" fmt="string"/>
<field no="91" name="ocl-object-id-dtn-regid-realmname" fmt="string"/>
<field no="92" name="ocl-object-id-dtnrealm-uport" fmt="string"/>
<field no="93" name="ocl-policy-name" fmt="string"/>
<field no="94" name="src-private-port" fmt="string"/>
<field no="95" name="dest-private-port" fmt="string"/>
<field no="96" name="src-realm-media-ip" fmt="string"/>
<field no="97" name="src-realm-media-port" fmt="string"/>
<field no="98" name="dest-realm-media-ip" fmt="string"/>
<field no="99" name="dest-realm-media-port" fmt="string"/>
<field no="100" name="src-trunk-context" fmt="string"/>
<field no="101" name="dst-trunk-context" fmt="string"/>
<field no="102" name="Leg1_PCV" fmt="string"/>
<field no="103" name="Leg2_PCV" fmt="string"/>
<field no="104" name="Leg1_PANI" fmt="string"/>
<field no="105" name="Leg2_PANI" fmt="string"/>
<field no="106" name="call-connect-time-ms" fmt="string"/>
<field no="107" name="call-end-time-ms" fmt="string"/>
<field no="108" name="routing-number" fmt="string"/>
<field no="109" name="No_of_m_lines" fmt="string"/>
<field no="110" name="from-uri-user-part" fmt="string"/>
<field no="111" name="new-from-uri-user-part" fmt="string"/>
<field no="112" name="paid-uri-user-part" fmt="string"/>
<field no="113" name="new-paid-uri-user-part" fmt="string"/>
<field no="114" name="privacy" fmt="string"/>
<field no="115" name="request-uri-user-part" fmt="string"/>
<field no="116" name="new-request-uri-user-part" fmt="string"/>
<field no="117" name="local-refer-status" fmt="string"/>
<field no="118" name="sip-dest-respreason" fmt="string"/>
<field no="119" name="sip-src-respreason" fmt="string"/>
<field no="120" name="charge-number" fmt="string"/>
<field no="121" name="charge-number-noa" fmt="uint32"/>
<field no="122" name="charge-number-npi" fmt="uint32"/>
<field no="123" name="segment-start-time-ms" fmt="string"/>
<field no="124" name="segment-duration-fractional" fmt="string"/>
<field no="125" name="leg1-loss-rate" fmt="uint32"/>
<field no="126" name="leg1-discard-rate" fmt="uint32"/>
<field no="127" name="leg1-burst-density" fmt="uint32"/>
<field no="128" name="leg1-gap-density" fmt="uint32"/>
<field no="129" name="leg1-burst-duration" fmt="uint32"/>
<field no="130" name="leg1-gap-duration" fmt="uint32"/>
<field no="131" name="leg1-round-trip-delay" fmt="uint32"/>
<field no="132" name="leg1-ES-Delay" fmt="uint32"/>
<field no="133" name="leg1-GMin" fmt="uint32"/>
<field no="134" name="leg1-jb-adaptive" fmt="uint32"/>
<field no="135" name="leg1-jb-rate" fmt="uint32"/>
<field no="136" name="leg1-RFactor" fmt="uint32"/>
<field no="137" name="leg1-MCQ" fmt="uint32"/>
<field no="138" name="leg1-jb-nominal" fmt="uint32"/>
<field no="139" name="leg1-jb-max-delay" fmt="uint32"/>
<field no="140" name="leg1-jb-abs-max-delay" fmt="uint32"/>
<field no="141" name="leg2-loss-rate" fmt="uint32"/>
<field no="142" name="leg2-discard-rate" fmt="uint32"/>
<field no="143" name="leg2-burst-density" fmt="uint32"/>
<field no="144" name="leg2-gap-density" fmt="uint32"/>
<field no="145" name="leg2-burst-duration" fmt="uint32"/>
<field no="146" name="leg2-gap-duration" fmt="uint32"/>
<field no="147" name="leg2-round-trip-delay" fmt="uint32"/>
<field no="148" name="leg2-ES-Delay" fmt="uint32"/>
<field no="149" name="leg2-GMin" fmt="uint32"/>
<field no="150" name="leg2-jb-adaptive" fmt="uint32"/>
<field no="151" name="leg2-jb-rate" fmt="uint32"/>
<field no="152" name="leg2-RFactor" fmt="uint32"/>
<field no="153" name="leg2-MCQ" fmt="uint32"/>
<field no="154" name="leg2-jb-nominal" fmt="uint32"/>
<field no="155" name="leg2-jb-max-delay" fmt="uint32"/>
<field no="156" name="leg2-jb-abs-max-delay" fmt="uint32"/>
<field no="157"/>
<field no="158"/>
<field no="159" name="src-cipher-suite" fmt="uint32"/>
<field no="160" name="dest-cipher-suite" fmt="uint32"/>
<field no="161" name="src-packet-outside-replay-window" fmt="uint32"/>
<field no="162" name="src-packet-auth-failure" fmt="uint32"/>
<field no="163" name="src-packet-cipher-failure" fmt="uint32"/>
<field no="164" name="dest-packet-outside-replay-window" fmt="uint32"/>
<field no="165" name="dest-packet-auth-failure" fmt="uint32"/>
<field no="166" name="dest-packet-cipher-failure" fmt="uint32"/>
<field no="167" name="fmm-call-leg-info1" fmt="string"/>
<field no="168" name="fmm-call-leg-info2" fmt="string"/>
<field no="169" name="fmm-call-leg-info3" fmt="string"/>
<field no="170" name="fmm-call-leg-info4" fmt="string"/>
<field no="171" name="fmm-call-leg-info5" fmt="string"/>
<field no="172" name="fmm-call-info1" fmt="string"/>
<field no="173" name="fmm-call-info2" fmt="string"/>
<field no="174" name="fmm-call-info3" fmt="string"/>
<field no="175" name="fmm-call-info4" fmt="string"/>
<field no="176" name="fmm-call-info5" fmt="string"/>
<field no="177" name="embedded-DSP-insertion-Reason" fmt="string"/>
<field no="178" name="outgoing-to-uri" fmt="string"/>
<field no="179" name="incoming-request-uri" fmt="string"/>
<field no="180" name="incoming-rsa-ip-address" fmt="A.B.C.D"/>
<field no="181" name="SBC-iServer-version" fmt="string"/>
<field no="182" name="outgoing-request-uri" fmt="string"/>
<field no="183" name="outgoing-from-uri" fmt="string"/>
<!-- field 184 reserved for privacy-ingress-requested -->
<field no="184"/>
<!-- field 185 reserved for privacy-method-egress -->
<field no="185"/>
<!-- field 186 reserved for privacy-egress-requested -->
<field no="186"/>
<!-- field 187 reserved for Packet-Policing-Indicator leg1-->
<field no="187" name="src-policed-packets" fmt="uint32"/>
<!-- field 188 reserved for Packet-Policing-Indicator leg2-->
<field no="188" name="dest-policed-packets" fmt="uint32"/>
<field no="189" name="full-paid-hdr" fmt="string"/>
<field no="190" name="source-ptime" fmt="uint32"/>
<field no="191" name="destination-ptime" fmt="uint32"/>
<!--field 192 reserved for role-of-node-->
<field no="192"/>
<!--field 193 reserved for call-asserted-identity-->
<field no="193"/>
<!--field 194 reserved for sdp-media-name-->
<field no="194"/>
<!--field 195 reserved for media-initiator-flag-->
<field no="195"/>
<!--field 196 reserved for local-gw-inserted-->
<field no="196"/>
<!--field 197 reserved for orig-ioi-->
<field no="197"/>
<!--field 198 reserved for term-ioi-->
<field no="198"/>
<!--field 199 reserved for total-rejected-reinvites-->
<field no="199"/>
</CDR>';

#my $xmlData = &Genband::PERF::PerfUtils::frameCliCmd($xml);

my $xmlData = &XMLin($xml);
print Dumper(\$xmlData);


