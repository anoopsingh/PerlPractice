use ATS;
use Data::Dumper;
$ENV{TERM} = 'DUMP';
my $ssh = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-SQAR1-SBC2"], -sessionlog =>1);

#my $ret = $ssh->verifyiServerStatus();

#print Dumper $ret;
