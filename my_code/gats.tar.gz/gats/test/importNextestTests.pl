use ATS;
use Data::Dumper;

#my @any = ('advanced_trunk_group_routing','ayt_info_msg','call_routing','cdr','cdr_start_stop','codec_filtering','codec_profile','drop_call_invalid_dnis','e164_numbering','ep_isdn_local','extended_header_manipulation','functional_basic','host_manipulation','hunt_isdn_cc_global','hunting_within_cp','interim_cdr_enhancement','kopt_configurable_sessid_verid','kopt_split_sip_header','last_reg_time','leadingplusremoval','maddr','outofband-dtmf','pem_removal_183_to_180_conversion','pilot_number_registration','provision','privacy_enhancements','privacy_manipulation','q931','radius_x_route','ratelimiting_callgapping','ratelimiting_firewall','rdn_diversion_iwf','routing_hunting_options','sdp_pass_thru','sip_port_mapping','sip_trans','sip_update','sipi_peerless','sipi_sipt_80','tcst38_fax');

#my @real = ('path_route_based_routing','nexunit_maddr','nexunit_pathheader','nexunit_relay_in_call_subscribe','nexunit_serviceroute','nexunit_sip_stack','nexunit_siptxn_tie_up','im_presence','tls','cdr_start_stop','ciscoGTD','h323_radius','number_manipulation','privacy_manipulation','rad_accounting','radius','radius_pod','radius_prepaid','radius_x_route','sip_trans','tcp','x_route_tag','nexunit_aaa','3xx','ayt_info_msg','dtmf_tone_generation','enum','functional_basic','gare','history_info','invite_based_reachability','media_cac','media_inactivity_timer','mirrorproxy','multiple_sip_ports','nat','nat_enhancements','obp','pem_removal_183_to_180_conversion','ptime_removal','rmaip','sanity','sip_local_refer','snmp','msud');

my %suiteType = ();
#map {$suiteType{$_ . '.qms'} = 'Any'} @any;
#map {$suiteType{$_ . '.qms'} = 'Real'} @real;

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN72"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/eng_test.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep --color=never -v "dsp.qms"');

chomp @result;

my %data = ();
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);
    
    my $name =  join('-', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = 'eng_test.qms/' . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    $data{$name}{type} = 'Any'; #(defined $suiteType{$temp[0]}) ? $suiteType{$temp[0]} : 'Real';
    
    print "$data{$name}{type}==\n";
}

#print Dumper(\%data);

my $tTests = 0;
my $anyTest = 0;

foreach my $suiteName (keys %data) {
    my $suiteId = &getUUID();
    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.3.0,V8.3.1,V8.3.2', 'sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'NEXUNIT', '$data{$suiteName}{path}')\n";
    
    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.1.1,V8.2.1,V8.3.0,V8.3.1,V8.3.2,V8.4.0,V9.0.0,V9.1.0', 'annapolis,jarell,sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'NEXUNIT', '$data{$suiteName}{path}', 'NONSCM', '$data{$suiteName}{type}')");
    
    #print "INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')\n";
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    
    $anyTest += scalar(@{$data{$suiteName}{tests}}) if ($data{$suiteName}{type} eq 'Any');
    $tTests += scalar(@{$data{$suiteName}{tests}});
    
}

print "$anyTest = $tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
