use ATS;
use Date::Parse;
use Data::Dumper;
$ENV{TERM} = 'DUMP';
my $ssh = Genband::Base->new(
                                                -obj_host => "172.23.58.2",
                                                -obj_user => 'root',
                                                -obj_password => 'shipped!!',
                                                -comm_type => "SSH", -sessionlog => 1);


my $checkRegCmd = q(statclient showLink);
@result = $ssh->execCmd($checkRegCmd);
print Dumper $result;
#for (my $ii =0; $ii<=$#$result; $ii++ ) {
#        if ( $result->[$ii]=~ /pci0/ ) {
#           $flag = 1;
#
#        }
#        if ( $flag ) {
#            if ( $result->[$ii]=~ /UP BROADCAST RUNNING MULTICAST/ ) {
#                $media = 1;
#                print "media is up and ruung \n";
#            }
#        }
#    }
