use Data::Dumper;
$testData = 'SBC_HA,NXTEST,SBC,NXTEST';

my %REQUIRED = ();

foreach ( $testData) {
    my @tbS = split(/,/, $_);
    foreach my $tb (@tbS) {
	if ($tb =~ /^(.+)\_HA$/) {
		push (@{$REQUIRED{$1}}, 2);
        } else {
		 push (@{$REQUIRED{$tb}}, 1);	
        }
    }
}

print Dumper(\%REQUIRED);
