use Data::Dumper;
#my $cmd = "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3\"/\"\$4\"/\"\$5}'";
#my $cmd = "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3\"/\"\$4}'";
#my $cmd = "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3}'";
#my $cmd = "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2}' 2>/dev/null";

my @cmds = ("find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2}' 2>/dev/null" , "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3}'", "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3\"/\"\$4}'", "find -name \"*.qmt\" | grep -e '/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms\/.*\.qms/' | awk -F'/' '{ print \$2\"/\"\$3\"/\"\$4\"/\"\$5}'");

foreach my $cmd (@cmds) {
    print "executing -> $cmd\n"
    my @suitesWithSubF = `$cmd`;
    
    my %done = ();
    foreach my $feature (@suitesWithSubF) {
            chomp $feature;
            next if $done{$feature};
            my @tests = `ls -1 $feature/*.qmt | grep -v 'provision' | grep -v xit 2>/dev/null`;
            $done{$feature} = 1;
            chomp @tests;
            next if((scalar @tests) <= 0);
            print Dumper(\@tests);
            print "$feature\n";
            `mkdir $feature/main.qms`;
            map {`mv $_ $feature/main.qms/`} @tests;
    #       `mv $feature/main.qms/provision.qmt $feature/`;
    #       `mv $feature/main.qms/xit.qmt $feature/`;
    #       last;
    }
}
