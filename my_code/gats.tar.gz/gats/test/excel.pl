#!/usr/bin/perl -w

use strict;
use Spreadsheet::WriteExcel;
use Spreadsheet::WriteExcel::Utility qw( xl_range_formula );

my $workbook  = Spreadsheet::WriteExcel->new( 'chart.xls' );
my $worksheet = $workbook->add_worksheet();
my $bold      = $workbook->add_format( bold => 1 );

# Add the worksheet data that the charts will refer to.
my $headings = [ 'Number', 'Sample 1'];
my $data = [
    [ 2, 3, 4, 5, 6, 7 , 8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30],
    [ 1, 4, 5, 2, 1, 5,6,7,8,9,0,1,3,2,1 ,0,3,8,9,10,4,7,2,9,3,5,1,8,2],
    [0,3,8,9,10,4,7,2,9,3,5,1,8,2,1, 4, 5, 2, 1, 5,6,7,8,9,0,1,3,2,1]
];

$worksheet->write( 'A1', $headings, $bold );
$worksheet->write( 'A2', $data );

# Create a new chart object. In this case an embedded chart.
my $chart = $workbook->add_chart( type => 'line', embedded => 1 );

# Configure the first series. (Sample 1)
$chart->add_series(
    name       => 'Sample 1',
    categories => '=Sheet1!$A$2:$A$30',
#    categories => xl_range_formula( 'Sheet1', 0, 0, 15, 0 ),
    values     => '=Sheet1!$B$2:$B$30',
#    values => xl_range_formula( 'Sheet1', 0, 1, 15, 1 ),
);

$chart->add_series(
    name       => 'Sample 2',
    categories => '=Sheet1!$A$2:$A$30',
#    categories => xl_range_formula( 'Sheet1', 0, 0, 15, 0 ),
    values     => '=Sheet1!$C$2:$C$30',
#    values => xl_range_formula( 'Sheet1', 0, 1, 15, 1 ),
);


# Add a chart title and some axis labels.
$chart->set_title ( name => 'Results of sample analysis' );
$chart->set_x_axis( name => 'Test number' );
$chart->set_y_axis( name => 'Sample length (cm)' );

# Insert the chart into the worksheet (with an offset).
$worksheet->insert_chart( 'D2', $chart, 25, 10 );
