use Genband::Installer;
use strict;
#$ENV{TERM} = 'dump';
my %args = ( -location => 'IND', -build => 'V9.1.0.0D53', -sbcs => ['GL-SBC33']);

unless (&Genband::Installer::installSbc(%args)) {
	print "Failed to install \'$args{-build}\'\n";
} else {
	print "successfully installed \'$args{-build}\'\n";
}
