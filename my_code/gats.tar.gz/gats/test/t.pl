use Net::Telnet;
use Data::UUID;
@cmd = ('ssh','-l', 'root', '172.23.59.71', '-p', 22);
            my $pty = &spawnPty(\@cmd);

my            $telObj = new Net::Telnet (-fhopen => $pty,
                                    -prompt => '/.*[\$#%>] $/',
                                    -telnetmode => 0,
                                    -binmode=> 0,  # setting this to 1 added a weird character to the end of each line.
                                    -cmd_remove_mode => 1,
                                    -output_record_separator => "\r",
                                    -Timeout => 30,
                                    -Errmode => "return"
                                    );

my ($prematch, $match) = $telObj->waitfor(-match => '/[P|p]assword: ?$/i', -match => '/.*[\$#%>] $/');

$telObj->print('shihpped!!');
$telObj->waitfor(-match => -match => '/.*[\$#%>] $/');

my @r = $telObj->cmd('ls -l ');

print @r;

sub spawnPty {
    my $cmdArgs=shift;
    my($pid, $pty, $tty, $tty_fd, @cmd);
    our $success;
    @cmd = @$cmdArgs;
    ## Create a new pseudo terminal.
    use IO::Pty ();
$pty = new IO::Pty;
    ## Execute the program in another process.
    unless ($pid = fork) {  # child process\
        ## Disassociate process from existing controlling terminal.
        use POSIX ();
        #POSIX::setsid or die "setsid failed: $!";
        $pty->make_slave_controlling_terminal; 
        ## Associate process with a new controlling terminal.
        $tty = $pty->slave;
        $tty_fd = $tty->fileno;
        close $pty;

        ## Make stdio use the new controlling terminal.
        open STDIN, "<&$tty_fd" or die $!;
        open STDOUT, ">&$tty_fd" or die $!;
        open STDERR, ">&STDOUT" or die $!;
        close $tty;
	    #autoflush STDOUT 0;	
        ## Execute requested program.
        #exec @cmd or die "problem executing $cmd[0]\n";
        #system(@cmd) == 0 or &error(__PACKAGE__ . ".spawnPty Problem executing $cmd[0]");
    } # end child process
    $pty;
}
