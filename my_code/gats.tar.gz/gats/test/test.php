<?php

echo time();
?>

