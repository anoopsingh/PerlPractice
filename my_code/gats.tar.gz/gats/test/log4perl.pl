use Log::Log4perl qw(get_logger :easy :levels);;

my ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
my $timestamp = sprintf "%4d%02d%02d-%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
 
my $startTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
 

 
my $layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss.SSS}.%-8p %32.33C{3} : %X{ip} %m%n");
# Simplified layout for screen
my $screen_layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss}: %X{ip} %m%n");
 
# Override default easy init logging for Base 
# connections
 
my $ats_logger        = get_logger("Genband");
my $reg_execution_logger  = get_logger("Scripts");
$ats_logger->additivity(0);
$reg_execution_logger->additivity(0);

# Create the ATS appender and point it to a log file
my $ats_file_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "RegRun.log",
        name => "AutomationLog",
);

 
# Create a second test case appender and point it to the screen 
my $test_case_screen_appender = Log::Log4perl::Appender->new(
        "Log::Dispatch::Screen",
        name => "screen",
);
 
# Add appenders to the appropriate logger 
$ats_logger->add_appender($ats_file_appender);
$ats_logger->add_appender($test_case_screen_appender);
$reg_execution_logger->add_appender($test_case_screen_appender);
 
# Configure the appenders with the layout we've defined
$ats_file_appender->layout($layout);
$test_case_screen_appender->layout($screen_layout);



use ATS;
use threads;

my @threads = ();
foreach ('Ram', 'Bheam') {
    Log::Log4perl::MDC->put("ip", $_);
    push(@threads, threads->create(\&test()));
    print "======done======\n";
}

foreach (@threads) {
    $_->join();
}

sub test {
    sleep 10;
    my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["NXTEST6"], -sessionlog =>1);
}

