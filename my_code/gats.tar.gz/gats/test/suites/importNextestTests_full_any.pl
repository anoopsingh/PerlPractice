use ATS;
use Data::Dumper;


my @any = ('183_to_180_conversion', '3xx', 'adaptive_fax_routing', 'advancedTrunkGroupRouting', 'allowdestarqall', 'alternate_gk', 'ani_dnis_loopdetection', 'ayt_info_msg', 'bt_feature', 'call_routing', 'causecode', 'causecode_2', 'cdr', 'cdr_start_stop', 'cg_cd_party', 'ciscoGTD', 'codecFiltering', 'codecProfile', 'codeMappingReasonText', 'default_ptime', 'detect_endpoint_availability', 'diversion_header', 'domain_based_routing', 'dropCall_Invalid_DNIS', 'dtmf_tone_generation', 'dynamicCallHunting', 'e164_numbering', 'ec911', 'enum', 'ep_isdn_local', 'extended_header_manipulation_80', 'functional', 'functional_basic', 'fmm', 'gare', 'gw_selection', 'h225messages', 'h245messages', 'h323_radius', 'h323registration', 'handling_forked_request', 'history_info', 'host_manipulation', 'hunt_isdn_cc_global', 'hunting_within_cp', 'ibasis_enhancement', 'im_presence', 'in-egress-maxcalls', 'info_based_reachability', 'interim_cdr_enhancement', 'invite_based_reachability', 'last_reg_time', 'kopt_configurable_sessid_verid', 'kopt_paid_header_manipulation_fmm', 'kopt_split_sip_header', 'leadingplusremoval', 'maddr', 'mastergk', 'media_cac', 'media_inactivity_timer', 'media_interrealm', 'media_intrarealm', 'media_routing', 'mirrorproxy', 'msud', 'multiple_DNS', 'multiple_sip_ports', 'nat', 'nat_enhancements', 'no_source_address', 'number_manipulation', 'obp', 'obpxfactor', 'out_of_dialogue_sip_option_message', 'outbound_call_limit', 'outgoing_prefix', 'outofband-dtmf', 'path_route_based_routing', 'pem_removal_183_to_180_conversion', 'perf', 'phonecontext', 'pilot_number_registration', 'policing_indicator', 'priority_route_precedence', 'privacy_enhancements', 'privacy_iw', 'privacy_manipulation', 'ptime_removal', 'q931', 'qos', 'rad_accounting', 'radius', 'radius_pod', 'radius_prepaid', 'radius_x_route', 'ratelimiting_callgapping', 'ratelimiting_firewall', 'rba', 'rcse_header_manipulation', 'rdn_diversion_iwf', 'reason_header', 'reg_event_support', 'reject_route', 'restricted_ani', 'rmaip', 'rogue-rtp', 'routing_hunting_options', 'sanity', 'scm', 'sdp_manipulation', 'sdp_offer_answer', 'sdp_pass_thru', 'sip_local_refer', 'sip_options', 'sipi_peerless', 'sip_port_mapping', 'sip_prack', 'sip_trans', 'sip_update', 'sip3xxRelay', 'sipi_sipt_80', 'sipt', 'snmp', 'source_lookup', 'src_port_selection', 'sticky_route', 'subnet_cac', 'surrogate_registration', 'system_security', 'tcp', 'tcs_rfc_2833', 'tcst38_fax', 'tel_uri', 'tel_uri_rcse', 'timerc', 'tls', 'to_based_routing', 'trunkgroup', 'x_route_tag', 'zone', 'tea_37810_maddr', 'tea_38054_reinvite', 'tea_37534_redirect', 'tea_37995_sipi', 'ff_195836_progressIndicator', 'tea_37251', 'ps_187134_18xSameBody', 'ps_187451_wrongMline', 'ps_187912_mediaAttribute', 'ps_188449_h323SIP', 'ps_189042_mulitipleG729', 'ps_189713_longSDP', 'ps_189927_preMediaTimeout', 'ps_191260_contact200OK', 'ps_193259_hairpinMport', 'ff_38363_historyInfo_181', 'ff_189024_ForwardOptions', 'ff_192558_ClImapping', 'ff_194794_removeCLIinfo', 'ff_190110_ModifyContact', 'ff_194722_ClearmodeCodec', 'sipregistration', 'siperrcodemap', 'throttling_nat_ep'); 


my %suiteType = ();
map {$suiteType{$_ . '.qms'} = 'Any'} @any;

$ENV{'TERM'} = 'DUMP';

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN75"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/production_components.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep -v  "/dsp.qms" | grep -v "/scm.qms" | grep -v "/nxgen_media.qms"');

chomp @result;

my %data = ();
my $count = 0;
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);
    next unless (defined $suiteType{$temp[0]});
    my $name =  join('.', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = 'production_components.qms/' . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    $count++;
    
}

#print Dumper(\%data);
print "count = $count\n";

my $tTests = 0;

foreach my $suiteName (keys %data) {
    my $suiteId = &getUUID();
    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.3.0,V8.3.1,V8.3.2', 'sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'SMOKE', '$data{$suiteName}{path}')\n";

    print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V9.1.0', 'annapolis,sandybridge1u,sandybridge2u,,sandybridge2u-q21', 'SBC,NXTEST', '', 'FULL', '$data{$suiteName}{path}', 'NONSCM', 'Any')\n";

    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V9.1.0', 'annapolis,sandybridge1u,sandybridge2u,sandybridge2u-q21', 'SBC,NXTEST', '', 'FULL', '$data{$suiteName}{path}', 'NONSCM', 'Any')");
    
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    
    $tTests += scalar(@{$data{$suiteName}{tests}});
#    sleep(1); 
}

print "Tests = $tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
