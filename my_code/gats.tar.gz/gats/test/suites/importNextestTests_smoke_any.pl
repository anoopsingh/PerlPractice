use ATS;
use Data::Dumper;


my @any = ('advanced_trunk_group_routing', 'ayt_info_msg', 'call_routing', 'cdr', 'cdr_start_stop', 'codec_filtering', 'codec_profile', 'default_ptime', 'detect_endpoint_availability', 'drop_call_invalid_dnis', 'e164_numbering', 'enum', 'ep_isdn_local', 'extended_header_manipulation', 'functional', 'functional_basic', 'fmm', 'history_info', 'host_manipulation', 'hunt_isdn_cc_global', 'hunting_within_cp', 'info_based_reachability', 'interim_cdr_enhancement', 'invite_based_reachability', 'kopt_configurable_sessid_verid', 'kopt_paid_header_manipulation_fmm', 'kopt_split_sip_header', 'last_reg_time', 'leadingplusremoval', 'maddr', 'media_inactivity_timer', 'mirrorproxy', 'msud', 'multiple_dns', 'nat_enhancements', 'number_manipulation', 'outofband-dtmf', 'path_route_based_routing', 'pem_removal_183_to_180_conversion', 'pilot_number_registration', 'policing_indicator', 'privacy_enhancements', 'privacy_manipulation', 'ptime_removal', 'q931', 'radius', 'radius_x_route', 'ratelimiting_callgapping', 'ratelimiting_firewall', 'rdn_diversion_iwf', 'reg_event_support', 'routing_hunting_options', 'sanity', 'sdp_manipulation', 'sdp_pass_thru', 'sip_port_mapping', 'sip_trans', 'sip_update', 'sipi_peerless', 'sipi_sipt_80', 'tcp', 'tcst38_fax'); 


my %suiteType = ();
map {$suiteType{$_ . '.qms'} = 'Any'} @any;

$ENV{'TERM'} = 'DUMP';

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN75"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/smoke.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep -v  "/dsp.qms" | grep -v "/scm.qms" | grep -v "/nxgen_media.qms"');

chomp @result;

my %data = ();
my $count = 0;
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);
    next unless (defined $suiteType{$temp[0]});
    my $name =  join('.', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = 'smoke.qms/' . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    $count++;
    
}

#print Dumper(\%data);
print "count = $count\n";

my $tTests = 0;

foreach my $suiteName (keys %data) {
    my $suiteId = &getUUID();
    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.3.0,V8.3.1,V8.3.2', 'sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'SMOKE', '$data{$suiteName}{path}')\n";

    print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V9.1.0', 'annapolis,sandybridge1u,sandybridge2u,,sandybridge2u-q21', 'SBC,NXTEST', '', 'SMOKE', '$data{$suiteName}{path}', 'NONSCM', 'Any')\n";

    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V9.1.0', 'annapolis,sandybridge1u,sandybridge2u,sandybridge2u-q21', 'SBC,NXTEST', '', 'SMOKE', '$data{$suiteName}{path}', 'NONSCM', 'Any')");
    
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    
    $tTests += scalar(@{$data{$suiteName}{tests}});
#    sleep(1); 
}

print "Tests = $tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
