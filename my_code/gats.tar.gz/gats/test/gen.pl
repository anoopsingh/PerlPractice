use ATS;
use Data::Dumper;
#$ENV{TERM} = 'dump';
my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["NXTEST140"], -sessionlog =>1);

$obj->becomeUser(-userName => 'test');

my @out = $obj->{conn}->cmd(String => "find /var/opt/nextest/tdb/logs/20140127-142829/smoke/pilot_number_registration -name \"result.txt\" | xargs sed -n '/TESTS THAT DID NOT PASS/,/STATISTICS/p' | grep -e \".*: .*\"", Prompt => '/.*[\$%#\}\>] $/');

print Dumper(\@out);

$obj->{conn}->cmd( 'exit')
 
