use ATS;
use Data::Dumper;

my $gen = Genband::ATSHELPER::newFromAlias(-testbed_alias => ['BL-S1R6-VMGEN72'], -sessionlog =>1);




$gen->execLinuxCmd('ifconfig eth2 | grep "Mask:"');
my $mask = $gen->{CMDRESULTS}->[0];
$mask =~ s/.*Mask:(\S+)/$1/;

my $maskBit = ($mask eq '255.255.255.0') ? 24 :16;

my ($eth2, $eth3) = ($gen->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}, $gen->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP});

my ($eth2Nw, $eth3Nw) = ($eth2, $eth3);
$eth2Nw =~ s/(.+)\..+?$/$1/;
$eth3Nw =~ s/(.+)\..+?$/$1/;

my @patterns = ('s/automation *=.*/automation = "full"/', "s/realm_default_mask *=.*/realm_default_mask = $maskBit/", "s/realm_public_mask *=.*/realm_public_mask = $maskBit/", "s/realm_private_mask *=.*/realm_private_mask = $maskBit/", "s/mymsw_pubmed *=.*/mymsw_pubmed = \"${eth2Nw}.51\"/","s/mymsw_pubmed_mask *=.*/mymsw_pubmed_mask = \"$mask\"/", "s/mymsw_prvmed *=.*/mymsw_prvmed = \"${eth3Nw}.51\"/", "s/mymsw_prvmed_mask *=.*/mymsw_prvmed_mask = \"$mask\"/", "s/mymsw_pubmed_gw *=.*/mymsw_pubmed_gw = \"${eth2Nw}.1\"/", "s/mymsw_prvmed_gw *=.*/mymsw_prvmed_gw = \"${eth3Nw}.1\"/");

foreach (@patterns) {
    $gen->execLinuxCmd("sed -i '$_' /home/test/.nextest/userConfig.cfg");
}
