#use Genband::ATSHELPER;
use ATS;
use Data::Dumper;

my @TESTBED = (
                ['BL-E2R1-SBC19', 'BL-E2R1-SBC20'], # SBC HA pair
                'BL-S1R6-VMGEN75'
               );
		

my %testbed = Genband::ATSHELPER::resolveHashFromAliasArray( -input_array  => \@TESTBED );

print Dumper(\%testbed);

my %REQUIRED = (
                "SBC" => [2],
                "NXTEST"     => [1],
             );
unless (Genband::ATSHELPER::checkRequiredConfiguration ( \%REQUIRED, \%testbed )) {
	print "not enough resources available\n";
} else {
	print "all is well\n";
}
