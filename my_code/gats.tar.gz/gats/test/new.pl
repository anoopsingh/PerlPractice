my %pat = ( 1   =>  [   {   -prompt =>  'quit:', #Select choice by number or type q to quit:
                                -value  =>  1 #1.      Install a version of software.
                            },
                            {   -prompt =>  'license\s+terms.+?y\/n.+?:', #SDo you agree to the above license terms? [y/n]:
                                -value  =>  'y'
                            },
                            {   -prompt =>  'y\/n.+?:', # Are you sure you want to continue y/n ? [y]:
                                -value  =>  'y'
                            },
                            {   -prompt =>  'Enter.+new.+password.+iServer\s+database.+?:', # Enter a new password for the iServer database user and press <Enter>:
                                -value  =>  'shipped!!'
                            },
                            {   -prompt =>  'Retype.+password.+iServer\s+database.+?:', # Retype the password you entered for the iServer database user and press <Enter>:
                                -value  =>  'shipped!!'
                            },
                            {   -prompt =>  'Select\s+your\s+choice.*:', # Select your choice: for Is this system standalone or part of a cluster? [stand alone]:
                                -value  =>  $type
                            },
                            {   -prompt =>  'redundancy\?.+?:', # Do you want to configure a bonded control interface for redundancy? <y|[n]>:
                                -value  =>  'n'
                            },
                            {   -prompt =>  'Select\s+your\s+choice.*:', #control-interface
                                -value  =>  2
                            },
                            {   -prompt =>  'peer.+?IP\s+address.*:', #Enter peer control IP address []:
                                -value  =>  0
                            },
                            {   -prompt =>  'redundancy\s+type.+?\]:', #Enter the redundancy type for this machine: master(m)/slave(s):[m]:
                                -value  =>  0
                            },
                            {   -prompt =>  'Select\s+your\s+choice.*:', # interface-monitor-list
                                -value  =>  '0'
                            },
                            {   -prompt =>  'management\s+IP\s+address.*:', # Enter the management IP address []:
                                -value  =>  0
                            },
                            {   -prompt =>  'management\s+IPv6\s+address.*:', # Enter the management IPv6 address []:
                                -value  =>  ''
                            },
                            {   -prompt =>  'commit.+?changes.+?y\/n.+?:', #Do you want to commit the changes(y/n)? [y]:
                                -value  =>  'y'
                            },
                            {   -prompt =>  'id_rsa.+?:', #Enter file in which to save the key (/root/.ssh/id_rsa):
                                -value  =>  ''
                            },
                            {   -prompt =>  'id_rsa.+?Overwrite.+?y\/n.+?', #/root/.ssh/id_rsa already exists. Overwrite (y/n)?
                                -value  =>  'y'
                            },
                            {   -prompt =>  'Enter\s+passphrase.+?:', #Enter passphrase (empty for no passphrase):
                                -value  =>  ''
                            },
                            {   -prompt =>  'passphrase\s+again:', #Enter same passphrase again:
                                -value  =>  ''
                            },
                            {   -prompt =>  'Hit\s+\[CR\]\s+to\s+continue', #Hit [CR] to continue...
                                -value  =>  ''
                            },
                            {   -prompt =>  'quit:', #Select choice by number or type q to quit:
                                -value  =>  'q'
                            }
                        ],
                  2 =>  [   {   -prompt =>  'quit:', #Select choice by number or type q to quit:
                                -value  =>  2 #1.      Install a version of software.
                            },
                            {   -prompt =>  'uninstall\s+iServer.+?:', # Are you sure you want to uninstall iServer version 8.3.0.0  ?[y]:
                                -value  =>  'y'
                            },
                            {   -prompt =>  'backup.+?iServer\s+database.+?:', # Do you want to backup the iServer database ?[y]:
                                -value  =>  'n'
                            },
                            {   -prompt =>  'backup.+?iServer\s+configuration.+?:', # Are you sure you want to uninstall iServer version 8.3.0.0  ?[y]:
                                -value  =>  'n'
                            },
                            {   -prompt =>  'backup.+?iServer\s+license.+?:', # Do you want to backup the iServer license file ?[y]:
                                -value  =>  'n'
                            },
                            {   -prompt =>  'Hit\s+\[CR\]\s+to\s+continue', #Hit [CR] to continue...
                                -value  =>  ''
                            },
                            {   -prompt =>  'quit:', #Select choice by number or type q to quit:
                                -value  =>  'q'
                            }
                        ]
                );


for (my $index = 0; $index < scalar (@{$pat{2}}); $index++) {
	
	print "$index\n";
	next;
}
