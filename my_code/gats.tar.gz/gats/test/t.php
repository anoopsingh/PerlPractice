<?php

$a = array(1,2);

$b = array(3,4);

echo implode("','", $b);
?>
