use ATS:

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN71"], -sessionlog =>1) or die 'Failed to make connection';

$gen->execLinuxCmd('cd /home/nextest/logs/20140806-075812/production_components/');

my @results = $gen->execCmd('find -name "result.txt"');

my %resultFiles = ();
foreach my $f (@resultFiles) {
    chomp $f;
    my @path = split('/', $f);
    unless ($f =~ /provision|xit/) {
        
    }
}


