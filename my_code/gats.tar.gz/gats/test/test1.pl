use XML::Simple;
use Data::Dumper;


my $x = '<PORTALLOC vnet="Hk-Vnet1" address=<testbedata>ram</testbeddata>" mask="255.255.255.0" low="10000" high="65000" />';
$xmlData = &XMLin("$x");

print Dumper(\$xmlData);
