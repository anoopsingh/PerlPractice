use Log::Log4perl qw(get_logger :easy :levels);;

my $l = Log::Log4perl->easy_init($DEBUG);;

print $l;
