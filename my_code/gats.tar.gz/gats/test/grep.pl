my $pm = '
dfssdfds

qmtest: error: There is no test or suite with ID 
               "production_components.h323_radius.hrad_009_47790". ';


if ($pm =~ /here is no test or suite with ID/i) {
	print "hi\n";
} else {
	print "sucks\n";
}
