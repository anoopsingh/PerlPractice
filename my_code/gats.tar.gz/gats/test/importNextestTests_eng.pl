use ATS;
use Data::Dumper;


my %suiteType = ();

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["BL-S1R6-VMGEN72"], -sessionlog =>1);

$obj->{conn}->cmd('cd /var/opt/nextest/tdb/eng_test.qms');
my @result = $obj->{conn}->cmd('find -name "*.qmt" | grep --color=never -v "dsp.qms"');

chomp @result;

my %data = ();
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);
    
    my $name =  join('-', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = 'eng_test.qms/' . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    $data{$name}{type} = 'Any'; #(defined $suiteType{$temp[0]}) ? $suiteType{$temp[0]} : 'Real';
    
    print "$data{$name}{type}==\n";
}

#print Dumper(\%data);

my $tTests = 0;
my $anyTest = 0;

foreach my $suiteName (keys %data) {
    my $suiteId = &getUUID();
    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.3.0,V8.3.1,V8.3.2', 'sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'NEXUNIT', '$data{$suiteName}{path}')\n";
    
    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','SBC', 'V8.1.1,V8.2.1,V8.3.0,V8.3.1,V8.3.2,V8.4.0,V9.0.0,V9.1.0', 'annapolis,jarell,sandybridge1u,sandybridge2u', 'SBC,NXTEST', '', 'NEXUNIT', '$data{$suiteName}{path}', 'NONSCM', '$data{$suiteName}{type}')");
    
    #print "INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')\n";
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    
    $anyTest += scalar(@{$data{$suiteName}{tests}}) if ($data{$suiteName}{type} eq 'Any');
    $tTests += scalar(@{$data{$suiteName}{tests}});
    
}

print "$anyTest = $tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
