use Genband::Installer;
use strict;
#$ENV{TERM} = 'dump';
my %args = ( -location => 'BL', -build => 'V8.3.2.4', -sbcs => ['BL-E2R1-SBC9','BL-E2R1-SBC10']);

unless (&Genband::Installer::installSbc(%args)) {
	print "Failed to install \'$args{-build}\'\n";
} else {
	print "successfully installed \'$args{-build}\'\n";
}
