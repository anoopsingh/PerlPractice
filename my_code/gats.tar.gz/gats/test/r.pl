my $str = 'Voice-Message: 1/4(1/0)';


if ($str =~ /(.*)\((.*)/) {
	print "$1 ($2\n";
} else {
	print "no\n";
}
