

&editMdeviceFile("/gats/perf/tests/124_temp/mdevices.xml");


sub editMdeviceFile {
    my $mdevice = shift;
    
    my $newFile = $mdevice;
    unless ( system ( "cp $mdevice  ${mdevice}_back") == 0 ) {
        die "Could not create user log directory in $user_home_dir/ ";
    }
    
    $mdevice = "${mdevice}_back";
    unless (open ( my $fh, '<', $mdevice)) {
        print "Perf::sbcPerf - ERROR ->failed to open \'$mdevice\' -> $!\n";
        return 0;
    }
    
    unless (open ( my $newFh, '>', $newFile)) {
        print "Perf::sbcPerf - ERROR ->failed to open \'$newFile\' -> $!\n";
        return 0;
    }
    foreach my $line (<$fh>) {
        unless ($line =~ /\<\s*testbeddata\s*\>/) {
            print $newFh $line;
            next;
        }
        my @temp = split(/\<\s*testbeddata\s*\>.*?\<\/\s*testbeddata\s*\>/, $line);
        my $pat = '';
        my $newLine = '';
        my @values = ();
        map {$pat .= '.*?<\s*testbeddata\s*\>(.*?)\<\/\s*testbeddata\s*\>.*?'} 0..($#temp-1);
        
        unless ($line =~ /$pat/) {
            print "Perf::sbcPerf - ERROR -> did not match the expected pattern \"$pat\"\n";
            return 0;
        }
        map {push (@values, ${$_+1})} 0..($#temp-1);
        
        map {($_ < $#temp) and $newLine .= "$temp[$_]$values[$_]"} 0..$#temp;
        print "Perf::sbcPerf - prepared line is \"$newLine\"\n";
        print $newFh "$newLine\n";
    }
    
    close $fh;
    close $newFh;
    return 1;
}
