use ATS;
use Date::Parse;
use Data::Dumper;
#$ENV{'TERM'} = 'dump';
my $ssh = Genband::Base->new(
                                                -obj_host => "172.23.61.4",
                                                -obj_user => 'root',
                                                -obj_password => 'shipped!!',
-return_on_fail => 1,
                                                -comm_type => "SSH", -sessionlog => 1);




#$ssh = Genband::Base->new(
#                                                -obj_host => "172.23.107.19",
#                                                -obj_user => 'root',
#                                                -obj_password => 'shipped!!',
#                                                -comm_type => "SSH", -sessionlog => 1);

#my $buildCmd = q(gis -v| grep GIS|sed 's/.*Server\s*//'|awk -F , {'print $1'}|sed 's/v//');
#my $buildCmd = q(df -kh .);
#my $buildCmd = q(ps -ef |grep qmtest |grep -v grep);
#my $buildCmd = q(lstat);
##my $buildCmd = q(ls -l /var/opt/nextest| grep ^l);
#$ssh->execLinuxCmd($buildCmd);
#$lct1 = $ssh->{CMDRESULTS}->[1];
#if($lct1 =~ /^License Expiry Date\s+(.*)/) {
#    print "hhaaaaaa$1\n";
#}
#$time = $1;
#$op = $ssh->{CMDRESULTS}->[0];
#my $buildCmd = q(date +"%a %b %d %T %Y");
##my $buildCmd = q(ls -l /var/opt/nextest| grep ^l);
#$ssh->execLinuxCmd($buildCmd);
#$lct2 = $ssh->{CMDRESULTS}->[0];

#print "time license $time\n";
#print "time dutxxxx $lct2\n";

#my $t1 = str2time("$time");
#my $t2 = str2time("$lct2");
#print "t111111111 $t1\n";
#print "t22222222222 $t2\n";

#if($t1>$t2){
#print "T1 is greater";
#}else{
#print "T2 is greater";
#}
##
##$ssh->execLinuxCmd("mkdir -p /home/test/anoopresultDirectory");
#$ssh->execLinuxCmd("mkdir -p /home/test/anoopresultDirectory/results");
#$ssh->execLinuxCmd("chown -R test:users /home/test/anoopresultDirectory");
#$ssh->execLinuxCmd("chown -R test:users /home/test/anoopresultDirectory/results");
#$ssh->execLinuxCmd("su - test ;cd /home/test/anoopresultDirectory; /opt/nextest/bin/qmtest run  -c nextest.scm_configuration=ON -c nextest.trace_level=DEBUG -c nextest.disable_debugflags=OFF -c nextest.radius_verify=OFF -o /home/test/anoopresultDirectory/results_provision.qmr /home/test/anoopresultDirectory/production_components.provision");
# my $scpCmd = "scp $resultDir/$resultFile root\@172.23.54.205:/$regResultDir/";

#$ssh->scpFile( -scpCmd => $scpCmd,  -password => 'shipped!!');
#exit;
#my $buildCmd = q(su test;);
#$ssh->execLinuxCmd($buildCmd);
#$regExecDir = '/home/test/anoop_test111';
#my $cmd = "mkdir -p /home/test/anoop_1test1111";
#my $buildCmd = q(ssh root@mymsw);
#$ssh->execLinuxCmd($cmd);
#$ssh->execLinuxCmd("cd /home/test/anoop_1test1111");
##my $buildCmd = q(ssh root@bkupmsw);
##$ssh->execLinuxCmd($buildCmd);
##$ssh->execLinuxCmd("exit");
#my $arg = 'production_components.provision';
#my $buildCmd = "/opt/nextest/bin/qmtest run  -c nextest.scm_configuration=ON -c nextest.trace_level=DEBUG -c nextest.disable_debugflags=OFF -c nextest.radius_verify=OFF -o results_provision.qmr $arg";
#$ssh->execLinuxCmd($buildCmd);

#my $buildCmd = q(ssh root@mymsw ls -l /var/core | wc -l);
#$ssh->execLinuxCmd($buildCmd);
#$ssh->execLinuxCmd("date -s \"Tue Dec 17 03:04:07 EST 2013\"");
#print "\n core count is.........";
#print $ssh->{CMDRESULTS}->[0];
#print "core count is.........\n";
#my $checkRegCmd = q(ls -l /var/opt/nextest| grep ^l);
#$ssh->execLinuxCmd($checkRegCmd);
#my $ref = ref($ssh->{CMDRESULTS});
#print "hhhhhhhhhhhh ref type is $ref";
#print $ssh->{CMDRESULTS}->[0]. "\n";
#if ( $ssh->{CMDRESULTS}->[0] =~ /(.*) tdb -> (.*)/ ) {
#   print "nexttest version is $2";
#}

#my $op = $ssh->{CMDRESULTS}->[0];
#if ( $op =~ /(.*)pci0(.*)UP BROADCAST RUNNING MULTICAST(.*)/ ) {
#     print "Media connectiviyt is up $3\n";
#} 
