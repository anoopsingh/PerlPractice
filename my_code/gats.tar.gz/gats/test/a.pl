my $su = 'ramesh.pateel.perl';

$su =~ s/(.*)\..+?$/$1/;

print "$su\n";
