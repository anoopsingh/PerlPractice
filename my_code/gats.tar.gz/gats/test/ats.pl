use ATS;
use Data::Dumper;
#$ENV{TERM} = 'dump';
my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ['BL-S1R6-SBC31'], -sessionlog =>1);


#my @r = $obj->execCmd('grep "PS1" .bashrc');
print "hi\n" if $obj->restartAll();
