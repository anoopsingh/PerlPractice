use strict;
use threads;
use ATS;
use Benchmark qw(:hireswallclock);


use Log::Log4perl qw(get_logger :easy :levels);;

my ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
my $timestamp = sprintf "%4d%02d%02d-%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
 
my $startTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
 

 
my $layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss.SSS}.%-8p %32.33C{3} : %X{ip} %m%n");
# Simplified layout for screen
my $screen_layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss}: %X{ip} %m%n");
 
# Override default easy init logging for Base 
# connections
 
my $ats_logger        = get_logger("Genband");
my $reg_execution_logger  = get_logger("Scripts");
$ats_logger->additivity(0);
$reg_execution_logger->additivity(0);

# Create the ATS appender and point it to a log file
my $ats_file_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "RegRun.log",
        name => "AutomationLog",
);

 
# Create a second test case appender and point it to the screen 
my $test_case_screen_appender = Log::Log4perl::Appender->new(
        "Log::Dispatch::Screen",
        name => "screen",
);
 
# Add appenders to the appropriate logger 
$ats_logger->add_appender($ats_file_appender);
$ats_logger->add_appender($test_case_screen_appender);
$reg_execution_logger->add_appender($test_case_screen_appender);
 
# Configure the appenders with the layout we've defined
$ats_file_appender->layout($layout);
$test_case_screen_appender->layout($screen_layout);
 
my $starttime = Benchmark->new;
my $finishtime;
my $timespent;
my $num_of_threads = 2;
 
my @threads = initThreads();
my $k = 0;
my @n = ('Ram', 'Malc');
foreach(@threads){
        Log::Log4perl::MDC->put("ip", $n[$k]);
        Genband::Utils::changeLogFile(-appenderName => "AutomationLog", -newLogFile => $n[$k++] . ".log");
        $_ = threads->create(eval {\&doOperation});
        
}

print "Executing ==== \n";

foreach(@threads){
   my $temp =  $_->join();
   print "eval out =" . $_->error() . "=\n";
   print "$temp = temp\n";
}
$finishtime = Benchmark->new;
$timespent = timediff($finishtime,$starttime);
print "\nDone!\nSpent ". timestr($timespent);
 
print "\n\nNow trying without threading:\n\n";
 
my $starttime = Benchmark->new;

&test();
&test(); 
 
$finishtime = Benchmark->new;
$timespent = timediff($finishtime,$starttime);

select(STDOUT);
print "\nDone!\nSpent ". timestr($timespent);
print "\nProgram Done!\nPress Enter to exit";

$a = <>;
 
sub initThreads{
    my @initThreads;
    for(my $i = 1;$i<=$num_of_threads;$i++){
        push(@initThreads,$i);
    }
    return @initThreads;
}

sub doOperation{
    # Get the thread id. Allows each thread to be identified.
    my $id = threads->tid();
    #die "im dead\n";
    my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["NXTEST6"], -sessionlog =>1);
    print "Thread $id done!\n";
    &ram();
    # Exit the thread
#    threads->exit();
    return 10;
}

sub ram {
   sleep 10;
   my $id = threads->tid();
   print "thread $id\n";
}

sub test {
    sleep 10;
    my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => ["NXTEST6"], -sessionlog =>1);
}


