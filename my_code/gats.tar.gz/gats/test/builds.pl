use Genband::Utils;
use Data::Dumper;

my $builds = &Genband::Utils::executeSqlCmd("select * from builds");


foreach my $row (@{$builds}) {
    my $id = &getUUID();
    print "update builds set build_uuid = '$id' where elementType='$row->[1]' and build='$row->[2]' limit 1\n";
    &Genband::Utils::executeSqlCmd("update builds set build_uuid = '$id' where elementType='$row->[1]' and build='$row->[2]' limit 1");
}

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
