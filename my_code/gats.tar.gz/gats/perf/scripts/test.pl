$callDuration = 123;
my $count = int($callDuration/60);
    my $oddSeconds = $callDuration%60;



print "$count=$oddSeconds";

