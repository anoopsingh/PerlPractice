
# Parameters Passed
tmp=$1 

bios=`cat $tmp/sysInfo.log | grep BIOS | awk '{print $2}' | head -1`
os=`cat $tmp/sysInfo.log | grep "^OS:" | awk '{print $2}'| head -1`
hk=`cat $tmp/sysInfo.log | grep HK | awk '{print $2}' | head -1`
sbc=`cat $tmp/sysInfo.log | grep "SBC:" | awk '{print $2}' | head -1`
#flag=`cat $tmp/sysInfo.log | grep Flag | awk '{print $2}'`
flag=$2

echo "set label ""\"TEST:                             ${flag}""\" at graph .01,.98 left" >> $tmp/pcputoplot
echo "set label ""\"SBC Release Version:     ${sbc^^}""\" at graph .01,.94 left" >> $tmp/pcputoplot
echo "set label ""\"BIOS Version:                ${bios}""\" at graph .01,.90 left" >> $tmp/pcputoplot
echo "set label ""\"OS Version:                    ${os}""\" at graph .01,.86 left" >> $tmp/pcputoplot
echo "set label ""\"HK:                                 ${hk}""\" at graph .01,.82 left" >> $tmp/pcputoplot
