#!/bin/bash

# Define Local Variables
tmp=$1
testId=$2
#pcpu=$2 vermem=$3 mem=$4 cpu=$5
vermem='vermem.png'
mem='memory.png'
cpu='pcpu.png'

rm -f $tmp/pcputoplot*
rm -f $tmp/memtoplot*
rm -f $tmp/verMemtoplot*
rm -f $tmp/pcpu-*
rm -rf $tmp/ver-*
rm -rf $tmp/mem-*


rm -f $tmp/timeStamp*

# Script Plots the Process(gis) per CPU for Active and Standby SBX

# Get Sample Size and Setup Timers
size=`cat $tmp/pcpu.log | grep ^Cpu | wc -l`
/gats/perf/scripts/gnu/setTime.sh 20 $size $tmp > $tmp/timeStamp

size=`cat $tmp/pcpu2.log | grep ^Cpu | wc -l`
/gats/perf/scripts/gnu/setTime.sh 20 $size $tmp > $tmp/timeStamp2

xrangeStart=`cat $tmp/timeStamp | head -1`
xrangeStop=`cat $tmp/timeStamp | tail -1`
samplesize=`cat $tmp/timeStamp | wc -l`
plotsize=$(echo "$samplesize *30 / 16" |bc -l)

echo $xrangeStart
echo $xrangeStop

# Sets Up Graph with GNUPLOT
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1900,400" >> $tmp/verMemtoplot
echo "set output '$tmp/${vermem}'" >> $tmp/verMemtoplot
echo "set xdata time;" >> $tmp/verMemtoplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/verMemtoplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/verMemtoplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/verMemtoplot
echo "set format x \"%r\";" >> $tmp/verMemtoplot
echo "set yrange [0:*];" >> $tmp/verMemtoplot
#echo "set ytics 1000;" >> $tmp/verMemtoplot
echo 'set xlabel "TIME";' >> $tmp/verMemtoplot
echo 'set ylabel "Vertiual Memory Consumption/MB";'  >> $tmp/verMemtoplot
echo "set grid;" >> $tmp/verMemtoplot
#echo "set key outside" >> $tmp/verMemtoplot
echo "set label ""\"Gis Virtual  memory  Usage""\" at graph .5,0.98 center" >> $tmp/verMemtoplot


# for %mem usage
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1900,400" >> $tmp/memtoplot
echo "set output '$tmp/${mem}'" >> $tmp/memtoplot
echo "set xdata time;" >> $tmp/memtoplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/memtoplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/memtoplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/memtoplot
echo "set format x \"%r\";" >> $tmp/memtoplot
echo "set yrange [0:*];" >>$tmp/memtoplot
#echo "set ytics 10;" >> $tmp/memtoplot
echo 'set xlabel "TIME";' >> $tmp/memtoplot
echo 'set ylabel "% mem Utilization";'  >> $tmp/memtoplot
echo "set grid;" >> $tmp/memtoplot
#echo "set key outside" >> $tmp/memtoplot
echo "set label ""\"Gis MEM Usage""\" at graph .5,0.98 center" >> $tmp/memtoplot

#for cpu usage
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1900,400" >> $tmp/pcputoplot
echo "set output '$tmp/${cpu}'" >> $tmp/pcputoplot
echo "set xdata time;" >> $tmp/pcputoplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/pcputoplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/pcputoplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/pcputoplot
echo "set format x \"%r\";" >> $tmp/pcputoplot
echo "set grid;" >> $tmp/pcputoplot
echo "set yrange [0:*];" >> $tmp/pcputoplot
#echo "set ytics 10;" >> $tmp/pcputoplot
echo 'set xlabel "TIME";' >> $tmp/pcputoplot
echo 'set ylabel "CPU Utilization";'  >> $tmp/pcputoplot
echo "set grid;" >> $tmp/pcputoplot
#echo "set key outside" >> $tmp/pcputoplot
echo "set label ""\"Gis CPU Usage""\" at graph .5,0.98 center" >> $tmp/pcputoplot

# Retrieves hostname for active and standby SBX
activeHost=`cat $tmp/mpstat.log | grep "(" | awk  '{print $3}'`
standbyHost=`cat $tmp/mpstat2.log | grep "(" | awk '{print $3}'`

/gats/perf/scripts/gnu/sysInfo.sh $tmp $testId

pcpuLogs=('pcpu.log' 'pcpu2.log')
for i in "${pcpuLogs[@]}"; do
    if [ "$i" == 'pcpu.log' ]; then
	    host=$activeHost
		timestmp="timeStamp"
		ce="active"
    else
 	    host=$standbyHost
		timestmp="timeStamp2"
		ce="standby"
    fi
    cat $tmp/$i | grep " gis " | awk '{print $5}' | sed s/m// > $tmp/ver-$ce
    cat $tmp/$i | grep " gis " | awk '{print $10}' > $tmp/mem-$ce
    cat $tmp/$i | grep " gis " | awk '{print $9}'  > $tmp/pcpu-$ce
    paste $tmp/$timestmp $tmp/ver-$ce > $tmp/ver-memdata-$ce
    paste $tmp/$timestmp $tmp/mem-$ce > $tmp/memdata-$ce
    paste $tmp/$timestmp $tmp/pcpu-$ce > $tmp/pcpudata-$ce
    echo "\"$tmp/ver-memdata-$ce\" using 1:3 with linespoints title '$host', \\" >> $tmp/verMemtoplot
    echo "\"$tmp/memdata-$ce\" using 1:3 with linespoints title '$host', \\" >> $tmp/memtoplot
    echo "\"$tmp/pcpudata-$ce\" using 1:3 with linespoints title '$host', \\" >> $tmp/pcputoplot
done

#paste -d , $tmp/timeStamp $tmp/pcpu-active $tmp/pcpu-standby $tmp/mem-active $tmp/mem-standby $tmp/ver-active $tmp/ver-standby >$tmp/stats1.csv

cat $tmp/verMemtoplot | sed '13 s/"/plot "/' | sed '14 s/, \\//' > $tmp/verMemtoplot.fixed
cat $tmp/memtoplot | sed '13 s/"/plot "/' | sed '14 s/, \\//' > $tmp/memtoplot.fixed
cat $tmp/pcputoplot | sed '19 s/"/plot "/' | sed '20 s/, \\//'  > $tmp/pcputoplot.fixed
/usr/bin/gnuplot $tmp/verMemtoplot.fixed
/usr/bin/gnuplot $tmp/memtoplot.fixed
/usr/bin/gnuplot $tmp/pcputoplot.fixed

# Remove Files After Plotters Finished
rm -f $tmp/pcputoplot*
rm -f $tmp/memtoplot*
rm -f $tmp/verMemtoplot*
rm -f $tmp/timeStamp*
rm -f $tmp/*memdata*
#rm -f $tmp/pcpu-*
#rm -rf $tmp/ver-*
#rm -rf $tmp/mem-*

