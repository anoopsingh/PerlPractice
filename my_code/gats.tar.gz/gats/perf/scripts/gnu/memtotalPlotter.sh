#!/bin/bash

# Define Local Variables
tmp=$1

rm -f $tmp/activeMEM
rm -f $tmp/standbyMEM
rm -f $tmp/timeStamp*
rm -f $tmp/totaltoplot*

# Description of memtotalPlotter.sh 
# Script Graphs Overall Memory For Both Active and Standby SBX

# Gets Sample Size and Sets up Timers
size=`cat $tmp/totalmem.log | wc -l`
/gats/perf/scripts/gnu/setTime.sh 20 $size $tmp > $tmp/timeStamp
size=`cat $tmp/totalmem2.log | wc -l`
/gats/perf/scripts/gnu/setTime.sh 20 $size $tmp > $tmp/timeStamp2

xrangeStart=`cat $tmp/timeStamp | head -1`
xrangeStop=`cat $tmp/timeStamp | tail -1`
samplesize=`cat $tmp/timeStamp | wc -l`
plotsize=$(echo "$samplesize *30 / 16" |bc -l)

activeHost=`cat $tmp/mpstat.log | grep "(" | awk  '{print $3}'`
standbyHost=`cat $tmp/mpstat2.log | grep "(" | awk '{print $3}'`

# Sets up Graph with GNUPLOT
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1900,400" >> $tmp/totaltoplot
echo "set output '$tmp/totalmem.png'" >> $tmp/totaltoplot
echo "set xdata time;" >> $tmp/totaltoplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/totaltoplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/totaltoplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/totaltoplot
echo "set format x \"%r\";" >> $tmp/totaltoplot
echo "set grid;" >> $tmp/totaltoplot
echo 'set xlabel "TIME";' >> $tmp/totaltoplot
echo 'set ylabel "% Memory Utilization";' >> $tmp/totaltoplot
echo "set autoscale;" >> $tmp/totaltoplot
echo "set label ""\"System Memory Usage""\" at graph .5,0.98 center" >> $tmp/totaltoplot


# MemTotal for Active & Standby SBC
array=('totalmem.log' 'totalmem2.log')
for i in "${array[@]}"; do
    for x in `cat $tmp/$i`; do
	mem=$(echo "$x * 100" | bc -l ) 
	if [ "$i" == 'totalmem.log' ]; then
            echo "$mem" >> $tmp/sm-active
	else
            echo "$mem" >> $tmp/sm-standby
	fi
    done    
    if [ "$i" == 'totalmem.log' ]; then
        paste $tmp/timeStamp $tmp/sm-active > $tmp/activeMEM
    else
        paste $tmp/timeStamp2 $tmp/sm-standby > $tmp/standbyMEM
    fi
done

#paste -d , $tmp/stats1.csv $tmp/sm-active $tmp/sm-standby >$tmp/stats2.csv
# Get the low point of memory usage overall
#cat $tmp/sm-active | awk 'NR==20,NR==100'  |  sort | awk 'NR==1' > $tmp/memlow.log

echo "plot \"$tmp/activeMEM\" using 1:3 with linespoints title '$activeHost', \\" >> $tmp/totaltoplot
echo "\"$tmp/standbyMEM\" using 1:3 with linespoints title '$standbyHost'" >> $tmp/totaltoplot
/usr/bin/gnuplot $tmp/totaltoplot

# Remove Files After Plotters Finished
#rm -f $tmp/active*
#rm -f $tmp/standby*
rm -f $tmp/activeMEM
rm -f $tmp/standbyMEM
rm -f $tmp/timeStamp*
rm -f $tmp/totaltoplot*


