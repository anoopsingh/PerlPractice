#!/bin/bash

# Define Local Parameters
tmp=$1 

rm -f $tmp/timeStamp*
rm -f $tmp/active*
rm -f $tmp/standby*
rm -f $tmp/toplot*

# Description of cpuPlotter.sh
# Graphs Data for CPU and Calls for Duration of Test Both Active and Standby

# Gets the sample size of mpstat.log and sets up the timer
size=`cat $tmp/mpstat.log | grep --binary-files=text all | awk '{ print $11 }' | wc -l`
size2=`cat $tmp/mpstat2.log | grep --binary-files=text all | awk '{ print $11 }' | wc -l`
/gats/perf/scripts/gnu/setTime.sh 20 $size $tmp > $tmp/timeStamp
/gats/perf/scripts/gnu/setTime.sh 20 $size2 $tmp > $tmp/timeStamp2

# Retrieves hostname for active and standby SBX
activeHost=`cat $tmp/mpstat.log | grep "(" | awk  '{print $3}'`
standbyHost=`cat $tmp/mpstat2.log | grep "(" | awk '{print $3}'`

# Defines Ranges for Start and Stop on Graph
xrangeStart=`cat $tmp/timeStamp | head -1`
xrangeStop=`cat $tmp/timeStamp | tail -1`
samplesize=`cat $tmp/timeStamp | wc -l`
plotsize=$(echo "$samplesize *30 / 16" |bc -l)

# Sets Up Graph with GNUPLOT
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1890,390" >> $tmp/toplot
echo "set output '$tmp/cpu.png'" >> $tmp/toplot
echo "set xdata time;" >> $tmp/toplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/toplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/toplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/toplot
echo "set format x \"%r\";" >> $tmp/toplot
#echo "set ytics 10;" >> $tmp/toplot
echo "set grid;" >> $tmp/toplot
echo 'set xlabel "TIME";' >> $tmp/toplot
echo 'set ylabel "CPU %";' >> $tmp/toplot
echo "set autoscale;" >> $tmp/toplot
echo "set yrange [0:*];" >> $tmp/toplot


# Check to find which column is idle
idle=`cat $tmp/mpstat.log | grep "CPU" | head -2 | tail -1 | awk '{print $12}'`
if [ "$idle" == '%idle' ]; then
    awk='$12'
else 
    awk='$11'
fi

# Active & Standby Overall CPU Plot
array=('mpstat.log' 'mpstat2.log')
for i in "${array[@]}"; do
    cat $tmp/$i | grep --binary-files=text all | awk "{print $awk}" > $tmp/cpuData
    for x in `cat $tmp/cpuData`; do
        result=$(echo "100 - $x" |bc -l)
        if [ "$i" == 'mpstat.log' ]; then
            echo $result >> $tmp/sc-active
        else
            echo $result >> $tmp/sc-standby
        fi
    done
    if [ "$i" == 'mpstat.log' ]; then
        paste $tmp/timeStamp $tmp/sc-active > $tmp/activeCPU
    else
        paste $tmp/timeStamp2 $tmp/sc-standby > $tmp/standbyCPU
    fi
    rm $tmp/cpuData
done

#echo "TimeStamp,Gis CPU Usage %(Active),Gis CPU Usage %(Standby),Gis  Mem  Usage %(Active),Gis  Mem  Usage %(Standby),Gis Virtual  memory Usage (Active),Gis Virtual  memory Usage (Standby),Free Memoryin GB (Active),Free Memoryin GB (Standby),System CPU Usage %(Active),System CPU Usage %(Standby)" >$tmp/stats.csv
#paste -d , $tmp/stats2.csv $tmp/sc-active $tmp/sc-standby >>$tmp/stats.csv

echo "plot \"$tmp/activeCPU\" using 1:3 with linespoints title '${activeHost}', \\" >> $tmp/toplot
echo "\"$tmp/standbyCPU\" using 1:3 with linespoints title '${standbyHost}' \\" >> $tmp/toplot
/usr/bin/gnuplot $tmp/toplot

# Remove Files After Plotters Finished
#rm -f $tmp/timeStamp*
rm -f $tmp/activeCPU
rm -f $tmp/standbyCPU
rm -f $tmp/toplot*
#rm -f $tmp/stats2.csv
#rm -f $tmp/stats1.csv




