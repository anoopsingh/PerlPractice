#!/bin/bash

# Define Local Variables
tmp=$1 mpstat=$2 corecpu=$3

rm -f $tmp/timeStamp*
rm -f $tmp/core.data*
rm -f $tmp/core.toplot*
rm -f $tmp/coreCPU.* 

# Description of corePlotter.sh 
# Script Plots the Per-Core CPU for Active and Standby SBX

#Gets the sample size of mpstat.log and sets up the timer
size=`cat $tmp/$mpstat | grep --binary-files=text "     0" | awk '{ print $11 }' | wc -l`
/gats/perf/scripts/gnu/setTime.sh 30 $size $tmp > $tmp/timeStamp
xrangeStart=`cat $tmp/timeStamp | head -1`
xrangeStop=`cat $tmp/timeStamp | tail -1`
samplesize=`cat $tmp/timeStamp | wc -l`
plotsize=$(echo "$samplesize *30 / 16" |bc -l)

# Sets Up Graph with GNUPLOT
echo "set terminal png font '/usr/share/fonts/truetype/arial.ttf' 9.5 size 1890,390" >> $tmp/core.toplot
echo "set output '$tmp/${corecpu}'" >> $tmp/core.toplot
echo "set xdata time;" >> $tmp/core.toplot
echo "set timefmt \"%m/%d/%y %H:%M:%S:\";" >> $tmp/core.toplot
echo "set xrange [\"${xrangeStart}\":\"${xrangeStop}\"];" >> $tmp/core.toplot
echo "set xtics \"${xrangeStart}\",${plotsize},\"${xrangeStop}\" " >> $tmp/core.toplot
echo "set format x \"%r\";" >> $tmp/core.toplot
echo "set grid;" >> $tmp/core.toplot
echo "set ytics 10;" >> $tmp/core.toplot
echo 'set xlabel "TIME";' >> $tmp/core.toplot
echo 'set ylabel "CPU % Per Core";' >> $tmp/core.toplot
echo "set autoscale;" >> $tmp/core.toplot
echo "set yrange [0:100];" >> $tmp/core.toplot

# Check to see which column %idle is in 
idle=`cat $tmp/$mpstat | grep "CPU" | head -2 | tail -1 | awk '{print $12}'`
if [ "$idle" == '%idle' ];then
    awk='$12'
else
    awk='$11'
fi

if [ "$mpstat" == 'mpstat.log' ]; then
    cores=`cat $tmp/sysInfo.log | grep "CPU Core" | awk '{print $3}'`
else
    cores=`cat $tmp/sysInfo2.log | grep "CPU Core" | awk '{print $3}'`
fi

for ((i=0; i <= $cores-1; i++)); do
    for b in `cat $tmp/$mpstat | grep --binary-files=text "     $i" | awk "{print $awk}"`; do
        result=$(echo "100-$b" |bc -l)
        echo "$result" >> $tmp/core.data${i}
    done
    paste $tmp/timeStamp $tmp/core.data${i} > $tmp/coreCPU.data${i}
done 

echo "plot \"$tmp/coreCPU.data0\" using 1:3 with linespoints title 'core0', \\" >> $tmp/core.toplot
for ((i=1; i <= $cores-2; i++)); do
    echo "\"$tmp/coreCPU.data${i}\" using 1:3 with linespoints title 'core{$i}', \\" >> $tmp/core.toplot
done

i=`expr $cores - 1`
echo "\"$tmp/coreCPU.data${i}\" using 1:3 with linespoints title 'core{$i}'">> $tmp/core.toplot


/usr/bin/gnuplot $tmp/core.toplot

# Remove Files After Plotters Finished
#rm -f $tmp/timeStamp*
#rm -f $tmp/core.data*
#rm -f $tmp/core.toplot*
#rm -f $tmp/coreCPU.* 
