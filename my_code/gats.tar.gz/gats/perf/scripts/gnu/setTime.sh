#!/bin/bash

# Parameters Passed
x=$1 size=$2 tmp=$3

time2=`cat $tmp/sysInfo.log |grep "Current Date"| awk '{print $3}'`
h=`cat $tmp/pcpu.log | grep "load average" | head -1 | awk '{print $3}'`
sec=30
timer=0

while [ $timer -ne $size ]
do
echo `date -d "${time2} ${h} $time seconds" +"%D	%H:%M:%S"`
time=$(($time + $x))
timer=$[${timer}+1]
done
