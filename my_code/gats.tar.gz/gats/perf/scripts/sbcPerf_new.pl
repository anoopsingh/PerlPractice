#!/gats/bin/perl
#############################################################
#
# Genband US LLC,
#
# All Rights Reserved.
# Confidential and Proprietary.
#
# Module Name:  sbcPerf.pl
#
# Module Description:
# This script automates Performance Testing
# 
# Author: Ramesh Pateel (Ram)
#
#############################################################
our (%TESTBED);

use ATS;
#use strict;
use Genband::Utils;
use Genband::PERF::PerfUtils;
use Genband::PERF::PerfNxTest;
use Log::Log4perl qw(get_logger :easy);
use Data::Dumper;

my %cmdLineArguements=@ARGV;	#takes arguments from commandline
$SIG{INT} = \&handleControlC;

#print Dumper(\%cmdLineArguements);
if(defined($cmdLineArguements{'-h'})){# NEED HELP?
    &usage();
}
if (!defined($cmdLineArguements{'-id'}) or !$cmdLineArguements{'-id'}){# DO WE HAVE THE ARGUMENT?
    &usage();
}

my $perfJobID = $cmdLineArguements{'-id'};

# Create timestamp for automation run logs
my ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
my $timestamp = sprintf "%4d%02d%02d-%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;

my $startTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
my $endTime = '';

my $log_dir = "/gats/perf/logs";

my $layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss.SSS}.%-8p %32.33C{3} : %m%n");
# Simplified layout for screen
my $screen_layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss}: %m%n");

# Override default easy init logging for Base 
# connections

my $ats_logger        = get_logger("Genband");
my $test_case_logger  = get_logger("Scripts");
$ats_logger->additivity(0);
$test_case_logger->additivity(0);

# Create the ATS appender and point it to a log file
my $ats_file_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "$log_dir/PerfRun.log",
        name => "AutomationLog",
);

# Create the test case appender and point it to a log file
my $test_case_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "$log_dir/PerfRun.log",
        name => "TestRunLog",
);

# Create a second test case appender and point it to the screen 
my $test_case_screen_appender = Log::Log4perl::Appender->new(
        "Log::Dispatch::Screen",
        name => "screen",
);

# Add appenders to the appropriate logger 
$ats_logger->add_appender($ats_file_appender);
$ats_logger->add_appender($test_case_screen_appender);
$test_case_logger->add_appender($test_case_screen_appender);
$test_case_logger->add_appender($test_case_appender);

# Configure the appenders with the layout we've defined
$ats_file_appender->layout($layout);
$test_case_appender->layout($layout);
$test_case_screen_appender->layout($screen_layout);

# Set logging levels
$ats_logger->level($DEBUG);
$test_case_logger->level($DEBUG);


my ($jobData, $testData, $testBedData, $externalBody);

unless ($jobData = &Genband::Utils::executeSqlCmd("SELECT loadJob_testbedtopologyuuid, loadJob_testcaseuuid, loadJob_username, loadJob_release, loadJob_platform, loadJob_duration, loadJob_build, loadJob_callrate, loadJob_callholdtime, loadJob_bulkconf FROM loadJob where loadJob_uuid = \'$perfJobID\'")) {
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get job details for jobid - \'$perfJobID\'");
}

unless ($testBedData = &Genband::Utils::executeSqlCmd("SELECT testbedtopology_testbedelements, testbedtopology_otherTestbedelements, testbedtopology_location FROM testbedtopology where testbedtopology_uuid = \'$jobData->[0]->[0]\'")) {    
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get testbed topology details for jobid - \'$perfJobID\'");
}

unless ($testData = &Genband::Utils::executeSqlCmd("SELECT loadtest_testcaseid, loadtest_name, loadtest_requiredelements FROM loadtest where loadtest_uuid = \'$jobData->[0]->[1]\'")) {
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get testcase details for jobid - \'$perfJobID\'");
}

my $topologyID = $jobData->[0]->[0];
my $testId =  $testData->[0]->[0];  
my $testName = $testData->[0]->[1];
my $platform = $jobData->[0]->[4];
my $release = $jobData->[0]->[3];
my $userName = $jobData->[0]->[2];

my $callDuration = $jobData->[0]->[5];
my $build = $jobData->[0]->[6];

my $callRate = $jobData->[0]->[7];
my %callRates = ();
my $totalCallRate = 0;

my @tempcallRate = split(',', $callRate);
foreach (@tempcallRate) {
    my @tbnRate = split(/:/, $_);
    $callRates{$tbnRate[0]} = $tbnRate[1];
    $totalCallRate += $tbnRate[1];
}

my $callHoldTime = $jobData->[0]->[8];
my @tempcallhold = split(',', $callHoldTime);
my %callHoldTimes = ();
my $maxCallHoldTime = 0;
foreach (@tempcallhold) {
    my @tbnRate = split(/:/, $_);
    $callHoldTimes{$tbnRate[0]} = $tbnRate[1]*1000;
    $maxCallHoldTime = $tbnRate[1] if ($maxCallHoldTime < $tbnRate[1]);
}

my $bulkConfig = $jobData->[0]->[9];


$log_dir .= "/$userName/$testId/$timestamp";
my $webDir = "/srv/www/vhosts/gensmart/performance/$userName/$testId/$timestamp/";
my $url = "http://172.23.54.205/performance/$userName/$testId/$timestamp/";
my $testDir = "/gats/perf/test/${testId}_${testName}/";
my $userData = '';
unless ($userData = &Genband::Utils::executeSqlCmd("SELECT emailId FROM users where userName = \'$userName\'")) {
    &testFailed('Failed', "failed to get user details for - \'$userName\'");
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get user details for - \'$userName\'");
}

my $mail = $userData->[0]->[0];

unless ( system ( "mkdir -p $log_dir/" ) == 0 ) {
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => '', -status => 'Failed', -externalBody => "Could not create user log directory \"$log_dir\" for jobid - \'$perfJobID\'", -log_dir => $log_dir, -testName => $testName, -testId => $testId);
    $test_case_logger->logdie("Perf::sbcPerf - ERROR -> Could not create user log directory in $log_dir/ ");
}

unless ( system ( "mkdir -p $webDir" ) == 0 ) {
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => '', -status => 'Failed', -externalBody => "Could not create web log directory \"$webDir\" for jobid - \'$perfJobID\'", -log_dir => $log_dir, -testName => $testName, -testId => $testId);
    $test_case_logger->logdie("Perf::sbcPerf - ERROR -> Could not create web log directory in $webDir ");
}

Genband::Utils::changeLogFile(-appenderName => "AutomationLog", -newLogFile => "$log_dir/PerfRun.log"); #switchin the ATS log
Genband::Utils::changeLogFile(-appenderName => "TestRunLog", -newLogFile => "$log_dir/PerfRun.log"); #switching the test log

# switching session logs
unless (Genband::Base::switchSessionLog($log_dir) ) {
    $test_case_logger->logdie("Perf::sbcPerf - ERROR -> unable to switch the session logs to $log_dir");
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => '', -status => 'Failed', -externalBody => "Failed to switch session logs for jobid - \'$perfJobID\'", -log_dir => $log_dir, -testName => $testName, -testId => $testId);
} else {
    $ENV{SESSION_DIR} = $log_dir;
    $test_case_logger->info("Perf::sbcPerf - INFO -> successfully switched all session logs to $log_dir");
}

my @TESTBED = ();


my @tbS = split(/,/, $testBedData->[0]->[0]);
foreach my $tb (@tbS) {
    if ($tb =~ /:/) {
        my @ceS = split (/:/, $tb);
        push (@TESTBED, \@ceS);
    } else {
        push (@TESTBED, $tb);
    }
}

@tbS = split(/,/, $testBedData->[0]->[1]);
foreach my $tb (@tbS) {
    $tb =~ s/.*://;
    push (@TESTBED, $tb);
}

$test_case_logger->info("Perf::sbcPerf - INFO -> framed testbed array => " . Dumper(\@TESTBED));

my %REQUIRED =();

foreach ( $testData->[0]->[2]) {
    my @tbS = split(/,/, $_);
    foreach my $tb (@tbS) {
        if ($tb =~ /^(.+)\_HA$/) {
            push (@{$REQUIRED{$1}}, 2);
        } else {
            push (@{$REQUIRED{$tb}}, 1);
        }
    }
}

&Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Initailizing the testbeds\", automationLog= \'$log_dir/PerfRun.log\' where JobId = \'$perfJobID\'");

$test_case_logger->info("Perf::sbcPerf - INFO -> required testbed array => " . Dumper(\%REQUIRED));

%TESTBED = Genband::ATSHELPER::resolveHashFromAliasArray( -input_array  => \@TESTBED );

unless (Genband::ATSHELPER::checkRequiredConfiguration ( \%REQUIRED, \%TESTBED)) {
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => '', -status => 'Failed', -externalBody => "The resources list passed are less the required testbeds for the test - \'$perfJobID\'", -log_dir => $log_dir, -testName => $testName, -testId => $testId);   
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  The resources list passed are less the required testbeds for the test");
}



my %changeOfConfig = ('sandybridge1u' => 1);

my $dut;

my $profileData = &Genband::PERF::PerfUtils::loadXMLData("$testDir/profile.xml");

unless ($dut = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{'sbc:1'}, -sessionlog =>1)) {
    &testFailed('Failed', "Failed to open connection to DUT");
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to open ssh connection to DUT");
} else {
    $test_case_logger->info("Perf::sbcPerf - opened ssh connection to DUT");
}

$build = $dut->{APPLICATION_VERSION};

&Genband::Utils::executeSqlCmd("update loadJob set loadJob_build = \"$build\" where loadJob_uuid = \'$perfJobID\'");

my @objs = ($dut);
push (@objs, $dut->{STANDBY}) if (defined $dut->{STANDBY});

#print Dumper($profileData);

#print $TESTBED{"$profileData->{server}"} . "===\n";

my $gw_2_gw = ($TESTBED{'sbc_count'} == 2) ? 1 :0;

my @dut2_objs = ();
my $dut2 = '';

if ($gw_2_gw) {
    unless ($dut2 = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{'sbc:2'}, -sessionlog =>1)) {
        &testFailed('Failed', "Failed to open connection to DUT2");
        $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to open ssh connection to DUT2");
    } else {
        $test_case_logger->info("Perf::sbcPerf - opened ssh connection to DUT2");
    }
    @dut2_objs = (defined $dut2->{STANDBY}) ?  ($dut2, $dut2->{STANDBY}) : ($dut2);
}

my @servers = ();
my %alreadyCopied = ();

foreach my $i (0..($profileData->{servers} - 1)) {
    last unless defined $TESTBED{$profileData->{"server" . ($i+1)}};
    unless ($servers[$i] = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{$profileData->{"server" . ($i+1)}}, -sessionlog =>1)) {
        &testFailed('Failed', "Failed to open connection to " . $profileData->{"server" . ($i+1)});
        $test_case_logger->info("Perf::sbcPerf - ERROR ->  failed to open ssh connection to server");
    }
    
    unless (&configureTool($servers[$i], $profileData->{"server" . ($i+1)}, 'server' . ($i+1))) {
        &testFailed('Failed', "Failed to Configure - " . $profileData->{"server" . ($i+1)});
        $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to oconfigure - " . $profileData->{"server" . ($i+1)});
    }
    $alreadyCopied{$profileData->{"server" . ($i+1)}} = 1;
    
}

sleep 1;

my @clients = ();

foreach my $i (0..($profileData->{clients} - 1)) {
    unless ($clients[$i] = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{$profileData->{"client" . ($i+1)}}, -sessionlog =>1)) {
        &testFailed('Failed', "Failed to open connection to " . $profileData->{"client" . ($i+1)});
        $test_case_logger->info("Perf::sbcPerf - ERROR ->  failed to open ssh connection to client");
    }
    
    if (defined $alreadyCopied{$profileData->{"client" . ($i+1)}}) {
        $test_case_logger->info("Perf::sbcPerf - INFO ->  you have this copied already, skipping");
        next;
    }
    
    unless (&configureTool($servers[$i], $profileData->{"client" . ($i+1)}, 'client' . ($i+1))) {
        &testFailed('Failed', "Failed to Configure - " . $profileData->{"client" . ($i+1)});
        $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  failed to oconfigure - " . $profileData->{"client" . ($i+1)});
    }
}

unless (&init()) {
    &testFailed('Failed', 'Test initialization failed, please check the system settings');
    $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  Test init failed");
}

if ($gw_2_gw) {
    unless (&initDut2()) {
        &testFailed('Failed', 'Test initialization failed, please check the system settings of DUT2');
        $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  Test init failed");
    } 
}

if ($bulkConfig) {
    unless (&bulkConfig()) {
        &testFailed('Failed', 'Bulk configuration failed, please check the system settings');
        $test_case_logger->logdie("Perf::sbcPerf - ERROR ->  Bulk configuration failed");
    }
}

my $loadResult = {};

unless (&runTest()) {
    ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
    $endTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
    #&Genband::PERF::PerfUtils::sendMail($mail, $url, 'Failed');
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => $url, -status => 'Failed', -log_dir => $log_dir, -testName => $testName, -testId => $testId, -externalBody => $externalBody);   
    &Genband::Utils::executeSqlCmd("INSERT INTO loadJobResult values (\'$perfJobID\', 'F', \'$startTime\', \'$endTime\', \'$url\')");
    $test_case_logger->error("Perf::sbcPerf - ERROR ->  Test failed");
} else {
    ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
    $endTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
    &Genband::Utils::executeSqlCmd("INSERT INTO loadJobResult values (\'$perfJobID\', 'P', \'$startTime\', \'$endTime\', \'$url\', \'$loadResult->{maxcps}\',  \'$loadResult->{abndcall}\',  \'$loadResult->{errcall}\',  \'$loadResult->{maxcall}\',  \'$loadResult->{maxcpu}\',  \'$loadResult->{maxmemory}\',  \'$loadResult->{avgcpu}\',  \'$loadResult->{avggiscpu}\',  \'$loadResult->{maxgismemory}\',  \'$loadResult->{maxgiscpu}\')");
    #&Genband::PERF::PerfUtils::sendMail($mail, $url, 'Passed');
    Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => $url, -status => 'Passed', -log_dir => $log_dir, -testName => $testName, -testId => $testId);   
}

sub init { 
    my $sub_name = 'init()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    my $mdeviceFile= ( defined $changeOfConfig{$platform}) ? "$testDir/config/$platform/mdevices.xml" : "$testDir/config/mdevices.xml";
        
    my %disableDebug = ( 'nxconfig.pl -e debug-modbridge' => 'debug-modbridge.*:',
                        'nxconfig.pl -e debug-modfind' => 'debug-modfind.*:',
                        'nxconfig.pl -e sdebug-level' => 'sdebug-level.*:',
                        'nxconfig.pl -e debug-modsip' => 'debug-modsip.*:',
                        'nxconfig.pl -e debug-modh248' => 'debug-modh248.*:',
                        'nxconfig.pl -e debug-modfce' => 'debug-modfce.*:');
                        
    foreach my $cmd (keys %disableDebug) {
    
        unless ($dut->promptConfirmExecCmd(	-cmd => $cmd,
                                            -prompts => [$disableDebug{$cmd}],
                                            -confirm => ['0'])) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name: failed to execute -> \'$cmd\' on -> \'$dut->{OBJ_HOSt}\'");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name: <-- Leaving sub [0]");
            return 0;
        }
        
    }
    
    my %confFiles = ();
    unless (%confFiles = &Genband::PERF::PerfUtils::getConfigFiles(-testDir => $testDir, -platform => $platform, -release => $release)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed get server config files");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    foreach ('mdevices.xml', 'iserverlc.xml','msxConfig.xml') {
        if (defined $confFiles{$_}) {
            $test_case_logger->info("Perf::sbcPerf::$sub_name --> using \'$confFiles{$_}\'");
            next;
        }
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed get \'$_\'");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless (&Genband::PERF::PerfUtils::editXmlFile( $confFiles{'mdevices.xml'} )) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to intialize sbc server");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    foreach my $file ($confFiles{'mdevices.xml'}, $confFiles{'iserverlc.xml'}) {
        my $scpCmd = "scp root\@172.23.54.205:$file /root/";
        unless ($dut->scpFile( -scpCmd => $scpCmd,  -password => 'shipped!!')) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to execute \"$scpCmd\"");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    
    unless ( system ( "cp \"$confFiles{'mdevices.xml'}_back\" \"$confFiles{'mdevices.xml'}\"") == 0 ) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> \"cp \"${mdeviceFile}_back\" \"$mdeviceFile\"\" execution failed");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    foreach my $obj (@objs) {
        $obj->{conn}->cmd("mkdir -p /var/core/OLDCORES 2>/dev/null");
        $obj->{conn}->cmd("mv  /var/core/core*  /var/core/OLDCORES/ 2>/dev/null");
    }

    unless ($dut->sbcInit( )) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to intialize sbc server");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $test_case_logger->info("Perf::sbcPerf::$sub_name - successfully initialized server");
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"configuring the testbeds\" where JobId = \'$perfJobID\'");
    
    unless (&testConfiguration($confFiles{'msxConfig.xml'})) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  test configuration failed") ;
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($dut->restartAll()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  Failed to restart SBC after the configuration");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    unless ($dut->verifySigPorts()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  signaling port are not running, please verify your configuration");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($dut->verifyHkports()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  HK port are not running, please verify your configuration"); 
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        #return 0;
    }
    
    #####I need to modify this
    
    #my %reachTest = ('eth2' => [$dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}, $dut->{TESTBED_ALIAS_DATA}->{PUB_MEDIA}->{1}->{IP}], 'eth3' => [$dut->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP}, $dut->{TESTBED_ALIAS_DATA}->{PRIV_MEDIA}->{1}->{IP}] );
    my %reachTest = ('eth2' => [$dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}], 'eth3' => [$dut->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP}] );

    foreach my $eth (keys %reachTest) {
        foreach my $ip (@{$reachTest{$eth}}) {
            foreach my $i (0..$#servers) {
                if ($servers[$i]->{ATS_OBJTYPE} == 'NXTEST') {
                    unless ($servers[$i]->pingHost($ip, $eth)) {
                        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  \"$ip\" not pingable from \"$eth\" of $servers[$i]->{OBJ_HOST}, please check your configuration");
                        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
                        return 0;
                    }
                } elsif ($obj->{ATS_OBJTYPE} == 'IXIA') {
                    #Stuff related IXIA
                }
            }
            
            foreach my $i (0..$#clients) {
                if ($clients[$i]->{ATS_OBJTYPE} == 'NXTEST') {
                    unless ($clients[$i]->pingHost($ip, $eth)) {
                        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  \"$ip\" not pingable from \"$eth\" of $clients[$i]->{OBJ_HOST}, please check your configuration");
                        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
                        return 0;
                    }
                } elsif ($obj->{ATS_OBJTYPE} == 'IXIA') {
                    #Stuff related IXIA
                }
            }
        }
    }
    
    unless (&checkForCore()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}

sub runTest {
    my $sub_name = 'runTest()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Running single call test\" where JobId = \'$perfJobID\'");
    
    unless ( &Genband::PERF::PerfUtils::runSingleCall(-servers => \@servers, -clients => \@clients, -profileData => $profileData, -callHoldTime => \%callHoldTimes, -callRates => \%callRates) ) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to make single call");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless (&Genband::PERF::PerfUtils::startLogCollector(@objs) ) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to start perf log collector in sbc server");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    foreach my $obj (@objs) {
        $obj->{conn}->cmd('rm -f /var/cdrs/*.*');
    }
    
    unless ( &Genband::PERF::PerfUtils::startLoad(-servers => \@servers, -clients => \@clients, -profileData => $profileData, -callHoldTime => \%callHoldTimes, -callRates => \%callRates) ) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to start load");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    my $count = int($callDuration/60);
    my $oddSeconds = $callDuration%60;
    my $secondsRemaining = $callDuration;
    my $completedDuration = 0;
    my $callsInHold = 0;
    foreach (keys %callHoldTimes)  {
        $callsInHold += int (($callRates{$_} * $callHoldTimes{$_}) / 1000);
    }
    
    my $vportsFlag =0;
    foreach (1..$count) {
        sleep 60;
        $secondsRemaining -= 60;
        &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Load is running, waiting for the duration of $secondsRemaining seconds\" where JobId = \'$perfJobID\'");
        $test_case_logger->info("Perf::sbcPerf::$sub_name - INFO - load is running, waiting for the duration of $secondsRemaining seconds");
        $completedDuration += 60;
        next unless ($completedDuration > $maxCallHoldTime);
        next if $vportsFlag;
        my @cmdOut = ();
        unless (@cmdOut = $dut->execCmd( "lstat" )) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to execute lstat");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
        my $matched = 0;
        foreach (@cmdOut) {
            chomp $_;
            next unless ($_ =~ /Used Media Routed VPORTS\s*(\d+)/);
            $matched = 1 if ($1 >= ($callsInHold - 20) and $1<= ($callsInHold + 20));
        }
        
        unless ($matched) {
            $externalBody = "Failed to match Used Media Routed VPORTS => [" . ($callsInHold - 20) . "-" . ($callsInHold + 20) . "]";
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to match \"Media Routed VPORTS\"");
            &Genband::PERF::PerfUtils::stopLoad(-servers => \@servers, -clients => \@clients, -callHoldTime => \%callHoldTimes);
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        } else {
            $test_case_logger->info("Perf::sbcPerf::$sub_name - Used Media Routed VPORTS matched for $callsInHold +- 20");
        }
        $vportsFlag =1;  
    }
    
    sleep $secondsRemaining if ($secondsRemaining >= 1);
    
    unless ( &Genband::PERF::PerfUtils::stopLoad(-servers => \@servers, -clients => \@clients) ) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to stop load");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Load is completed collecting the stats\" where JobId = \'$perfJobID\'");
    
    unless ( &Genband::PERF::PerfUtils::stopLogCollector(-objs => \@objs, -log_dir => $log_dir)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->failed to copy the logs from sbc");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    unless ( &Genband::PERF::PerfUtils::plotGraph(-log_dir => $log_dir, -testId => $testId, -testName => $testName, -callDuration => $callDuration, -callRate => $callRate, -platform => $platform, -build => $build, -webDir => $webDir)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to plot perf graph");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Test completed\" where JobId = \'$perfJobID\'");
    
    unless (&checkForCore()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    if ($gw_2_gw) {
        unless (&checkForCore($gw_2_gw)) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }

    my %cdrRfactor = ();
    unless (%cdrRfactor = &Genband::PERF::PerfUtils::getCdrAndRfactor($dut, (-profile => $profileData,  -clients => \@clients, -webDir => $webDir))) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  Failed to get the crd/rfactor data");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ( $loadResult = &Genband::PERF::PerfUtils::generateReport(%cdrRfactor, -profile => $profileData, -log_dir => $log_dir, -webDir => $webDir, -build => $build, -testId => $testId, -testName => $testName, -callHoldTime => \%callHoldTimes, -callDuration => $callDuration, -platform => $platform)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  Failed to get the crd/rfactor data");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}


sub testConfiguration {
    my ($config, $otherSBC) = @_;
    my $sub_name = 'testConfiguration()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    my $fh;
    
    my $dutObj = ($otherSBC) ? $dut2 : $dut;
    unless (open ( $fh, '<', $config)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->failed to open \'$config\' -> $!");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    foreach my $line (<$fh>) {
        next if ($line =~ /(^\s*#|^\s*$)/);
        
        chomp $line;
=pod
        my $xmlData = &Genband::PERF::PerfUtils::loadXMLData($line);
        my ($cmd, @values);
        $xmlData->{testbeddata} = [$xmlData->{testbeddata}] if ((ref $xmlData eq "HASH") and !(ref ($xmlData->{testbeddata})) and defined $xmlData->{testbeddata});
        foreach my $testData (@{$xmlData->{testbeddata}}) {
            my @temp = split(/-\>/, $testData);
            unless ( defined $TESTBED{"$temp[0]:hash"}->{$temp[1]}->{$temp[2]}->{$temp[3]}) {
                $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  $testData empty or invalid");
                $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
                return 0;
            }            
            $test_case_logger->info("Perf::sbcPerf::$sub_name - \'$TESTBED{\"$temp[0]:hash\"}->{$temp[1]}->{$temp[2]}->{$temp[3]}\'");
            push (@values, $TESTBED{"$temp[0]:hash"}->{$temp[1]}->{$temp[2]}->{$temp[3]});
        }
        
        if (@{$xmlData->{content}}) {
            map {$cmd .= $xmlData->{content}->[$_] . ($values[$_] ? $values[$_] : '') } 0..(scalar @{$xmlData->{content}} - 1);
        } else {
            $cmd = $xmlData;
        }
=cut

        my $cmd = &Genband::PERF::PerfUtils::frameCliCmd($line);
        
        unless ($line =~ /^\s*<\s*(\S+)\s*>/) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to get Method name from $line");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
        my $method = $1;
        unless ($dutObj->can($method)) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  \"$method\" is not a method of \"$dutObj->{TYPE}\"");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
        unless ($dutObj->$method(( ref $cmd ) ? (ref $cmd == "ARRAY" ? @{$cmd} : %{$cmd}) : $cmd)) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to execute $method with => " . Dumper($cmd));
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    close $fh;
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}

sub configureTool {
    my ($obj, $profileCount , $subDir) = @_;
    my $sub_name = 'configureTool()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    my @scripts = `ls -1 $testDir/script/ 2>/dev/null`;
    #$subDir = "$testDir/script/$subDir";
    
    chomp @scripts;
    if ( $obj->{ATS_OBJTYPE} == 'NXTEST') {
        unless (&Genband::PERF::PerfNxTest::configureNxTest($obj, "$testDir/script/$subDir")) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> Failed to configure \'$profileCount\' ");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    } elsif ($obj->{ATS_OBJTYPE} == 'IXIA') {
        unless (&Genband::PERF::PerfIXIA::configureIXIA($obj, "$testDir/script/$subDir")) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> Failed to configure '\$profileCount\'");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
        
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}

sub checkForCore {
    my $otherSbc = shift;
    my $sub_name = 'checkForCore()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    my @needToCheck = $otherSbc ? @dut2_objs : @objs;
    foreach my $obj (@needToCheck) {
        if (my @cores = $obj->execCmd("ls -1l /var/core/core* 2>/dev/null")) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found in host -> $obj->{OBJ_HOST}");
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core files are =>" . Dumper(\@cores));
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    return 1;
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
}

sub handleControlC {
    print "\nOh my God, you killed Kenny\n\n";
    &testFailed('Failed', "you killed the job");
    exit;
}

sub usage{
    print "\n USAGE: ./sbcPerf.pl -id jobId\n";
    exit(0);
}

sub bulkConfig {
    my $arg = shift;
    
    my $sub_name = 'bulkConfig()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Configuring Bulk Data\" where JobId = \'$perfJobID\'");
    unless (Genband::PERF::PerfUtils::bulkConfig($dut, $bulkConfig)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to do bulk configuration");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless (&checkForCore()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found during the bulk configuration");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}

sub testFailed {
    my ($status, $msg) = shift;
    my $sub_name = 'testFailed()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    
    &Genband::PERF::PerfUtils::sendMail(-mailId => $mail, -webUrl => $url, -status => $status, externalBody => $msg, -testName => $testName, -testId => $testId);
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
}

# To keep it simple and understandable made copy past init() :P

sub initDut2 {
    my %args = (-skipLicence => 1);    
    my $sub_name = 'initDut2()';
    $test_case_logger->info("Perf::sbcPerf::$sub_name --> Entered sub");
    my $mdeviceFile= ( defined $changeOfConfig{$platform}) ? "$testDir/config/DUT2/$platform/mdevices.xml" : "$testDir/config/DUT2/mdevices.xml";
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"preparing the testbeds - DUT2\" where JobId = \'$perfJobID\'");
    
    if ( (`ls -1l $mdeviceFile 2>/dev/null`) and ( `ls -1l $testDir/config/DUT2/iserverlc.xml 2>/dev/null`)) {
        delete $args{-skipLicence};

        unless (&Genband::PERF::PerfUtils::editXmlFile( $mdeviceFile )) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to intialize sbc server");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    
        foreach my $file ($mdeviceFile, "$testDir/config/iserverlc.xml") {
            my $scpCmd = "scp root\@172.23.54.205:$file /root/";
            unless ($dut2->scpFile( -scpCmd => $scpCmd,  -password => 'shipped!!')) {
                $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> failed to execute \"$scpCmd\"");
                $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
                return 0;
            }
        }
        unless ( system ( "cp \"${mdeviceFile}_back\" \"$mdeviceFile\"") == 0 ) {
            $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> \"cp \"${mdeviceFile}_back\" \"$mdeviceFile\"\" execution failed");
            $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    } else {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR -> config files not found");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    foreach my $obj (@dut2_objs) {
        $obj->{conn}->cmd("mkdir -p /var/core/OLDCORES 2>/dev/null");
        $obj->{conn}->cmd("mv  /var/core/core*  /var/core/OLDCORES/ 2>/dev/null");
    }

    unless ($dut2->sbcInit( %args )) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  failed to intialize sbc server");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $test_case_logger->info("Perf::sbcPerf::$sub_name - successfully initialized server");
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"configuring the testbeds - DUT2\" where JobId = \'$perfJobID\'");
    
    unless (&testConfiguration("$testDir/config/DUT2/msxConfig.xml", 1)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  test configuration failed") ;
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    unless ($dut2->verifySigPorts()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  signaling port are not running, please verify your configuration");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    unless ($dut2->verifyHkports()) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  HK port are not running, please verify your configuration"); 
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        #return 0;
    }

    unless (&checkForCore(1)) {
        $test_case_logger->error("Perf::sbcPerf::$sub_name - ERROR ->  core found");
        $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $test_case_logger->debug("Perf::sbcPerf::$sub_name <-- Leaving sub [1]");
    return 1;
}

1;
