#!/bin/sh
#These Endpoints are not used for Calls.
cli vnet add bulk_vnet1
cli vnet edit bulk_vnet1 ifname eth1
cli vnet edit bulk_vnet1 gateway 51.25.5.1

cli realm add realm_tx_1_1
cli realm edit realm_tx_1_1 addr public emr alwayson imr alwayson
cli realm edit realm_tx_1_1 natmr alwayson
cli realm edit realm_tx_1_1 rsa 51.25.5.253 mask 255.255.255.0
cli realm edit realm_tx_1_1 medpool 1
cli realm edit realm_tx_1_1 admin enable
cli realm edit realm_tx_1_1 vnet bulk_vnet1

phone_num=8001
for (( i=1; i<252;i++))
do
    epname=ep_tx_$i 
    cli iedge add $epname 0 
    cli iedge edit $epname 0 type ipphone 
    cli iedge phones $epname 0  $phone_num 
    cli iedge edit $epname  0 realm realm_tx_1_1
    cli iedge edit $epname  0 sip enable 
    cli iedge edit $epname  0  static 51.25.5.$i 
    phone_num=$[$phone_num + 1]
done

cli vnet add bulk_vnet2
cli vnet edit bulk_vnet2 ifname eth1
cli vnet edit bulk_vnet2 gateway 52.25.6.1

cli realm add realm_tx_2_1
cli realm edit realm_tx_2_1 addr public emr alwayson imr alwayson
cli realm edit realm_tx_2_1 natmr alwayson
cli realm edit realm_tx_2_1 rsa 52.25.6.253 mask 255.255.255.0
cli realm edit realm_tx_2_1 medpool 1
cli realm edit realm_tx_2_1 admin enable
cli realm edit realm_tx_2_1 vnet bulk_vnet2

ip=1
for (( i=254; i<500;i++))
do
    epname=ep_tx_$i
    cli iedge add $epname 0
    cli iedge edit $epname 0 type ipphone
    cli iedge phones $epname 0  $phone_num
    cli iedge edit $epname  0 realm realm_tx_2_1
    cli iedge edit $epname  0 sip enable
    cli iedge edit $epname  0  static 52.25.6.$ip
    phone_num=$[$phone_num + 1]
    ip=$[$ip +1]
done

cli vnet add bulk_vnet3
cli vnet edit bulk_vnet3 ifname eth2
cli vnet edit bulk_vnet3 gateway 71.30.5.1

cli realm add realm_tx_3_1
cli realm edit realm_tx_3_1 addr public emr alwayson imr alwayson
cli realm edit realm_tx_3_1 natmr alwayson
cli realm edit realm_tx_3_1 rsa 71.30.5.253 mask 255.255.255.0
cli realm edit realm_tx_3_1 medpool 1
cli realm edit realm_tx_3_1 admin enable
cli realm edit realm_tx_3_1 vnet bulk_vnet3

for (( i=1; i<252;i++))
do
    epname=ep_rx_$i
    cli iedge add $epname 0
    cli iedge edit $epname 0 type ipphone
    cli iedge phones $epname 0  $phone_num
    cli iedge edit $epname  0 realm realm_tx_3_1
    cli iedge edit $epname  0 sip enable
    cli iedge edit $epname  0  static 71.30.5.$i
    phone_num=$[$phone_num + 1]
done

cli vnet add bulk_vnet4
cli vnet edit bulk_vnet4 ifname eth2
cli vnet edit bulk_vnet4 gateway 72.30.6.1

cli realm add realm_tx_4_1
cli realm edit realm_tx_4_1 addr public emr alwayson imr alwayson
cli realm edit realm_tx_4_1 natmr alwayson
cli realm edit realm_tx_4_1 rsa 72.30.6.253 mask 255.255.255.0
cli realm edit realm_tx_4_1 medpool 1
cli realm edit realm_tx_4_1 admin enable
cli realm edit realm_tx_4_1 vnet bulk_vnet4

ip=1
for (( i=254; i<500;i++))
do
    epname=ep_rx_$i
    cli iedge add $epname 0
    cli iedge edit $epname 0 type ipphone
    cli iedge phones $epname 0  $phone_num
    cli iedge edit $epname  0 realm realm_tx_4_1
    cli iedge edit $epname  0 sip enable
    cli iedge edit $epname  0  static 72.30.6.$ip
    phone_num=$[$phone_num + 1]
    ip=$[$ip +1]
done

   #rname='san_realm_' + str(i) 
   #msw.assertCommand('cli vnet add %s' %vname)
    #msw.assertCommand('cli vnet edit %s ifname eth2 vlanid %s' %(vname,i))
    #msw.assertCommand('cli realm add %s' %rname)
    #msw.assertCommand('cli realm edit %s mask 255.255.0.0 rsa 192.168.%s.10 vnet %s medpool %s' %(rname,i,vname,i))
echo "added 1014 endpoints"
