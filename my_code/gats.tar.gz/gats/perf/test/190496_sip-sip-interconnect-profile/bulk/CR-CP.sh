#!/bin/sh

for (( i=1; i<=100000;i++))
do
    crname=Dummy_CR_1_100000_$i
    cpname=Dummy_CP_1_100000_$i
    cli cr add  $crname
    cli cr edit $crname dest 4$i calltype dest
    cli cp add $cpname $crname
done

echo "added 100000 cp-cr"



