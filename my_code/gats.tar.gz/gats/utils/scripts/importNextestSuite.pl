=head1 NAME

importNextestSuite.pl - Perl script import nextest suite and its sub suites to genSmart DB.

=head1 AUTHOR

Ramesh Pateel (Ram)
=cut

use ATS;
use Data::Dumper;

my %cmdLineArguements=@ARGV;

if(defined($cmdLineArguements{'-h'})){# NEED HELP?
    &usage();
}

foreach ('-dut', '-release', '-platform', '-devices', '-regType', '-path', '-bucket', '-env', '-nxtest', '-duttype', '-clitype') {
    die "command line arugume '$_' is missing\n"  unless (defined $cmdLineArguements{$_});
}

$ENV{'TERM'} = 'DUMP';

my $obj = Genband::ATSHELPER::newFromAlias(-testbed_alias => [$cmdLineArguements{-nxtest}], -sessionlog =>1);

my @tempPath = split('/',$cmdLineArguements{-path});

my $path = "/var/opt/nextest/tdb/$tempPath[0]";

my $featurePath = join('/', @tempPath[1..($#tempPath)]);

$obj->{conn}->cmd("cd $path");

my @result = $obj->{conn}->cmd("find $featurePath -name \"*.qmt\" ");

chomp @result;

my %data = ();
my $count = 0;
foreach my $line (@result) {
    chomp $line;
    $line =~ s/^\.\///;
    next if ($line =~ /(provision|xit)\.qmt$/);
    $line =~ s/\.qmt//;
    
    my @temp = split('/', $line);
    my $name =  join('.', @temp[0..($#temp-1)]);
    $name =~ s/\.qms//g;
    $data{$name}{path} = "$tempPath[0]/" . join('/',@temp[0..($#temp-1)]);
    push (@{$data{$name}{tests}}, $temp[-1]);
    $count++;
    
}

#print Dumper(\%data);
my $tTests = 0;

foreach my $suiteName (keys %data) {
    my $suiteId = &getUUID();

    #print "INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','$cmdLineArguements{-dut}', '$cmdLineArguements{-release}', '$cmdLineArguements{-platform}', '$cmdLineArguements{-devices}', '', '$cmdLineArguements{-regType}', '$data{$suiteName}{path}', '$cmdLineArguements{-bucket}', '$cmdLineArguements{-env}')\n";

    &Genband::Utils::executeSqlCmd("INSERT INTO regressionsuite VALUES ('$suiteId', '$suiteName','$cmdLineArguements{-dut}', '$cmdLineArguements{-release}', '$cmdLineArguements{-platform}', '$cmdLineArguements{-devices}', '', '$cmdLineArguements{-regType}', '$data{$suiteName}{path}', '$cmdLineArguements{-bucket}', '$cmdLineArguements{-env}', '$cmdLineArguements{-duttype}', '$cmdLineArguements{-clitype}')");
    
    &Genband::Utils::executeSqlCmd("INSERT INTO regressiontests VALUES ('$suiteId','" . join(',', @{$data{$suiteName}{tests}}) . "')");
    $tTests += scalar(@{$data{$suiteName}{tests}});
}

print "$tTests\n";

sub getUUID () {
    my $q  = &Genband::Utils::executeSqlCmd("select uuid() as uuid");
    return $q->[0]->[0];
}
