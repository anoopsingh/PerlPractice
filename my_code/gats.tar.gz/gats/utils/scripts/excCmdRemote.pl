=head1 NAME

excCmdRemote.pl - Perl script to execute shell cmds on remote machine, return the results.

=head1 AUTHOR

Ramesh Pateel (Ram)
=cut

use ATS;
my %cmdLineArguements=@ARGV;

if(defined($cmdLineArguements{'-h'})){# NEED HELP?
    &usage();
}

die "ip address is missing \n" unless (defined $cmdLineArguements{-ip});
die "Port is missing \n" unless (defined $cmdLineArguements{-port});
die "Total number of commands is missing\n" unless (defined $cmdLineArguements{-n});
my $user = (defined $cmdLineArguements{-user}) ? $cmdLineArguements{-user} : 'root';
my $passwd = (defined $cmdLineArguements{-passwd}) ? $cmdLineArguements{-passwd} : 'shipped!!';

$ENV{'TERM'} = 'DUMP';
my $ssh = Genband::Base->new( -obj_host =>  $cmdLineArguements{-ip},
                              -obj_port => $cmdLineArguements{-port},
                              -obj_user => $user,
                              -obj_password => $passwd,
                              -comm_type => "SSH",-sessionlog =>1) || die "Failed to make ssh connection";

foreach (1..$cmdLineArguements{-n}) {
    $ssh->execLinuxCmd($cmdLineArguements{"-cmd$_"}) || die "Failed to execute  $cmdLineArguements{-cmd$_}\n";
    
    map {print $_ . "\n"} @{$ssh->{CMDRESULTS}};
}

sub usage{
    print "\n USAGE: excCmdRemote.pl  -n numberOfCmds -ip ipaddress -port port -cmd1 \"First cmd\" -cmd2 \"second cmd\"\n";
    exit(0);
}
