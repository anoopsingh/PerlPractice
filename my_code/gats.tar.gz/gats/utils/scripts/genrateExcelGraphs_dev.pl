#!/usr/bin/perl
#############################################################
#
# Genband US LLC,
#
# All Rights Reserved.
# Confidential and Proprietary.
#
# Module Name:  genrateExcelGraphs.pl
#
# Module Description:
# This script used to plot the graph from raw data
# Usage:
#       Input 3 in number
#           1) -log log file, make sure log file as first column as timestamp
#           2) -uid userid
# 
# Author: Ramesh Pateel (Ram)
#
#############################################################


#use strict;
use Spreadsheet::WriteExcel;
use Excel::Writer::XLSX;

my %cmdLineArguements=@ARGV;	#takes arguments from commandline

#print Dumper(\%cmdLineArguements);
if(defined($cmdLineArguements{'-h'})){# NEED HELP?
    &usage();
}
if (!defined($cmdLineArguements{'-log'}) or !defined($cmdLineArguements{'-uid'})){# DO WE HAVE THE ARGUMENT?
    &usage();
}

sub usage{
    print "\n USAGE: genrateExcelGraphs -log /tmp/ram/test.log -uid rpateel\n";
    exit(0);
}

my $fh;
eval {
    open ($fh, '<', "$cmdLineArguements{'-log'}");
};

die  "Failed to open $cmdLineArguements{'-log'} - $@\n" if ($@);

my $user = $cmdLineArguements{'-uid'};
my $file = "/tmp/$user.xlsx";
my $workbook = Excel::Writer::XLSX->new($file);

my $worksheet = $workbook->add_worksheet('Test Stats');
my $format = $workbook->add_format(bold => 1, bg_color => 50, border  => 1);

my ($row, $col) = ( 0, 0);
my @header =();
foreach my $line (<$fh>) {
    unless ($row) {
        @header = split(/\s+/, $line);
        $worksheet->write_row($row++,0,\@header, $format);
        $col = $#header;
        next;
    }
    my @data = split(/\s+/, $line);
    map {$data[$_] =~ s/[a-z]//ig} 1..$#data;
    last unless ($data[0]);
    $worksheet->write_row($row++,0,\@data);
}  

my $graphData = [];

my $chartrow = 5;
my $colName = 'B';
foreach (1..$#header) {
    
    my $chart = $workbook->add_chart( type => 'line', embedded => 1 );
    $chart->add_series(
        name       => $_,
        categories => '=Test Stats!$A$1:$A$' . $row,
        values     => '=Test Stats!$' . $colName . '$14:$' . $colName . '$' . $row,
        marker     => { type => 'none'}
    );
    $colName++;
    # Add a chart title and some axis labels.
    $chart->set_title ( name => $header[$_] );
    $chart->set_x_axis( name => $header[0] );
    $chart->set_y_axis( name => $header[$_] );

    # Insert the chart into the worksheet (with an offset).
    $worksheet->insert_chart( $chartrow, $col+3, $chart);
    $chartrow+=20;
}

$workbook->close();

print "Result file => \'$file\'\n";
1;
