#!/gats/bin/perl
#############################################################
#
# Genband US LLC,
#
# All Rights Reserved.
# Confidential and Proprietary.
#
# Module Name:  nextestRegression.pl
#
# Module Description:
# This script automates the regression execution
#
######## LIMITATION ########### IT IS ONLY FOR NEXTEST BASED FRAMEWORK EXECUTION#####
# 
# Author: Ram (Ramesh Pateel)
#
#############################################################

#use strict;
#use warnings;
#use diagnostics;
use ATS;
use MIME::Entity;
use Data::Dumper;
use Log::Log4perl qw(get_logger :easy);

# Reading command line Arguments
my %cmdLineArguements=@ARGV;	#takes arguments from commandline
$SIG{INT} = \&handleControlC;

#print Dumper(\%cmdLineArguements);
if(defined($cmdLineArguements{'-h'})){# NEED HELP?
	&usage();
}
if (!defined($cmdLineArguements{'-id'}) or !$cmdLineArguements{'-id'}){# DO WE HAVE THE ARGUMENT?
	&usage();
}

my $regJobID = $cmdLineArguements{'-id'};
my $baseLogDir = $cmdLineArguements{'-log'};

# Create timestamp for automation run logs
my ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
my $timestamp = sprintf "%4d%02d%02d-%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;

my $startTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;

my $log_dir = $baseLogDir;

$ENV{SESSION_DIR} = $log_dir;

my $layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss.SSS}.%-8p %32.33C{3} : %m%n");
# Simplified layout for screen
my $screen_layout = Log::Log4perl::Layout::PatternLayout->new(
        "%d{MMddyyy HHmmss}: %m%n");

# Override default easy init logging for Base 
# connections

my $ats_logger        = get_logger("Genband");
my $reg_execution_logger  = get_logger("Scripts");
$ats_logger->additivity(0);
$reg_execution_logger->additivity(0);

# Create the ATS appender and point it to a log file
my $ats_file_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "$log_dir/RegRun.log",
        name => "AutomationLog",
);

# Create the test case appender and point it to a log file
my $test_case_appender = Log::Log4perl::Appender->new(
        "Log::Log4perl::Appender::File",
        filename => "$log_dir/RegRun.log",
        name => "TestRunLog",
);

# Create a second test case appender and point it to the screen 
my $test_case_screen_appender = Log::Log4perl::Appender->new(
        "Log::Dispatch::Screen",
        name => "screen",
);

# Add appenders to the appropriate logger 
$ats_logger->add_appender($ats_file_appender);
$ats_logger->add_appender($test_case_screen_appender);
$reg_execution_logger->add_appender($test_case_screen_appender);
$reg_execution_logger->add_appender($test_case_appender);

# Configure the appenders with the layout we've defined
$ats_file_appender->layout($layout);
$test_case_appender->layout($layout);
$test_case_screen_appender->layout($screen_layout);

# Set logging levels
$ats_logger->level($DEBUG);
$reg_execution_logger->level($DEBUG);

my ($jobData, $testData, $testBedData, $externalBody);
 
unless ($jobData = &Genband::Utils::executeSqlCmd("SELECT regressionjob_testbedtopologyuuid, regressionjob_release, regressionjob_username, regressionjob_build, regressionjob_type, regressionjob_debugmode, regressionjob_name, regressionjob_platform, regressionjob_flags, regressionjob_skipbaseconfig, regressionjob_executeonly, regressionjob_notify, regressionjob_cc, regressionjob_skiptbprepare  FROM regressionjob where regressionjob_uuid = \'$regJobID\'")) {
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get job details for jobid - \'$regJobID\'");
}

my $debugMode = ($jobData->[0]->[5]) ? '-c nextest.debugmode=ON' : '-c nextest.debugmode=OFF';
my $executeOnly = (defined $jobData->[0]->[10] and $jobData->[0]->[10] ) ? $jobData->[0]->[10] : 0;

my $notifyIfFailed = $jobData->[0]->[11];
 
unless ($testBedData = &Genband::Utils::executeSqlCmd("SELECT testbedtopology_testbedelements, testbedtopology_otherTestbedelements, testbedtopology_location, testbedtopology_name, testbedtopology_duttype, testbedtopology_clitype FROM testbedtopology where testbedtopology_uuid = \'$jobData->[0]->[0]\'")) {
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get testbed topology details for jobid - \'$regJobID\'");
 
}

unless ($testData = &Genband::Utils::executeSqlCmd("SELECT regressionsuite.regressionsuite_name, regressionjobtests.regressionjobtests_testcase, regressionsuite.regressionsuite_path, regressionsuite.regressionsuite_type, regressionsuite.regressionsuite_uuid, regressionjobtests.regressionjobtests_provision FROM  regressionjobtests, regressionsuite where regressionjobtests.regressionjobtests_suiteuuid = regressionsuite.regressionsuite_uuid and regressionjobtests.regressionjobtests_jobuuid = \'$regJobID\' order by regressionsuite.regressionsuite_type, regressionsuite.regressionsuite_name")) {
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get test suite details for jobid - \'$regJobID\'");
}

my $userName = $jobData->[0]->[2];
my $build = $jobData->[0]->[3];

my $skipBaseConfig = ( $jobData->[0]->[9] == 1) ? 1 : 0;

# Creating the logs directory 
#$log_dir .= "/$userName/$timestamp";
#my $regReslDir = $log_dir.'/results/';

my $userData = '';
unless ($userData = &Genband::Utils::executeSqlCmd("SELECT emailId FROM users where userName = \'$userName\'")) {
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to get user details for - \'$userName\'");
}

my $mail = $userData->[0]->[0] . ($jobData->[0]->[12] ? ";$jobData->[0]->[12]" : '');

my $regressionType = lc $jobData->[0]->[4];

=pod
unless ( system ( "mkdir -p $log_dir/" ) == 0 ) {
	&sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "Could not create log directory \"$log_dir\"");
	$reg_execution_logger->logdie("reg::runReg - ERROR -> Could not create user log directory in $log_dir/ ");
}

Genband::Utils::changeLogFile(-appenderName => "AutomationLog", -newLogFile => "$log_dir/RegRun.log"); #switchin the ATS log
Genband::Utils::changeLogFile(-appenderName => "TestRunLog", -newLogFile => "$log_dir/RegRun.log"); #switching the test log

# switching session logs
unless (Genband::Base::switchSessionLog($log_dir) ) {
    &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "Failed to switch session logs for jobid - \'$regJobID\'");
	$reg_execution_logger->logdie("Reg::AutomationReg - ERROR -> unable to switch the session logs to ");
} else {
    $ENV{SESSION_DIR} = $log_dir;
    $reg_execution_logger->info("Reg:: - INFO -> successfully switched all session logs to ");
}
=cut

my ($gen, $dut);
my @TESTBED = ();
 

my @tbS = split(/,/, $testBedData->[0]->[0]);
foreach my $tb (@tbS) {
    if ($tb =~ /:/) {
        my @ceS = split (/:/, $tb);
        push (@TESTBED, \@ceS);
    } else {
        push (@TESTBED, $tb);
    }
}

@tbS = split(/;/, $testBedData->[0]->[1]);
foreach my $tb (@tbS) {
    $tb =~ s/.*://;
    push (@TESTBED, $tb);
}

&Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Initailizing the testbeds\", automationLog= \'$log_dir/RegRun.log\' where JobId = \'$regJobID\'");

my %TESTBED = Genband::ATSHELPER::resolveHashFromAliasArray( -input_array  => \@TESTBED );

unless ($dut = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{'sbc:1'}, -sessionlog =>1)) {
    &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "Failed to open connection to DUT(SBC)");
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to open ssh connection to DUT");
} else {
    $reg_execution_logger->info("Perf::sbcPerf - opened ssh connection to DUT");
}
$build = $dut->{APPLICATION_VERSION};

my $jobContent = '<table border="1" align="center"><tr><td>Job Name</td><td>Build</td><td>Release</td><td>Platform</td><td>Regression Type</td><td>TestBed Topology</td><td>Start Time</td><td>End Time</td></td></tr>' . "<tr><td>$jobData->[0]->[6]</td><td>$build</td><td>$jobData->[0]->[1]</td><td>$jobData->[0]->[7]</td><td>$jobData->[0]->[4]</td><td>$testBedData->[0]->[3]</td>";

&Genband::Utils::executeSqlCmd("update regressionjob set regressionjob_build = \"$build\" where regressionjob_uuid = \'$regJobID\'");

unless ($gen = Genband::ATSHELPER::newFromAlias(-testbed_alias => $TESTBED{'nxtest:1'}, -sessionlog =>1)) {
    &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "Failed to open connection to GEN Machine");
    $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to open ssh connection to DUT");
} else {
    $reg_execution_logger->info("Perf::sbcPerf - opened ssh connection to DUT");
}

my $gen_ip     = $gen->{OBJ_HOST};
my $sbc_pri_ip = $dut->{OBJ_HOST};
my $sbc_sec_ip = (defined $dut->{STANDBY}) ?  $dut->{STANDBY}->{OBJ_HOST} : '';;

#my $scpCmd = "scp /etc/hosts root\@172.16.26.92:/$log_dir/";
#unless ($gen->scpFile( -scpCmd => $scpCmd,  -password => 'shipped!!')) {
#     $reg_execution_logger->error("Reg::runRegression:: - ERROR -> failed to execute \"$scpCmd\"");
#     $reg_execution_logger->debug("Reg::runRegression:: <-- Leaving sub [0]");
#     return 0;
#}

if ($jobData->[0]->[5]) {
    my @debugFlags = split(';', $jobData->[0]->[8]);
    open (my $debugFh, '>', "$log_dir/debugFlags.txt") or $reg_execution_logger->logdie("Perf::sbcPerf - ERROR ->  failed to open debugFlags.txt");;
    foreach my $flag (@debugFlags) {
        chomp $flag;
        $flag =~ s/^\s+//;
        $flag =~ s/\s+$//;
        next unless ($flag =~ /^nxconfig\.pl/);
        print $debugFh $flag ."\n";
    }
    
    close $debugFh;
    
    $scpCmd = "scp root\@172.16.26.92:$log_dir/debugFlags.txt /tmp/";
    unless ($gen->scpFile( -scpCmd => $scpCmd,  -password => 'By2GYH')) {
        $reg_execution_logger->error("Reg::runRegression:: - ERROR -> failed to execute \"$scpCmd\"");
        $reg_execution_logger->debug("Reg::runRegression:: <-- Leaving sub [0]");
        return 0;
    }   
    system("rm -f $log_dir/debugFlags.txt");
}


unless (&init()) {
    &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "Test Initialization failed, please check the system settings");
    $reg_execution_logger->logdie("Reg::runRegression - ERROR ->  Test init failed");
}


unless (&runQmtest($build)){
    &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "QmTest execution Failed, Please check your testbed configuration");
    $reg_execution_logger->logdie("Reg::runRegression - ERROR ->  regression execution failed");
}

$gen->execLinuxCmd('rm -f /tmp/debugFlags.txt') if ($jobData->[0]->[5]);

sub init {

    my $sub_name = 'init';

    # verify the signaling ports :: Verifying the  eth2 & eth3 interfaces are active and configutred for an IP
    unless ($dut->verifySigPorts()) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  signaling port are not running, please verify your configuration");
        $reg_execution_logger->debug("Reg::sbcPerf::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($dut->installLicense()) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - Failed to install license");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    unless ($dut->verifyLicense()) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - Testbed doesn't have a valid license, please verify your configuration");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($testBedData->[0]->[4] eq 'D-SBC') {
        ##Verify hk cards
        unless ($dut->verifyHkports( -minCardUp => 1)) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  HK port are not running, please verify your configuration");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    
    #Verify i server process
    unless ($dut->verifyiServerStatus()) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  iserver prcoesses  are not running, please check the psis process");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    #check regression status
    my @qmtestProc = $gen->execCmd('ps -ef |grep /opt/nextest/bin/qmtest | grep -v grep 2>/dev/null');
    if ( scalar @qmtestProc) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR->  regression is already running please wait for its completion" . Dumper(\@qmtestProc));
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    #$gen->execLinuxCmd('rm /tmp/openser_fifo'); #openser file is getting corrupted in vm, so deleting it
    my $DiscSpaceCmd = q(df -kh .);    
    unless ( $gen->execLinuxCmd($DiscSpaceCmd)) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to execute the disc space command");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- $gen->{CMDRESULTS}->[1]");
    # check Disk space on gen machine

    unless ( &checkDiskSpace($gen->{CMDRESULTS}->[1]) ) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  there is not enough disc space for running the regression");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    unless ($gen->{TESTBED_ALIAS_DATA}->{SYS}->{1}->{PLATFORM} =~ /^VM/) {
        unless ( $gen->execCmd("ifconfig pci0 2>/dev/null | grep -i 'UP BROADCAST RUNNING MULTICAST'")) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  HK card is down, media connectiviy not found");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    
    unless (&syncTime( )) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> failed to sysnc the time on duts");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }

    # check if the job wish to configure nextest machine or not
    unless ($jobData->[0]->[13]) {
        unless (&verifyConfig()) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> failed to check/change the hosts file");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }    
    }
    
    unless (&checkPasswordLessConnectivity( )) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> password less conectivity failed");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
   

} #END sub init


sub syncTime {

    #get the time from gen machine
    my $sub_name = "syncTime";
    $reg_execution_logger->info("Reg::runRegression::$sub_name --> Entered sub");
    my $dateCmd = q(date);
    unless ( $gen->execLinuxCmd($dateCmd)) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to execute the command");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    my $timeOnGen = $gen->{CMDRESULTS}->[0];

    $reg_execution_logger->debug("Reg::runRegression::$sub_name time on GEN machine is $timeOnGen");
    # Now set the same time on two duts
    my $setDateCmd = "date -s \"$timeOnGen\"";
    $reg_execution_logger->debug("Reg::runRegression::$sub_name set time command on two duts is $setDateCmd");

    unless ( $dut->execLinuxCmd($setDateCmd)) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to execute the command");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    $reg_execution_logger->debug("Reg::runRegression::$sub_name set time on primary sbc now going to set time on secondary sbc $setDateCmd");
    if (defined $dut->{STANDBY}) {
        unless ( $dut->{STANDBY}->execLinuxCmd($setDateCmd)) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to execute the command");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    $reg_execution_logger->debug("Reg::runRegression::$sub_name: <-- Leaving sub [1]");
    return 1;

}

sub verifyConfig {
    my $sub_name = "verifyConfig";
    my $filename = "/$log_dir/hosts";
    $reg_execution_logger->debug("Reg::runRegresson $sub_name: --> Entered Sub");
    
    unless ($gen->execLinuxCmd('hostname')) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Failed to get hostanme on Gen");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }
    
    my $hostname = $gen->{CMDRESULTS}->[0];
    my $shortHost = $hostname;
    $shortHost =~ s/\.\S+//;
    
    my ($eth2, $eth3) = ($gen->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}, $gen->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP});
    my ($eth2Nw, $eth3Nw) = ($eth2, $eth3);
    $eth2Nw =~ s/(.+)\..+?$/$1/;
    $eth3Nw =~ s/(.+)\..+?$/$1/;
    my $mgmtNw = $gen->{TESTBED_ALIAS_DATA}->{MGMT}->{1}->{IP};
    $mgmtNw =~ s/(.+)\..+?$/$1/;

    unless ($gen->execLinuxCmd('ifconfig eth2 | grep "Mask:"')) {
         $reg_execution_logger->error(__PACKAGE__ . ".$sub_name Failed to get Mask for eth2 on Gen");
         $reg_execution_logger->error(__PACKAGE__ . ".$sub_name <-- Leaving sub [0]");
         return 0;
    }

    my $mask = $gen->{CMDRESULTS}->[0];
    #$mask =~ s/.*Mask:(\S+)/$1/;
    $mask =~ s/.*Mask:\D*(\d+?\.\d+?\.\d+?\.\d+)/$1/;
    my $natIp = '192.168.0.100   nat_public1
192.168.0.101   nat_public2
192.168.2.100   nat_public3
192.168.1.100   nat_private1
192.168.1.101   nat_private2
192.168.3.100   nat_private3
192.168.4.100   nat_private4';
    if ($mask ne '255.255.255.0') {
    $natIp = '192.0.0.100   nat_public1
192.0.0.101   nat_public2
192.2.2.100   nat_public3
192.1.1.100   nat_private1
192.1.1.101   nat_private2
192.3.3.100   nat_private3
192.4.4.100   nat_private4';
    }
    
    my $content = '############ Auto Generated ############
#
#
# hosts         This file describes a number of hostname-to-address
#               mappings for the TCP/IP subsystem.  It is mostly
#               used at boot time, when no name servers are running.
#               On small systems, this file can be used instead of a
#               "named" name server.
# Syntax:
#    
# IP-Address  Full-Qualified-Hostname  Short-Hostname
#
 
127.0.0.1       localhost
 
# special IPv6 addresses
::1             localhost ipv6-localhost ipv6-loopback
 
fe00::0         ipv6-localnet
 
ff00::0         ipv6-mcastprefix
ff02::1         ipv6-allnodes
ff02::2         ipv6-allrouters
ff02::3         ipv6-allhosts
169.254.0.1     hhn
169.254.0.2     hk

';

my ($sbcEth2Nw, $sbcEth3Nw) = ($dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}, $dut->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP});

$sbcEth2Nw =~ s/(.+)\..+?$/$1/;
$sbcEth3Nw =~ s/(.+)\..+?$/$1/;

my $radius = 221;
if ($gen->{TESTBED_ALIAS_DATA}->{PRI_RADIUS}->{1}->{IP} =~ /\.(\d+?)$/) {
    $radius = $1;
}

    $content .= $dut->{OBJ_HOSTS}->[0] ."\tmymsw\n";
$content .= $dut->{STANDBY}->{OBJ_HOSTS}->[0] ."\tbkupmsw\n" if (defined $dut->{STANDBY});
#### For DSBC, Q50 ip adress ######3
#print Dumper(\%TESTBED);
if ($testBedData->[0]->[4] eq 'D-SBC' ) {
    unless (defined $TESTBED{'ams:1:ce0:hash'}->{MGMT}->{1}->{'IP'}) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> myq50 ip is missing");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    $content .= $TESTBED{'ams:1:ce0:hash'}->{MGMT}->{1}->{'IP'} ."\tmyq50\n" ;
}
############################
$content .= $gen->{TESTBED_ALIAS_DATA}->{MGMT}->{1}->{IP} ."\tmygen $hostname $shortHost\n\n\n";

$content .= "$dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{IP}     pub_rsa staticrealm pub_test.com
$dut->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{IP}     prv_rsa dynamic_realm qanextest.com qanextest.com.
${sbcEth2Nw}.7       rh_realm_c enum_realm
${sbcEth3Nw}.8       rh_realm_psx
##Proxy realm entry
$dut->{TESTBED_ALIAS_DATA}->{PROXY_RSA}->{1}->{IP}     proxy_realm
##
 
# Public addresses
${eth2Nw}.119     public1 ps1.abc.com
${eth2Nw}.112     public2
${eth2Nw}.113     public3 tr_sip_ep1
${eth2Nw}.114     public4
${eth2Nw}.115     public5
${eth2Nw}.116     public6
${eth2Nw}.117     public7
${eth2Nw}.118     public8 ast_sipproxy sipproxy.e164.com openser
${eth2Nw}.129     public9
${eth2Nw}.18      public10
${eth2Nw}.11      public11
${eth2Nw}.12      public12
${eth2Nw}.13      public13
${eth2Nw}.14      public14
${eth2Nw}.15      public15
${eth2Nw}.16      public16 nxgenIP4
${eth2Nw}.17      public17 nxgenIP1
 
${eth2Nw}.20      chicago
${eth2Nw}.21      seattle
${eth2Nw}.22      portland
${eth2Nw}.23      newyork
${eth2Nw}.24      boston
${eth2Nw}.25      maryland
 
# Private addresses
${eth3Nw}.127     private1
${eth3Nw}.112     private2
${eth3Nw}.113     private3 tr_sip_ep2
${eth3Nw}.114     private4
${eth3Nw}.115     private5
${eth3Nw}.116     private6
${eth3Nw}.117     private7
${eth3Nw}.118     private8
${eth3Nw}.119     private9
${eth3Nw}.18      private10
${eth3Nw}.11      private11
${eth3Nw}.12      private12
${eth3Nw}.3       private13
${eth3Nw}.14      private14
${eth3Nw}.15      private15
${eth3Nw}.16      private16 nxgenIP3
${eth3Nw}.17      private17 nxgenIP2
 
 
${eth3Nw}.20      sandiego
${eth3Nw}.21      phoenix
${eth3Nw}.22      atlanta
${eth3Nw}.23      miami
${eth3Nw}.24      london
${eth3Nw}.25      texas
 
#CODENOMICON
${eth2Nw}.28      codenomicon1
${eth2Nw}.29      codenomicon2
${eth2Nw}.30      codenomicon3
${eth2Nw}.31      codenomicon4
 
# CLIENT AND SERVER
${eth3Nw}.30      client
${eth3Nw}.31      server
 
# IP ADDRESSES USED BY GNUGK, NXGEN (FOR MEDIA) AND SER
${eth2Nw}.32      gatekeeper1
${eth3Nw}.32      gatekeeper2
${eth2Nw}.34      sipproxy proxy.e164.com
#IP ADDRESSES USED BY SER for 8.3 OBP scenarios
${eth2Nw}.38       sipproxy2 

# nxgenIP1, nxgenIP2 and nxgenIP3 are defined above
 
# IP ADDRESSES USED BY RADIUS SERVER
${mgmtNw}.". $radius ."  radiusprimary
${mgmtNw}.". ($radius+1) ."  radiussecondary
${mgmtNw}.". ($radius+2) ."  radiusthird
${mgmtNw}.". ($radius+3) ."  radiusfourth
${mgmtNw}.". ($radius+4) ."  radiusfifth radiusfifthbackup
${mgmtNw}.". ($radius+5) ."  radiussixth
${mgmtNw}.". ($radius+6) ."  radiusfirst
${mgmtNw}.". ($radius+7) ."  radiussecond
 
 
# IP ADDRESSES USED BY NAT - NOT TO BE CHANGED
$natIp
 
# IP ADDRESSES USED BY NAT - SHOULD BE UNIQUE
${eth2Nw}.26      pub_nat
${eth2Nw}.27      pub_nat1
${eth2Nw}.40      pub_nat2
${eth3Nw}.26      prv_nat
${eth3Nw}.65      prv_nat1
${eth3Nw}.66      prv_nat2

# MAIL PARAMETER
192.168.15.37   mail.nextone.com
$eth2       eth2
$eth3       eth3
${sbcEth2Nw}.95      pcscf_access_rsa
${sbcEth3Nw}.95      pcscf_ims_rsa\n";
    
    my $write = '';
    unless (open($write, ">$filename")) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Can't open $filename: $!");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    print $write $content;
    close $write;
    
    #unless ($gen->execLinuxCmd("cp /etc/hosts /etc/hosts_$timestamp")) {
    #     $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Failed to make backup of hosts file");
    #     $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
    #     return 0;
    #}
    
    my $scpHostCmd = "scp root\@172.16.26.92:/$log_dir/hosts /etc/hosts";
    unless ($gen->scpFile( -scpCmd => $scpHostCmd,  -password => 'By2GYH')) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> failed to copy the modified host file \"$scpHostCmd\"");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }
    unlink $filename;
    
    unless ($gen->execLinuxCmd('ifconfig eth2 | grep "Mask:"')) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Failed to get Mask for eth2 on Gen");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }

    $mask = $gen->{CMDRESULTS}->[0];
    #$mask =~ s/.*Mask:(\S+)/$1/;
    $mask =~ s/.*Mask:\D*(\d+?\.\d+?\.\d+?\.\d+)/$1/;
    my $maskBit = ($mask eq '255.255.255.0') ? 24 :16;
    my $mediaCard = ($dut->{PLATFORM} =~ /q21/i ) ? 'q21' : 'Cavium' ;
    
    my $dutType = lc $testBedData->[0]->[4];
    $dutType =~ s/-//;
    my $cliType = lc $testBedData->[0]->[5];
    
    my $userConfigContent = '#####################################################################################
# This file is a sample user configuration file which contains the different values 
# used by Nextest. Please create the userConfig.cfg file under $HOME/.nextest/ using
# this file as a template. Please DO NOT modify the name of the variables!
#####################################################################################

# regression type i.e. full, dsp, h.248, ipv6, smoke, s9';
    $userConfigContent .= "\nautomation = \"" . $regressionType . "\"\n";
    $userConfigContent .= "# dut type i.e. dsbc, vsbc, isbc\n";
    $userConfigContent .= 'duttype = "' . $dutType . "\"\n";
    $userConfigContent .= "# cli type i.e. confd, shell\n";
    $userConfigContent .= 'clitype = "' . $cliType . "\"\n\n";
    
    $userConfigContent .= "#  Default Subnet Mask to be used for the Realms\n";
    $userConfigContent .= 'realm_default_mask = ' . $maskBit . "\n\n";
    
    $userConfigContent .= "#  Netmask to be used for the Public Realm\n";
    $userConfigContent .= 'realm_public_mask = ' . $maskBit . "\n\n";
    
    $userConfigContent .= "#  Netmask to be used for the Private Realm\n";
    $userConfigContent .= 'realm_private_mask = ' . $maskBit . "\n\n";
    if ($testBedData->[0]->[4] eq 'D-SBC') {
        $userConfigContent .= '########## below entry are q50 config specific ########
#  Netmask to be used for the H248 Realm' . "\n";
        $userConfigContent .= 'realm_h248_mask = "' . $mask . "\"\n\n";
    
        $userConfigContent .= "# Ethernet Interface Number to be assigned to the H248 Realm\n";
        $userConfigContent .= "realm_h248_interface = $dut->{TESTBED_ALIAS_DATA}->{H248_RSA}->{1}->{INTERFACE} 

h248_vlan_id = $dut->{TESTBED_ALIAS_DATA}->{H248}->{1}->{VLAN}
h248_rsa = \"$dut->{TESTBED_ALIAS_DATA}->{H248_RSA}->{1}->{IP}\"

mymsw_mgc_port = 2944

myq50_mgid = \"$TESTBED{'ams:1:ce0:hash'}->{MG}->{1}->{ID}\"
myq50_vmgid = \"$TESTBED{'ams:1:ce0:hash'}->{VMG}->{1}->{ID}\"
myq50_mg_addr = \"$TESTBED{'ams:1:ce0:hash'}->{MG}->{1}->{IP}\"
myq50_mg_port = $TESTBED{'ams:1:ce0:hash'}->{MG}->{1}->{PORT}

myq50_h248_base_interface = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{BASE_INTERFACE}\"
myq50_h248_base_interface_port = $TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{BASE_INTERFACE_PORT}
myq50_h248_interface = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{INTERFACE}\"
myq50_h248 = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{IP}\"
myq50_h248_mask = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{NETMASK}\"
myq50_h248_gw = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{GATEWAY}\"

myq50_pubmed_base_interface = \"$TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{BASE_INTERFACE}\"
myq50_pubmed_base_interface_port = $TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{BASE_INTERFACE_PORT}
myq50_pubmed_interface = \"$TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{INTERFACE}\"

myq50_prvmed_base_interface = \"$TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{BASE_INTERFACE}\"
myq50_prvmed_base_interface_port = $TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{BASE_INTERFACE_PORT}
myq50_prvmed_interface = \"$TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{INTERFACE}\"

myq50_pubmed_id = $TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{ID}
myq50_prvmed_id = $TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{ID}

myq50_pub_rtp = \"$TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{RTP}\"
myq50_prv_rtp = \"$TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{RTP}\"

myq50_pubmed_routing_table = \"$TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{ROUTING_TABLE}\"
myq50_pubmed_routing_id = $TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{ROUTING}
myq50_pubmed_route = $TESTBED{'ams:1:ce0:hash'}->{PUB_MEDIA}->{1}->{ROUTE}

myq50_prvmed_routing_table = \"$TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{ROUTING_TABLE}\"
myq50_prvmed_routing_id = $TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{ROUTING}
myq50_prvmed_route = $TESTBED{'ams:1:ce0:hash'}->{PRIV_MEDIA}->{1}->{ROUTE}

myq50_h248_routing_table = \"$TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{ROUTING_TABLE}\"
myq50_h248_routing_id = $TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{ROUTING}
myq50_h248_route = $TESTBED{'ams:1:ce0:hash'}->{H248}->{1}->{ROUTE}

########################################################\n";
    }

    $userConfigContent .= "

#  Default Ethernet Interface number to be assigned to the Realm  
realm_default_interface = $dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{INTERFACE} 

#  Ethernet Interface Number to be assigned to the Public Realm  
realm_public_interface = $dut->{TESTBED_ALIAS_DATA}->{PUB_RSA}->{1}->{INTERFACE}

#  Ethernet Interface Number to be assigned to the Private Realm  
realm_private_interface = $dut->{TESTBED_ALIAS_DATA}->{PRIV_RSA}->{1}->{INTERFACE} 

#  30978 
#  Interface Number of the MSW to which the Management IP is assigned
mgmt_interface = 0

#  Local Ethernet Interface Number to be used for Public addresses  
eth_pub_iface = 2 

#  Local Ethernet Interface Number to be used for Private addresses  
eth_pri_iface = 3\n\n";

    $userConfigContent .= "pub_vlan_id = $dut->{TESTBED_ALIAS_DATA}->{PUB_VNET}->{1}->{VLAN}\n" if (defined $dut->{TESTBED_ALIAS_DATA}->{PUB_VNET}->{1}->{VLAN} and $dut->{TESTBED_ALIAS_DATA}->{PUB_VNET}->{1}->{VLAN} > 0);
    $userConfigContent .= "pri_vlan_id = $dut->{TESTBED_ALIAS_DATA}->{PRIV_VNET}->{1}->{VLAN}\n" if (defined $dut->{TESTBED_ALIAS_DATA}->{PRIV_VNET}->{1}->{VLAN} and $dut->{TESTBED_ALIAS_DATA}->{PRIV_VNET}->{1}->{VLAN} > 0);
    
    $userConfigContent .= qq(
#  Public Media ip address to be assigned to the Hotknife interface hk0,0  
mymsw_pubmed = "$dut->{TESTBED_ALIAS_DATA}->{PUB_MEDIA}->{1}->{IP}"
mymsw_pubmed2 = "10.10.10.11"

#  Netmask to be assigned to the Hotknife interface hk0,0
mymsw_pubmed_mask = "$mask"

#  Private Media ip address to be assigned to the Hotknife interface hk0,1  
mymsw_prvmed = "$dut->{TESTBED_ALIAS_DATA}->{PRIV_MEDIA}->{1}->{IP}"
mymsw_prvmed2 = "10.10.11.11"

#  Netmask to be assigned to the Hotknife interface hk0,1
mymsw_prvmed_mask = "$mask"

#  Gateway to be assigned to the Public Hotknife interface hk0,0  
mymsw_pubmed_gw = "$dut->{TESTBED_ALIAS_DATA}->{PUB_MEDIA}->{1}->{GATEWAY}"

#  Gateway to be assigned to the Private Hotknife interface hk0,1  
mymsw_prvmed_gw = "$dut->{TESTBED_ALIAS_DATA}->{PRIV_MEDIA}->{1}->{GATEWAY}"

#  DB Sync Timer in seconds - REQUIRED ONLY FOR ISERVER VERSIONS >= 4.2
#  Please enter 0 for other versions
dbsync_timer = 5


# *************** TRANSCODER DETAILS - START ************** #

#  Transcoder IP Address
#transcoder_ip = "10.10.10.100"

#  Transcoder NetMask
#transcoder_mask = "255.255.255.0"

#  Port Number used by the Transcoder
#transcoder_port = "2424"

#  Transcoder Model
#transcoder_model = "TP-6310"

#  Transcoder License
#transcoder_license = "60"

# *************** TRANSCODER DETAILS - END ************** #


# *************** RADIUS SERVER DETAILS - START ************** #

#  Ethernet Interface on which the radius ip addresses should be added
radius_eth_iface = "0"

# *************** RADIUS SERVER DETAILS - END ************** #

# ********************CODENOMICON - START ************************** #
# This is the total number of codenomicon test cases. Total test cases
# for version 3.0 is 42942. 
# Ticket-36225: This value also indicates the number of testcases after
# which Sanity Test is performed.
codenomicon_Test_Chunk = 44092
# Ticket-36225: Parameter to enable/disable External Sanity Test
enableSanityTest = False 

# ********************CODENOMICON - END *************************** #

# *************** SCM DETAILS - START ************** #
#  Ethernet Interface name that connects the Primary and Backup MSW and
#  which will act as the Control Interface
scm_eth_iface = "$dut->{TESTBED_ALIAS_DATA}->{HA_SELF}->{1}->{INTERFACE}"

# *************** SCM DETAILS - END **************** #

# ************** COREWATCHER PARAMETERS - START ************** #
#  These Parameters are used for sending mails to concerned release manager
#  in case of core with option '--watch mymsw' given on commadline.
# This address defines from where the user wants to send mail.
# Changes made for ticket # 34247.
# For nextone environment from_addr is nexassist\@nextone.com, It is fixed for
# both sending mail in case of Core and also in case sending an attachment with 
# the mail. 
from_addr = "nexassist\@nextone.com"
# This defines the to-address/addresses, all the addresses must be enclosed
# in double quotes("") and separated by commas(,)
to_addr = "tlin\@nextone.com,bgundlach\@nextone.com,jokafor\@nextone.com,engtest\@nextone.com"
# This defines the mail server through which mail will be sent.
# In case of US machines it will be fixed to mail.nextone.com
mail_server = "mail.nextone.com"
# Changes for ticket 34247
# Two paratmeters added for user authentication and also to solve the issue of mail not received
# by multiple recipients. These two parameters 'login' and 'passwd' are for US machines.
login = "nexassist"
passwd = "sitverify"

# Ticket 28643:
# Flag to control stopping of the QMTest execution engine upon core detection
# True  =>  QMTest execution engine will stop upon detection of any core file
# Flase =>  QMTest execution engine will continue executing the testcases even
#           when cores are generated on MSW
stop_on_core = False 

# ************** COREWATCHER PARAMETERS - END ************** #

#Ticket 29725 changes
#************** GLOBAL TIMER VARIABLES - START **************** #

# Timeout value for assert functions
assertTimeout = 180

# Timeout value for Iserver start
iserverStartTimeout = 1000

# Timeout value for Iserver stop
iserverStopTimeout = 180

# Timeout value for Jserver commands 
jServerTimeout = 120

# Timeout value for cli commands 
cliTimeout = 60

# Timeout value for ssh sessions 
sshTimeout = 60

# Timeout value for assert media  
mediaTimeout =  60

# Timeout value for gens 
genTimeout =  60

# ************** GLOBAL TIMER VARIABLES - END ****************

# ************** GLOBAL TIMER VARIABLES - END ****************


#Ticket 29859 changes

#****************EMAIL ATTACH PARAMETERS - START ****************

# A User-Defined variable for deciding whtherto send  mails after every test suite completion ot not, Its value is 0, when one wants
# send the mail at the end of test suite or test case completion.
# By default its value is non-zero, here in this it is given as 1
checkEndSuite = 1
# Path for the output_file is defined here as the .txt results file  will be stored at this path with the name of the iserver release and
# test suite or test case pre-pended
output_file = "/var/opt/nextest/tdb/"

#***************EMAIL ATTACH PARAMETERS - END *******************


#****************MEDIA CARD PARAMETERS - START ****************

#Media Card that is present in the MSW - Valid values are Cavium/HKNIFE
#Ticket # 36415: Parameter used for specifying the type of Media Card
#default value is "HKNIFE"

media_card = "$mediaCard"

#****************MEDIA CARD PARAMETERS - END **************** 

#****************OPENSIPS PARAMETERS - START ****************
service_route_hdr_1 = "10.10.10.10"
service_route_hdr_2 = "10.10.10.11"
service_route_hdr_port = "5062"

#****************OPENSIPS PARAMETERS - END ****************\n\n);
    
    my $userFile = "/$log_dir/userConfig.cfg";
    my $uConf = '';
    unless (open($uConf, ">$userFile")) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Can't open $userFile: $!");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    print $uConf $userConfigContent;
    close $uConf;
    
    $scpHostCmd = "scp root\@172.16.26.92:/$log_dir/userConfig.cfg /home/test/.nextest/userConfig.cfg";
    unless ($gen->scpFile( -scpCmd => $scpHostCmd,  -password => 'By2GYH')) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> failed to copy the modified host file \"$scpHostCmd\"");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }
    unlink $userFile;

    return 1;

    
    #my @patterns = ("s/automation *=.*/automation = \"$regressionType\"/", "s/media_card *=.*/media_card = \"$mediaCard\"/","s/realm_default_mask *=.*/realm_default_mask = $maskBit/", "s/realm_public_mask *=.*/realm_public_mask = $maskBit/", "s/realm_private_mask *=.*/realm_private_mask = $maskBit/", "s/mymsw_pubmed *=.*/mymsw_pubmed = \"${eth2Nw}.51\"/","s/mymsw_pubmed_mask *=.*/mymsw_pubmed_mask = \"$mask\"/", "s/mymsw_prvmed *=.*/mymsw_prvmed = \"${eth3Nw}.51\"/", "s/mymsw_prvmed_mask *=.*/mymsw_prvmed_mask = \"$mask\"/", "s/mymsw_pubmed_gw *=.*/mymsw_pubmed_gw = \"${eth2Nw}.1\"/", "s/mymsw_prvmed_gw *=.*/mymsw_prvmed_gw = \"${eth3Nw}.1\"/");
    
    #foreach (@patterns) {
    #    $gen->execLinuxCmd("sed -i '$_' /home/test/.nextest/userConfig.cfg");
    #}
    
    unless ($gen->generateNxTestSshKey( -isHa => (( defined $dut->{STANDBY}) ? 1 : 0))) {
        $reg_execution_logger->error(__PACKAGE__ . ".$sub_name: ERROR -> failed to genrate ssh key");
        $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: <-- Leaving sub [0]");
        return 0;
    }

    unless ($dut->execLinuxCmd('grep -w "hk" /etc/hosts | grep -ve \'^\s*#\' ')) {
        $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: hk entry is not found in sbc hosts file adding it");
        $dut->execLinuxCmd('echo "169.254.0.2     hk" >>/etc/hosts');
    }
    unless ($dut->execLinuxCmd('grep -w "hhn" /etc/hosts | grep -ve \'^\s*#\' ')) {
        $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: hk entry is not found in sbc hosts file adding it");
        $dut->execLinuxCmd('echo "169.254.0.1     hhn" >>/etc/hosts');
    }
    unless ($dut->execLinuxCmd('grep -w `hostname` /etc/hosts | grep -ve \'^\s*#\' ')) {
        $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: hk entry is not found in sbc hosts file adding it");
        $dut->execLinuxCmd('echo "127.0.0.2       "`hostname`".genband.com "`hostname` >>/etc/hosts');
    }
    
    $reg_execution_logger->debug("Reg::runRegression::$sub_name: <-- Leaving sub [1]");
    return 1;
}

sub checkDiskSpace {

    my $cmdResult = shift;
    my $sub_name = "checkDiskSpace";

    $reg_execution_logger->debug("$sub_name: --> Entered Sub ");

    my $diskSpaceComponent = {};

    my $processOP = $cmdResult;
    my @comp = split(/[ ]+/, $processOP);
    $diskSpaceComponent->{'Size'}  = $comp[1];
    $diskSpaceComponent->{'Used'}  = $comp[2];
    $diskSpaceComponent->{'Avail'} = $comp[3];
    $diskSpaceComponent->{'Use%'}  = $comp[4];
    $diskSpaceComponent->{'Use%'} =~ s/%//;
    my $freeSpace = int(100 - $diskSpaceComponent->{'Use%'} );
    $reg_execution_logger->debug("Reg::runRegression:: $sub_name: <-- Disk space uses is Available : $diskSpaceComponent->{'Avail'} used : $diskSpaceComponent->{'Use%'}");
    if ( $freeSpace >= 5 ) {
        $reg_execution_logger->debug("Reg::runRegression::$sub_name: <-- enough disk space uses is Available : Free space is $freeSpace :: Avail:: $diskSpaceComponent->{'Avail'} used : $diskSpaceComponent->{'Use%'}");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name: <-- Leaving sub [1]");
        return 1;
    } else {
        $reg_execution_logger->debug("Reg::runRegression:: $sub_name: <-- Disk space is not suffcient : $diskSpaceComponent->{'Avail'} used : $diskSpaceComponent->{'Use%'}");
        $reg_execution_logger->debug("Reg::runRegression:: $sub_name: <-- Leaving sub [1]");
        return 0;
    }

}


sub checkPasswordLessConnectivity {

    my $sub_name = 'checkPasswordLessConnectivity';

    $reg_execution_logger->debug("Reg::runRegression::Entering sub $sub_name ");
    #change the user to test user
    unless ( $gen->becomeUser(-userName => 'test')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login as test user");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    $reg_execution_logger->debug("Reg::runRegression::Logged in as test user ");
    $gen->{conn}->cmd(String => 'rm -f /home/test/.ssh/known_hosts', Prompt => '/.*[\$%#\}\|\>] $/');
    my ($match, $prematch) = ('','');
    $gen->{conn}->print( 'ssh root@mymsw');
        
    unless (($prematch, $match) = $gen->{conn}->waitfor(-match => '/yes\/no/', -match => '/.*[\$%#\}\|\>] $/')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login from gen to prinmary sbc as test user passwordless");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    
    
    if ($match =~ /yes\/no/) {
        $gen->{conn}->print( 'yes');
        unless ($gen->{conn}->waitfor(-match => '/.*[\$%#\}\|\>] $/')) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login from gen to prinmary sbc as test user passwordless");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    
    unless ($gen->{conn}->cmd(String => 'exit', Prompt => '/.*[\$%#\}\|\>] $/')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  failed to logout from mymsw after password less connectivity");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $reg_execution_logger->debug("Reg::runRegression::done password less connectivity to primary sbc ");
    
    if (defined $dut->{STANDBY}) {
        $gen->{conn}->print( 'ssh root@bkupmsw');
        
        unless (($prematch, $match) = $gen->{conn}->waitfor(-match => '/yes\/no/', -match => '/.*[\$%#\}\|\>] $/')) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login from gen to secondry sbc as test user passwordless");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
        
        if ($match =~ /yes\/no/) {
            $gen->{conn}->print( 'yes');
            unless ($gen->{conn}->waitfor(-match => '/.*[\$%#\}\|\>] $/')) {
                $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login from gen to secondry sbc as test user passwordless");
                $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
                return 0;
            }
        }
        
        unless ($gen->{conn}->cmd(String => 'exit', Prompt => '/.*[\$%#\}\|\>] $/')) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  failed to logout from mymsw after password less connectivity");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return 0;
        }
    }
    
    unless ($gen->{conn}->cmd(String => 'exit', Prompt => '/.*[\$%#\}\|\>] $/')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  failed to switch back to root user");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }    
    
    $reg_execution_logger->debug("Reg::runRegression:: $sub_name: <-- Leaving sub [1]");

    return 1;

}


sub runQmtest {

    my $build = shift;
    my $sub_name = 'runQmtest';
    $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- entering sub");
    my ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
    my $timestamp = sprintf "%4d%02d%02d-%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
    my $logDir = "/var/opt/nextest/tdb/logs/$build/$timestamp";

    $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- entering sub");

    
    my @suitesToExecute = (); #This guy is big, holds all the shit to run
    my $suiteType = '';
    my %suiteIds = ();
    my %testsToExecute = ();
    my @oldMainFeature = ();
    my $oldSuiteId = '';
    my %mainProvision = ();
    my %notFound = ();
    
    my $featureName = '';
    my $oldFeatureName = '';
    my $cleanStart = 0;
    foreach my $row (@{$testData}) {
        my @currentMainFeature = ();
        my $suitePath = $row->[2];
        
        ############ look for tests in nextest machine#######
        my @qmtFiles = $gen->{conn}->cmd(String => "ls -1 /var/opt/nextest/tdb/$suitePath/*.qmt 2>/dev/null | xargs -n1 basename 2>/dev/null | grep -v 'provision.qmt' | grep -v 'xit.qmt' | awk -F'.' {'print \$1'} 2>/dev/null");
        chomp @qmtFiles;
        @qmtFiles = grep /\S/, @qmtFiles;
        map{$_ =~ s/\s//g} @qmtFiles;
        
        next unless @qmtFiles;
        #####################################################
        
        $suitePath =~ s/\.qms//g;
        
        my @tempPath = split('/', $suitePath);
        
        ##### injecting intermediate provisions ##############
        $featureName = $tempPath[1];
        print "$featureName = $oldFeatureName = $row->[5]\n";
        push (@suitesToExecute, $tempPath[0] . '.provision') if (($featureName ne $oldFeatureName) and ($cleanStart == 1));
        ######################################################
        
        
        $suitePath =~ s/\//./g;
        map {push(@currentMainFeature, join('.',@tempPath[0..$_]))} 0..$#tempPath;
        
        if ($suiteType ne $row->[3]) {
            my @temp = split(/\./, $suitePath);
            $mainProvision{$temp[0]} = 1;
            unless ($skipBaseConfig) {
                if (($executeOnly eq 0 or $executeOnly =~ /CONFIG/) and ($testBedData->[0]->[4] ne 'G9')) {
                    push (@{$testsToExecute{$temp[0]}} , 'provision');
                    push (@suitesToExecute, $temp[0] . '.provision');
                }
            }
            $suiteType = $row->[3];
        }
        my $tc = &Genband::Utils::executeSqlCmd("select regressiontests_testcases from regressiontests where regressiontests_suiteuuid = \'$row->[4]\'");
        
        my $injectedProvision = '';
        
        if ($row->[1] and $row->[1] !~ /NULL/i) {
            foreach my $oldFea (reverse @oldMainFeature[1..($#oldMainFeature-1)]) {
                unless(grep(/^\Q$oldFea\E$/, @currentMainFeature)) {
                    $injectedProvision = pop(@suitesToExecute) if (($featureName ne $oldFeatureName) and ($cleanStart == 1));
                    push (@suitesToExecute, $oldFea . '.xit');
                    push (@suitesToExecute, $injectedProvision);
                    #push (@{$testsToExecute{$oldSuiteId}} , $oldFea . '.xit');
                }
            }
            if ($#tempPath > 1) {
                foreach (1..($#tempPath-1)) {
                    my $tempProv = join('.',@tempPath[0..$_]) . '.provision';
                    unless (grep (/^\Q$tempProv\E$/, @suitesToExecute)) {
                        push (@suitesToExecute, $tempProv) if ($executeOnly eq 0 or $executeOnly =~ /CONFIG/);
                        #push (@{$testsToExecute{$suitePath}} , $tempProv);
                    }
                }
            }
            my @tests = split(',', $row->[1]);
            
            my @actualTests = split(',', $tc->[0]->[0]);
            
            
            if ($executeOnly eq 0 or $executeOnly =~ /CONFIG/) {
                push (@suitesToExecute, $suitePath . '.provision');
                push (@{$testsToExecute{$suitePath}} , 'provision');
            } 
            if ($executeOnly eq 0 or $executeOnly =~ /TEST/) {
                my @validTests = ();
                foreach my $tcN (@tests) {
                    next unless (grep(/^$tcN$/, @actualTests));
                    next unless (grep(/^$tcN$/, @qmtFiles)); #do they actually exits in nextest machine
                    
                    push (@validTests, $tcN);
                }
                map {push (@suitesToExecute, $suitePath . ".$_")} @validTests;
                push (@{$testsToExecute{$suitePath}} , @validTests);
            } 
            if ($executeOnly eq 0 or $executeOnly =~ /CLEANUP/) {
                push (@suitesToExecute, $suitePath . '.xit');
                push (@{$testsToExecute{$suitePath}} , 'xit');
            }
            
            $suiteIds{$suitePath} =  $row->[4];           
            
        } else {
            foreach my $oldFea (reverse @oldMainFeature[1..($#oldMainFeature-1)]) {
                unless(grep(/^\Q$oldFea\E$/, @currentMainFeature)) {
                    $injectedProvision = pop(@suitesToExecute) if (($featureName ne $oldFeatureName) and ($cleanStart == 1));
                    push (@suitesToExecute, $oldFea . '.xit');
                    push (@suitesToExecute, $injectedProvision);
                    #push (@{$testsToExecute{$oldSuiteId}} , $oldFea . '.xit');
                }
            }
            if ($#tempPath > 1) {
                foreach (1..($#tempPath-1)) {
                    my $tempProv = join('.',@tempPath[0..$_]) . '.provision';
                    unless (grep (/^\Q$tempProv\E$/, @suitesToExecute)) {
                        push (@suitesToExecute, $tempProv);
                        #push (@{$testsToExecute{$suitePath}} , $tempProv);
                    }
                }
            }
            $suiteIds{$suitePath} =  $row->[4];
            my @tests = split(',', $tc->[0]->[0]);
            my @validTests = ();
            foreach my $tcN (@tests) {
                next unless (grep(/^$tcN$/, @qmtFiles)); #do they actually exits in nextest machine                
                push (@validTests, $tcN);
            }
            push (@{$testsToExecute{$suitePath}}, @validTests);
            push (@suitesToExecute, $suitePath);
        }
        @oldMainFeature = @currentMainFeature;
        $oldSuiteId = $suitePath;
        
        $oldFeatureName = $featureName;
        $cleanStart = $row->[5];
    }
    
    if ($#oldMainFeature > 1) {
	    foreach (reverse @oldMainFeature[1..($#oldMainFeature-1)]) {
            my $tempXit = $_ . '.xit';
            unless (grep(/^\Q$tempXit\E$/, @suitesToExecute)) {
                push (@suitesToExecute, $tempXit) if ($executeOnly eq 0 or $executeOnly =~ /CLEANUP/);;
                #push (@{$testsToExecute{$oldSuiteId}}, $tempXit);
            }
	    }
    }
    
    chomp @suitesToExecute;
    @suitesToExecute = grep /\S/, @suitesToExecute;
    $reg_execution_logger->debug("Reg::runRegression::$sub_name - Selected Suite -" . Dumper(\@suitesToExecute));
    #print Dumper(\%testsToExecute);
    #print Dumper(\@suitesToExecute);
    
    #change the user to test user
    unless ( $gen->becomeUser(-userName => 'test')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  not able to login as test user");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    $reg_execution_logger->debug("Reg::runRegression::$sub_name  Logged in as test user");
    #change the user to test user
    
    my $regCmd = "/opt/nextest/bin/qmtest run -c nextest.trace_level=DEBUG -c nextest.disable_debugflags=OFF -c nextest.radius_verify=OFF -c nextest.result_path=$logDir ";
    
    my @sbcObjs = ($dut);
    my $scmMode = '-c nextest.scm_configuration=OFF';
    if (defined $dut->{STANDBY}) {
        push (@sbcObjs, $dut->{STANDBY});
        $scmMode = '-c nextest.scm_configuration=ON';
    }
    
    $regCmd .= " $scmMode $debugMode ";
    
    my %summary = ();
    my %indivisual = ();
    my %reason = ();
    my %failedRun = ();
    my ($oldSuite, $path) = (0, '', '');
    
    my (@testPass, @testFail, @testErr, @testUnTested) = ((),(),(),());
    
    ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
    my $startTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
    my $sTime = $startTime;
    &Genband::Utils::executeSqlCmd("insert into regressionjobresult (regressionjob_uuid,StartTime) values ('$regJobID','$startTime')");
    my ($endTime, $content) = ('', '');
    my %failedProvision =();
    my %coreFound = ();
    
    my $countForCheck = 0;
    
    my $executionFailed = 0;
    
    MAIN: foreach my $suite (@suitesToExecute) {
        my @suiteStr = split(/\./, $suite);
        my $suiteName = $suite;
        next if (defined $coreFound{$suiteStr[1]});
        
        $suiteName =~ s/(.*)\..+?$/$1/ unless (defined $testsToExecute{$suiteName});
        if  ( not defined $indivisual{$suiteName} and defined $testsToExecute{$suiteName}) {
            $indivisual{$suiteName} = ();
        }
        
        if (defined $failedProvision{$oldSuite} and ($suiteName =~ /\Q$oldSuite\E\..*/ or $suiteName eq $oldSuite)) {
            ### if the higher provision failed, set the sub feature provision also failed
            $failedProvision{$suiteName} = 1;
            next MAIN;
        }
        
        &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Running $suite\" , automationLog=\'$gen->{sessionLog2}\'  where JobId = \'$regJobID\'");
                
        if (defined $testsToExecute{$oldSuite} and ($oldSuite ne $suiteName) and (not defined $summary{$oldSuite})) {
            ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
            $endTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
            
            
            map { $indivisual{$oldSuite}{$_} = 'ERROR' } @{$testsToExecute{$oldSuite}} if (defined $failedRun{$suiteName} );
                        
            map {not defined $indivisual{$oldSuite}{$_} and $indivisual{$oldSuite}{$_} = 'PASS' } @{$testsToExecute{$oldSuite}} ;
            $content = $jobContent . "<td>$startTime</td><td>$endTime</td></tr></table>" . '<br/><br/><table border="1" align="center"><tr>';
            $content .= '<th>Test Case</th><th>Result</th><th>Reason</th></tr>';
            
            my $failed = 0;
            
            foreach my $t (keys %{$indivisual{$oldSuite}}) {
                $content .= '<tr><td>'. $t . '</td><td>' . $indivisual{$oldSuite}{$t} . '</td><td>' . (defined $reason{$oldSuite}{$t} ? $reason{$oldSuite}{$t} : '') . '</td></tr>';
                next if ($t =~ /(provision|xit)/);
                push (@testPass, $t) if ( $indivisual{$oldSuite}{$t} eq 'PASS' );
                
                if ( $indivisual{$oldSuite}{$t} eq 'FAIL' ) {
                    push (@testFail, $t) ;
                    $failed = 1;
                }
                if ( $indivisual{$oldSuite}{$t} eq 'ERROR' ) {
                    push (@testErr, $t);
                    $failed = 1;
                }
                if ( $indivisual{$oldSuite}{$t} eq 'UNTESTED' ) {
                    push (@testUnTested, $t);
                    $failed = 1;
                }
                next if defined $mainProvision{$oldSuite};
                $summary{$oldSuite}{$indivisual{$oldSuite}{$t}}++;
            }
            
            $content .= "</table>";
            
            
            if ($notifyIfFailed) {
                &sendMail(-mailId => $mail, -status => $oldSuite, -externalBody => $content, -nxtestLog => "$logDir/$path", -ip =>  $gen->{OBJ_HOST}) if ($failed);
            } else {
                &sendMail(-mailId => $mail, -status => $oldSuite, -externalBody => $content, -nxtestLog => "$logDir/$path", -ip =>  $gen->{OBJ_HOST});
            }
            
            unless (defined $mainProvision{$oldSuite}) {  
                &Genband::Utils::executeSqlCmd("insert into regressionsuiteresult value ('$regJobID', '" . $suiteIds{$oldSuite} . "',". ($summary{$oldSuite}{'FAIL'} || 0) . "," .  ($summary{$oldSuite}{'PASS'} || 0) . "," .  ($summary{$oldSuite}{'ERROR'} || 0) . "," .  ($summary{$oldSuite}{'UNTESTED'} || 0) . ", '" . join(',', @testFail) . "','" . join(',', @testPass) . "','" . join(',', @testErr) . "','" . join(',', @testUnTested) . "','$startTime','$endTime')");
                (@testPass, @testFail, @testErr, @testUnTested) = ((),(),(),());
            }
            $startTime = $endTime;
            delete $indivisual{$oldSuite};
            
            $countForCheck++;
            
            if ($countForCheck and ($countForCheck%5 == 0)){
                my ($r, $fReason) = &healthCheck();                
                unless ($r) {
                    $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  DUT health check failed");
                     &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => $fReason . ", Hence stoping the execution");
                    $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
                    #return 0;
                    $executionFailed = 1;
                    &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
                    last MAIN;
                }
            }
        }
        
        
        foreach my $obj (@sbcObjs) {
            $obj->{conn}->cmd("mkdir -p /var/core/OLDCORES 2>/dev/null");
            $obj->{conn}->cmd("mv  /var/core/core*  /var/core/OLDCORES/ 2>/dev/null");
        }

        $reg_execution_logger->debug("Reg::runRegression::$sub_name - running test suite \'$suite\'");
        
        # Some code to check the presence of file
        if ($suite =~ /(provision|xit)/) {
            my $fileName = $suite;
            $fileName =~ s/\./\.qms\//g;
            $gen->{conn}->cmd(String => "ls /var/opt/nextest/tdb/$fileName.*", Prompt => '/.*[\$%#\}\>] $/');
            my @filePres = $gen->{conn}->cmd(String => "echo \$?", Prompt => '/.*[\$%#\}\>] $/');
            chomp @filePres;
        
            unless ($filePres[0] == 0) {
                next;
            }
        }
        $path = join('/', @suiteStr);
        
        $gen->{conn}->print($regCmd . " $suite");
        my ($pm, $mt) ;
        unless ( ($pm, $mt) = $gen->{conn}->waitfor(-match => '/.*[\$%#\}\>] $/', Timeout => 3600*4)) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  Failed to execute regression for \'$suite\'");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            #return 0;
            $executionFailed = 1;
            &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
            last MAIN;
        }
        
        if ($pm =~ /There is no test or suite with ID/i){
            next;
        }
                
        $reg_execution_logger->info("Reg::runRegression::$sub_name - Info -> $pm - $mt");
        ########################### My change for file name changed ####################### 
        my @resultFile = $gen->{conn}->cmd(String => "find $logDir/$path -name \"result.txt\" 2>/dev/null", Prompt => '/.*[\$%#\}\>] $/');
        chomp @resultFile;
        @resultFile = grep /\S/, @resultFile;
        foreach ( @resultFile ) {
           my($b, $c) = split("$logDir/",$_);
           my $origPath = $_;
           $origPath =~ s/result\.txt//;
           $c =~ s/\/result\.txt/-result\.txt/;
           $c =~ s/\//-/g;
           my $fName = $origPath.$c;
           unless ( $gen->{conn}->cmd(String => "cp $_ $fName 2>/dev/null", Prompt => '/.[\$%#\}\>] $/') ) {
               $reg_execution_logger->debug("command error cp $_ $fName");
           }
        }
        #################################################################
        $path = join('/', @suiteStr);
        if (( $suite !~ /provision/ or defined $mainProvision{$suiteName}) and (not defined $summary{$suiteName})) {
            
            my @filesPr = $gen->{conn}->cmd(String => "find $logDir/$path -name \"result.txt\" 2>/dev/null", Prompt => '/.*[\$%#\}\>] $/');
            chomp @filesPr;
            @filesPr = grep /\S/, @filesPr;
            
            $failedRun{$suiteName} = 1 unless(@filesPr);
            
            my @result = $gen->{conn}->cmd(String => "find $logDir/$path -name \"result.txt\" 2>/dev/null | xargs sed -n \'/TESTS THAT DID NOT PASS/,/STATISTICS/p\' | grep -e \".*: .*\"", Prompt => '/.*[\$%#\}\>] $/');
            @result = grep /\S/, @result;
            
            
            if (defined  $testsToExecute{$suiteName}) {
                foreach my $testLine (@result) {
                    chomp $testLine;
                    next unless ($testLine =~ /(\S+?)\s*\:\s*(\S*)/);
                    my ($tc, $r) = ($1, $2);
                    next unless ($tc =~ /$suiteName\.(.*)/);
                    $tc = $1;
                    
                    ### Let me ommit some junk tests coming in
                    next unless (grep(/^$tc$/, @{$testsToExecute{$suiteName}}));                    
                    
                    $r = 'UNTESTED' if ($r =~ /UNTESTED/);
                    $indivisual{$suiteName}{$tc} = $r;
                    if ($r =~ /(FAIL|ERROR|UNTESTED)/) {
                        my $lNum = 4;
                        $lNum = 1 if ($r eq 'ERROR');
                        $lNum = 10 if ($r eq 'UNTESTED');
                        my @failedReason = $gen->{conn}->cmd(String => "awk 'c&&!--c;/$tc *: *$r/{c=$lNum}' $filesPr[0] | head -1", Prompt => '/.*[\$%#\}\>] $/',  Timeout => 200) if ($filesPr[0] =~ /result\.txt/);;
                        chomp @failedReason;
                        $reason{$suiteName}{$tc} =  ($failedReason[0] =~ /^\s*pass\s*$/i) ? 'ERROR' : $failedReason[0];
                    }
                }
            
            }
            
            if ( defined $mainProvision{$suiteName} and $suite =~ /provision/) {
                last MAIN if (grep(/(UNTESTED|FAIL|ERROR)/, @result));
                unless ( @filesPr ) {
                    $indivisual{$suiteName}{'provision'} = 'ERROR';
                    $reason{$suiteName}{'provision'}  = 'QmTest Error';
                    last MAIN;
                }
            }
        } elsif ($suite =~ /provision/ ) {
            my @result = $gen->{conn}->cmd(String => "find $logDir/$path -name \"result.txt\" | xargs sed -n \'/TESTS THAT DID NOT PASS/,/STATISTICS/p\' | grep -e \".*: .*\"", Prompt => '/.*[\$%#\}\>] $/');
            chomp @result;
            if (grep(/(FAIL|ERROR)/, @result)) {
                &sendMail(-mailId => $mail, -status => $suiteName, -externalBody => "$suite execution failed, Hence subsuite execution will be skipped" , -nxtestLog => "$logDir/$path", -ip =>  $gen->{OBJ_HOST});
                $failedProvision{$suiteName} = 1;
            }
        }
        
        unless ($dut->checkForCore()) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  core found");
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  storing cores as per suite/case wise found");
            
            foreach my $obj (@sbcObjs) {
                my $tempPath = $suite;
                $tempPath =~ s/\./\//g;
                $obj->{conn}->cmd("mkdir -p /var/core/$tempPath 2>/dev/null");
                $obj->{conn}->cmd("mv /var/core/core* /var/core/$tempPath");
            }
            
            &sendMail(-mailId => $mail, -status => $suiteName, -externalBody => "Core found, stored in suitewise directory" , -nxtestLog => "/var/core/$path", -ip =>  $dut->{OBJ_HOST}, -impMsg => 'CORE: ');
            
            my @activeStatus = $dut->{conn}->cmd("cli ha | grep -i active");
            chomp @activeStatus;
            unless (@activeStatus) {
                unless ($dut->restartAll()) {
                    $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  failed to recover after core");
                     &sendMail(-mailId => $mail, -status => 'Failed', -externalBody => "core found, Failed to recover from core", -impMsg => 'CORE: FAILED TO RESUME: ');
                    $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
                    #return 0;
                    $executionFailed = 1;
                    &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
                    last MAIN;
                }
            }

            my @tempStr = split(/\./, $suite);
            my $prov = $tempStr[0] . ".provision";
            $coreFound{$tempStr[1]} = 1;
            my $tempPath = $tempStr[0] . "/provision";
            
            $gen->{conn}->print($regCmd . " $prov");            
            unless ( ($pm, $mt) = $gen->{conn}->waitfor(-match => '/.*[\$%#\}\>] $/', Timeout => 3600*3)) {
                $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  Failed to execute regression for \'$prov\'");
                $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
                #return 0;
                $executionFailed = 1;
                &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
                last MAIN;
            }
            my @result = $gen->{conn}->cmd(String => "find $logDir/$tempPath -name \"result.txt\" | xargs sed -n \'/TESTS THAT DID NOT PASS/,/STATISTICS/p\' | grep -e \".*: .*\"", Prompt => '/.*[\$%#\}\>] $/');
            
            if (grep(/(UNTESTED|FAIL|ERROR)/, @result)) {                    
                &sendMail(-mailId => $mail, -status => $suiteName, -externalBody => "Failed to execute Main Provision after the core" , -nxtestLog => "/var/core/$path", -ip =>  $dut->{OBJ_HOST}, -impMsg => 'CORE: FAILED TO RESUME: ');
                &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
                last MAIN ;
            }                    
            
        }
        # removing result.txt since new one is already created
        foreach ( @resultFile ) {
            unless ( $gen->{conn}->cmd(String => "rm $_ 2>/dev/null", Prompt => '/.[\$%#\}\>] $/') ) {
               $reg_execution_logger->debug("clean up of result.txt");
            }
        }        
        $oldSuite =$suiteName;
        
        my $jobCanceled = &Genband::Utils::executeSqlCmd("select jobCancel from sched_job_queue where JobId = \'$regJobID\'");
        
        if ($jobCanceled->[0]->[0] == 1) {         
            if (!defined $mainProvision{$oldSuite} and $suite !~ /xit$/) {
                $reg_execution_logger->info("Perf::sbcPerf - INFO ->  running ${suite}.xit");
                $gen->{conn}->print($regCmd . " ${suite}.xit");
                $gen->{conn}->waitfor(-match => '/.*[\$%#\}\>] $/', Timeout => 900);
            }            
            &sendMail(-mailId => $mail, -status => 'Canceled', -externalBody => "Job '$regJobID' Canceled by user");
            
            &Genband::Utils::executeSqlCmd("update regressionjobresult set Cancelled = '1' where regressionjob_uuid = \'$regJobID\'");
            $executionFailed = 1;
            #Genband::Base::forcedDestroy();
            #$reg_execution_logger->logdie("Perf::sbcPerf - DIE ->  Job called for cancellation");
            last MAIN;
        }
    }
    ($sec,$min,$hour,$mday,$mon,$year,$wday, $yday,$isdst) = localtime(time);
    $endTime = sprintf "%4d-%02d-%02d %02d:%02d:%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec;
    
    &Genband::Utils::executeSqlCmd("update sched_job_queue set job_Status = \"Completed Execution\", automationLog= \'$log_dir/RegRun.log\' where JobId = \'$regJobID\'");
    
    foreach my $key (keys %indivisual) {
        next if (defined $failedProvision{$key});
        map {not defined $indivisual{$key}{$_} and $indivisual{$key}{$_} = 'PASS' } @{$testsToExecute{$key}};
       
        map { $indivisual{$key}{$_} = 'ERROR' } @{$testsToExecute{$key}} if (defined $failedRun{$key} );
        
        $content = $jobContent . "<td>$startTime</td><td>$endTime</td></tr></table>" . '<br/><br/><table border="1" align="center"><tr>';
        $content .= '<th>Test Case</th><th>Result</th><th>Reason</th></tr>';
        
        my $failed = 0;
        foreach my $t (keys %{$indivisual{$key}}) {
            $content .= '<tr><td>'. $t . '</td><td>' . $indivisual{$key}{$t} . '</td><td>' . (defined $reason{$key}{$t} ? $reason{$key}{$t} : '') . '</td></tr>';
            next if ($t =~ /(provision|xit)/);
            push (@testPass, $t) if ( $indivisual{$key}{$t} eq 'PASS' );
            if ( $indivisual{$key}{$t} eq 'FAIL' ) {
                push (@testFail, $t);
                $failed = 1;
            }
            if ( $indivisual{$key}{$t} eq 'ERROR' ) {
                push (@testErr, $t);
                $failed = 1;
            }
            if ( $indivisual{$key}{$t} eq 'UNTESTED' ) {
                push (@testUnTested, $t);
                $failed = 1;
            }
            $summary{$key}{$indivisual{$key}{$t}}++;
        }
        
        $content .= "</table>";
        
        if ($notifyIfFailed) {
            &sendMail(-mailId => $mail, -status => $key, -externalBody => $content, -nxtestLog => "$logDir/$path", -ip =>  $gen->{OBJ_HOST} )  if ($failed);
        } else {
            &sendMail(-mailId => $mail, -status => $key, -externalBody => $content, -nxtestLog => "$logDir/$path", -ip =>  $gen->{OBJ_HOST} );
        }
        
        next if ($key =~ /provision$/);
        
        &Genband::Utils::executeSqlCmd("insert into regressionsuiteresult value ('$regJobID', '" . $suiteIds{$key} . "',". ($summary{$key}{'FAIL'} || 0) . "," .  ($summary{$key}{'PASS'} || 0) . "," .  ($summary{$key}{'ERROR'} || 0) . "," .  ($summary{$key}{'UNTESTED'} || 0) . ", '" . join(',', @testFail) . "','" . join(',', @testPass) . "','" . join(',', @testErr) . "','" . join(',', @testUnTested) . "','$startTime','$endTime')");
    }
    
    
    my ($tpass, $tfail, $terror, $tuntested) = (0,0,0,0);
    $content = $jobContent . "<td>$sTime</td><td>$endTime</td></tr></table>" . '<br/><br/><table border="1" align="center"><tr><th>Feature</th><th># Tests Pass</th><th># Tests Fail</th><th># Tests Error</th><th># Tests UnTested</th></tr>';
    foreach (keys %summary) {
        $content .= '<tr><td>'. $_ . '</td><td>' . ($summary{$_}{'PASS'} || 0) . '</td><td>' . ($summary{$_}{'FAIL'}||0) . '</td><td>' . ($summary{$_}{'ERROR'}||0) . '</td><td>' . ($summary{$_}{'UNTESTED'}||0) . '</td></tr>';
        $tpass += $summary{$_}{'PASS'};
        $tfail += $summary{$_}{'FAIL'};
        $terror += $summary{$_}{'ERROR'};
        $tuntested += $summary{$_}{'UNTESTED'};
    }

    
    $content .= "<tr><td></td><td>$tpass</td><td>$tfail</td><td>$terror</td><td>$tuntested</td></table>";
    
    &sendMail(-mailId => $mail, -status => 'Completed', -externalBody => $content, -nxtestLog => "$logDir" );
    
    &Genband::Utils::executeSqlCmd("update regressionjobresult set totaltestsnotpass =   ". ($tfail+$terror+$tuntested) . ", totaltestspass = $tpass, EndTime = '$endTime' where regressionjob_uuid= '$regJobID'");
    
    unless ($gen->{conn}->cmd(String => 'exit', Prompt => '/.*[\$%#\}\>] $/')) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  failed to switch back to root user");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($gen->execLinuxCmd("cd $logDir")) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Failed to get into  $logDir");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }
    
    unless ($gen->execLinuxCmd("tar --ignore-failed-read -cvzf logs.tar.gz .", 600)) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> Failed to tar nextest logs");
        #$reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        #return 0;
    }
    
    $scpCmd = "scp -r logs.tar.gz root\@172.16.26.92:$baseLogDir/testlogs/";
    unless ($gen->scpFile( -scpCmd => $scpCmd,  -password => 'By2GYH', -timeout => 600)) {
        $reg_execution_logger->error("Reg::runRegression:: - ERROR -> failed to execute \"$scpCmd\"");
        $reg_execution_logger->debug("Reg::runRegression:: <-- Leaving sub [0]");
        return 0;
    }
    
    unless ($gen->execLinuxCmd("rm -f logs.tar.gz")) {
         $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR -> failed to drop tar file");
         $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
         return 0;
    }
    
    system ( "tar xvzf $baseLogDir/testlogs/logs.tar.gz -C $baseLogDir/testlogs/" ); 
    system ( "chmod -R +r $baseLogDir/testlogs");
    system ( "rm $baseLogDir/testlogs/logs.tar.gz" );
    
    system ( "cd $baseLogDir/testlogs/;find -name \"*result.txt\" |sort  | xargs grep -Ph \".*(provision|xit).*: .*\" | sort -u >provision_xit.txt" );
    
    if ($executionFailed) {
        $reg_execution_logger->debug("Reg::runRegression::$sub_name ----> leaving sub [0]");
        return 0;
    }
    $reg_execution_logger->debug("Reg::runRegression::$sub_name ----> leaving sub [1]");
    return 1;
}# END sub runQmtest

sub sendMail {
    my %args = @_;
    my $sub_name = 'sendMail()';
    $reg_execution_logger->debug("Reg::runRegression::$sub_name entring sub [0]");

    my $data = "Hi,<br/></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Thanks for using genSmart<br/></br>";
    
    $data .= $args{-externalBody} if (defined $args{-externalBody});
    
    if (defined $args{-nxtestLog}) {
        $args{-nxtestLog} =~ s/\/(xit|provision)$/\//;
        $data .= "<br/></br>Detailed logs are available at - $args{-ip}:$args{-nxtestLog}<br/></br>";
    }
    
    $data .= "<br/></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: This is an auto generated mail from genSMART(Genband Scheduler Manager for Automated Regression Testing). Please do not reply. For queries contact Ramesh.Pateel\@genband.com or Karthikeyan.Ramu\@genband.com";
    
    my $mail = MIME::Entity->build(
                Type    => "text/html charset=\"iso-8859-1\"",
                To      => "$args{-mailId}",
                #Cc      => 'ramesh.pateel@genband.com;karthikeyan.ramu@genband.com',
                From    => 'gensmart@genband.com',
                Subject => (defined $args{-impMsg} ? $args{-impMsg} : '') . "Regression execution - $args{-status}",
                Data    => $data,
    );

    open MAIL, "| /usr/sbin/sendmail -t -i" or die "open: $!";
    $mail->print(\*MAIL);
    close MAIL;
    $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: <-- Leaving sub [1]");
    return 1;
}

# regular checkup of dut
sub healthCheck {
    my $sub_name = 'healthCheck()';
    $reg_execution_logger->debug("Reg::runRegression::$sub_name entring sub");
    
    #unless ($dut->verifySigPorts()) {
    #    $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  signaling port are not running");
    #    $reg_execution_logger->debug("Reg::sbcPerf::$sub_name <-- Leaving sub [0]");
    #    return (0, ' signaling port are not running');
    #}

    ##Verify hk cards
    unless ($testBedData->[0]->[4] eq 'D-SBC') {
        unless ($dut->verifyHkports( -minCardUp => 1)) {
            $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  HK port are not running");
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return (0,'HK port are not running');
        }
    }
    
    #Verify iserver process
    unless ($dut->verifyiServerStatus()) {
        $reg_execution_logger->error("Reg::runRegression::$sub_name - ERROR ->  iserver prcoesses  are not running");
        $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
        return (0, 'iserver prcoesses  are not running');
    }
    
    if (defined $dut->{STANDBY}) {
        unless ($dut->checkScmStatus()) {
            $reg_execution_logger->debug("Reg::runRegression::$sub_name <-- Leaving sub [0]");
            return (0, 'scm status check fails, one of the Resource is not up');
        }
    }
    $reg_execution_logger->debug(__PACKAGE__ . ".$sub_name: <-- Leaving sub [1]");
    return (1, '');
}

#print Dumper $spaceComponent;
sub usage{
    print "\n USAGE: ./runRegression.pl -id jobId\n";
    exit(0);
}

sub handleControlC {
    print "\nOh my God, you killed Kenny\n\n";
    exit;
}

sub testFailed {
    my ($status, $msg) = shift;
    my $sub_name = 'testFailed()';
    $reg_execution_logger->info("Reg::AutomationReg::$sub_name --> Entered sub");

    #&sendMail(-mailId => $mail, -webUrl => '', -status => 'Failed', externalBody => $msg, -testName => $testName, -testId => $testId);
    $reg_execution_logger->debug("Reg::AutomationReg::$sub_name <-- Leaving sub [1]");
}

1;
