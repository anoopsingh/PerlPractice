#!/gats/bin/perl
#############################################################
#
# Genband US LLC,
#
# All Rights Reserved.
# Confidential and Proprietary.
#
# Module Name:  regSummary.pl
#
# Module Description:
# This script generates load Summary excel file
# 
# Author: Ramesh Pateel
#
#############################################################

use strict;
use Spreadsheet::WriteExcel;
use MIME::Entity;
use Genband::Utils;
use Data::Dumper;

my ($id, $email) = ($ARGV[0], $ARGV[1]);
chomp $id;
chomp $email;

$id =~ s/,/','/g;

my $dbh=Genband::Utils::db_connect('DATABASE') or die "failed make database connection";

my $logPaths = $dbh->selectall_arrayref( "select r.regressionjob_logpath, t.testbedtopology_name, r.regressionjob_type from regressionjob r join regressionjobresult rr on (r.regressionjob_uuid = rr.regressionjob_uuid) join testbedtopology t on (r.regressionjob_testbedtopologyuuid = t.testbedtopology_uuid) where r.regressionjob_uuid in ('$id') order by rr.StartTime",{ Slice => {} });

my %content = ();
my %tbDetails = ();
my %statusCode = ( 'PASS' => 0, 'FAIL' => 1, 'ERROR' => 2, 'UNTESTED' => 3);
my $ct = 0;


foreach my $logPath ( @{$logPaths}) {
    open (my $resultFH , '<', '/srv/www/vhosts/gensmart' . $logPath->{regressionjob_logpath} . 'testlogs/provision_xit.txt');
    foreach my $line (<$resultFH>) {
        chomp $line;
        next if ($line =~ /^\s+$/);
        next unless ($line =~ /:/);
        my @temp = split(/:/, $line);
        my ($suite, $status) = ($temp[0], $temp[1]);        
        $suite =~ s/\s+//g;
        if ($logPath->{regressionjob_type} =~ /DSP/) {
            $suite =~ s/(\w+\.)+?/$1\_/;
            $suite =~ s/\.\_/\_/;
            $suite =~ s/(smoke|production_components)_provision/provision/;
        } else {
            $suite =~ s/(\w+\.)+?//;
        }
        $status =~ s/\s+//g;
        next unless ($suite =~ /(provision|xit)$/);
        my $p = ($suite =~ /provision$/) ? 1 : 0;
        $suite =~ s/\.(provision|xit)$//;

        next if ($suite =~ /^provision$/);
        
        my $feature = $suite;
        if ($logPath->{regressionjob_type} =~ /DSP/) {
            $feature =~ s/([^\.]+?\_dsp\.[^\.]+?)\..*/$1/;
        } else {
            $feature =~ s/([^\.]+?)\..*/$1/;
        }
        
        next unless( defined $statusCode{$status});
        
        if (defined $tbDetails{$feature}) {
            push(@{$tbDetails{$feature}}, $logPath->{testbedtopology_name}) unless ( $logPath->{testbedtopology_name} eq $tbDetails{$feature}->[-1]);
        } else {
            push(@{$tbDetails{$feature}}, $logPath->{testbedtopology_name});
        }
        
        if ($p) {
            push(@{$content{$suite}->{provision}}, $statusCode{$status});
        } else {
            push(@{$content{$suite}->{xit}}, $statusCode{$status});
        }
        $ct++;
    }
}

push(@{$content{provision}->{provision}},0);

my $query = "select s.regressionsuite_name, r.totaltestsfail, r.totaltestspass, r.totaltestserror, r.totaltestsuntested, r.failedtests, r.passedtests, r.errortests, r.untestedtests, r.StartTime, r.suite_uuid from regressionsuiteresult r join regressionsuite s on (r.suite_uuid = s.regressionsuite_uuid) where r.regressionjob_uuid in ('$id') order by s.regressionsuite_name, r.StartTime";

my $sth = $dbh->prepare($query);

$sth->execute() or die "failed execute $query";

my $timestamp = time;
my $workbook = Spreadsheet::WriteExcel->new("/tmp/summary_consolidated-${timestamp}.xls");

my %formats =(); 
$formats{header} = $workbook->add_format(bold => 1, bg_color => 50,  border  => 1, align => 'center', valign  => 'vcenter');
$formats{header}->set_text_wrap(1);
$formats{total} = $workbook->add_format(bold => 1, bg_color => 'yellow', border  => 1, align => 'center', valign  => 'vcenter');

$formats{FAIL} = $workbook->add_format( bg_color => 'red', );
$formats{ERROR} = $workbook->add_format( bg_color => 27);
$formats{UNTESTED} = $workbook->add_format( bg_color => 'gray');
$formats{PASS} = $workbook->add_format( bg_color => 'green');
$formats{normal} = $workbook->add_format(align   => 'left');
$formats{suite} = $workbook->add_format(bold => 1, valign  => 'vcenter');
$formats{suite1} = $workbook->add_format(bold => 1, valign  => 'vcenter');

my $summary = $workbook->add_worksheet('Summary');
$summary->set_row(0,30);
$summary->set_column("A:A", 50);
$summary->set_column("B:G", 20);
$summary->write_row('A1', ['Suite Name', 'Total Tests', 'Total Pass', 'Total Fail', 'Total Error','Total UnTested'],  $formats{header});
$summary->freeze_panes(1,0);

my $suiteDetail = $workbook->add_worksheet('Details');
$suiteDetail->set_row(0,30);
$suiteDetail->set_column("A:B", 50);
$suiteDetail->set_column("C:E", 20);
#$suiteDetail->write(0,0, 'Suite Name',  $formats{header});
#$suiteDetail->write(0,1, 'Test Case',  $formats{header});
#$suiteDetail->write(0,2, 'Result',  $formats{header});
$suiteDetail->write_row('A1', ['Suite Name', 'Test Case', 'Result', 'Topology'],  $formats{header});

my $suiteTest = $dbh->selectall_hashref( "select * from regressiontests",'regressiontests_suiteuuid');

while (my $data = $sth->fetchrow_hashref) {
    my $suite = $data->{regressionsuite_name};
    
    my @actualTests = split(',',$suiteTest->{$data->{suite_uuid}}->{regressiontests_testcases});
    
    if ($data->{totaltestspass} > 0) {
        foreach my $tc (split(',',$data->{passedtests})) {
            push(@{$content{$suite}->{$tc}}, 0) if (grep(/^$tc$/, @actualTests));
        }
    }
    if ($data->{totaltestsfail} > 0) {
        foreach my $tc (split(',',$data->{failedtests})) {
            push(@{$content{$suite}->{$tc}}, 1) if (grep(/^$tc$/, @actualTests));
        }
    }
    if ($data->{totaltestserror} > 0) {
        foreach my $tc (split(',',$data->{errortests})) {
            push(@{$content{$suite}->{$tc}}, 2) if (grep(/^$tc$/, @actualTests));
        }
    }
    if ($data->{totaltestsuntested} > 0) {
        foreach my $tc (split(',',$data->{untestedtests})) {
            push(@{$content{$suite}->{$tc}}, 3) if (grep(/^$tc$/, @actualTests));
        }
    }
}

my (%total, %gtotal) = ((), ());
my %map = (0 => 'PASS', 1 => 'FAIL', 2 =>'ERROR', 3 => 'UNTESTED');

my $row = 1;
my %rowMap = ();
my %cols = ();
my $colCount = 2;
foreach my $suiteName (sort {$a cmp $b} keys %content) {
    my $suite = $suiteName;
    
    if ($suite =~ /^[^\.]+?\_dsp\./) {
        $suite =~ s/([^\.]+?\_dsp\.[^\.]+?)\..*/$1/;
    } else {
        $suite =~ s/(.+?)\..*/$1/;
    }
    
    my $orgRow = $row;
    my %rerun = ();
    foreach my $tc (sort {$a cmp $b} keys %{$content{$suiteName}}) {
        $total{$suite}{TOTAL}++;
        $total{$suite}{$map{$content{$suiteName}->{$tc}->[-1]}}++;
        $rowMap{$suiteName}{$tc} = $row;        
        my $index = 0;
        foreach (@{$content{$suiteName}->{$tc}}) {
            if ($index > 0 ) {
                unless (defined $cols{$index}) {
                    $cols{$index} = 2 * $index + 2;
                    $suiteDetail->write(0,$cols{$index}, "Rerun ($index)", $formats{header});
                    $colCount = $cols{$index};
                    $suiteDetail->write(0,($cols{$index} + 1), "Topology", $formats{header});                    
                }
                $suiteDetail->write($rowMap{$suiteName}{$tc}, $cols{$index},$map{$_}, $formats{$map{$_}});
                $rerun{$index} = 1;
            } else {
                $suiteDetail->write($row, 1,$tc, $formats{normal});
                $suiteDetail->write($row++, 2,$map{$_}, $formats{$map{$_}});                
            }            
            $index++;
        }        
    }    
    if ($orgRow == ($row - 1)) {
        $suiteDetail->write($orgRow,0, $suiteName, $formats{suite1});
        $suiteDetail->write($orgRow,3, $tbDetails{$suite}->[0], $formats{suite1}) if (defined $tbDetails{$suite}->[0]);
    } else {
        $suiteDetail->merge_range($orgRow,0,($row - 1), 0, $suiteName, $formats{suite});
        $suiteDetail->merge_range($orgRow,3,($row - 1), 3, $tbDetails{$suite}->[0], $formats{suite}) if (defined $tbDetails{$suite}->[0]);
    }
    
    foreach my $k (keys %rerun) {
        my $tb =  defined $tbDetails{$suite}->[$k] ? $tbDetails{$suite}->[$k] : $tbDetails{$suite}->[0];
        if ($orgRow == ($row - 1)) {
            $suiteDetail->write($orgRow, ($cols{$k} + 1), $tb, $formats{suite1});
        } else {
            $suiteDetail->merge_range($orgRow,($cols{$k} + 1),($row - 1), ($cols{$k} + 1), $tb, $formats{suite});
        }
    }
}
$suiteDetail->freeze_panes(1,0);
$suiteDetail->autofilter(0, 0, ($row-1), ($colCount + 1));

$row = 2;
foreach my $suite (sort keys %total) {
    $summary->write_row('A' . $row++, [$suite, ($total{$suite}{TOTAL} || 0 ), ($total{$suite}{PASS} || 0 ), ($total{$suite}{FAIL} || 0), ($total{$suite}{ERROR} || 0), ( $total{$suite}{UNTESTED} || 0)]);
    $gtotal{total} += $total{$suite}{TOTAL};
    $gtotal{pass} += $total{$suite}{PASS};
    $gtotal{fail} += $total{$suite}{FAIL};
    $gtotal{error} += $total{$suite}{ERROR};
    $gtotal{untested} += $total{$suite}{UNTESTED};
}

$summary->write_row('A' . ($row+2), ['Total', $gtotal{total}, $gtotal{pass}, $gtotal{fail}, $gtotal{error}, $gtotal{untested}], $formats{total});

undef %total;
undef %gtotal;
undef %content;
undef %rowMap;
undef %cols;
$workbook->close();
&sendMail( -file => "/tmp/summary_consolidated-${timestamp}.xls", -mailId => $email);
system("rm -f /tmp/summary_consolidated-${timestamp}.xls");

sub sendMail {
    my %args = @_;
    my $sub_name = 'sendMail()';
 
    my $data = "Hi,<br/></br>&nbsp;&nbsp;&nbsp;Please find the attached summary report<br/></br>";
 
    $data .= "<br/></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: This is an auto generated mail from genSMART(Genband Scheduler Manager for Automated Regression Testing). Please do not reply. For queries contact Ramesh.Pateel\@genabnd.com (or) Anoop.Kumar\@globallogic.com";
 
    my $mail = MIME::Entity->build(
                Type    => "text/html charset=\"iso-8859-1\"",
                To      => "$args{-mailId}",
                Cc      => 'ramesh.pateel@genband.com',
                From    => 'gensmart@genband.com',
                Subject => "Regression execution Summary Report",
                Data    => $data,
    );
 
    $mail->attach( Path        => $args{-file}, Type        => "application/vnd.ms-excel" );
    open MAIL, "| /usr/sbin/sendmail -t -i" or die "open: $!";
    $mail->print(\*MAIL);
    close MAIL;
    return 1;
}

1;
