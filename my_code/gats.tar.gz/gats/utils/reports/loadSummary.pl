#!/gats/bin/perl
#############################################################
#
# Genband US LLC,
#
# All Rights Reserved.
# Confidential and Proprietary.
#
# Module Name:  loadSummary.pl
#
# Module Description:
# This script generates load Summary excel file
# 
# Author: Ramesh Pateel (Ram)
#
#############################################################

use strict;
use Spreadsheet::WriteExcel;
use MIME::Entity;
use Genband::Utils;
use Data::Dumper;
use Time::Local;
use Genband::PERF::PerfUtils;

my $id = $ARGV[0];
chomp $id;
my @platforms = ();

my ($jobData, $testData, $testBedData, $externalBody);

my $dbh=Genband::Utils::db_connect('DATABASE') or die "failed make database connection";

my $summaryData = $dbh->selectrow_arrayref("SELECT loadsummary_name, loadsummary_dut, loadsummary_releases, loadsummary_platforms, loadsummary_uuid, loadsummary_username FROM loadsummary where loadsummary_uuid = \'$id\'") or die "Failed to get summary records";

my $query = "select loadJob.loadJob_release, loadJob.loadJob_platform, loadtest.loadtest_testcaseid, loadtest.loadtest_name, loadtest.loadtest_description, loadJobResult.maxcps, loadJobResult.abndcall, loadJobResult.errcall, loadJobResult.maxcall, loadJobResult.maxcpu, loadJobResult.maxmemory, loadJobResult.avgcpu, loadJobResult.avggiscpu, loadJobResult.maxgismemory, loadJobResult.maxgiscpu from loadJob join loadtest on (loadJob.loadJob_testcaseuuid = loadtest.loadtest_uuid) join loadJobResult on (loadJob.loadJob_uuid = loadJobResult.loadJob_uuid) where loadJob.loadJob_publish = 1  ";

$summaryData->[3] =~ s/\s+//g;

my $dir = "/srv/www/vhosts/gensmart/reports/load/$summaryData->[1]/$summaryData->[5]";
my $url = "http://172.16.26.92/reports/load/$summaryData->[1]/$summaryData->[5]";
my $timestamp = time;

unless ( system ( "mkdir -p $dir/" ) == 0 ) {
    die "failed to create report directory";
}

if ($summaryData->[2] and $summaryData->[2] !~ /NULL/i ) {
    @platforms = ($summaryData->[3]);
    $query .= " and loadJob.loadJob_release = \'$summaryData->[2]\' ";
}

if ($summaryData->[3] and $summaryData->[3] !~ /NULL/i ) {
    @platforms = ($summaryData->[3]);
    $query .= " and loadJob.loadJob_platform = \'$summaryData->[3]\' ";
}

my $sth = $dbh->prepare($query . " order by loadJob_release ");

$sth->execute() or die "failed execute $query";

my $workbook = Spreadsheet::WriteExcel->new("$dir/summary-$timestamp.xls");

my %formats =(); 
$formats{header} = $workbook->add_format(bold => 1, bg_color => 'yellow',  border  => 1, align => 'center', valign  => 'vcenter');
$formats{header}->set_text_wrap(1);

$formats{subheader} = $workbook->add_format(bold => 1, bg_color => 'yellow', border  => 1, align => 'center', valign  => 'vcenter');
$formats{subheader}->set_text_wrap(1);

$formats{release} = $workbook->add_format(bold => 1, bg_color => 'green', border  => 1, align => 'center', valign  => 'vcenter');

$formats{normal} = $workbook->add_format(align   => 'center', valign  => 'vcenter', border  => 1);
$formats{normal}->set_text_wrap(1);

my (%row , %col, %worksheets, %unique);

my @header = ('Avg % gis CPU Usage', 'Max % gis Memory Utilized', 'Avg % System CPU Usage', 'Max % System Memory Utilized', 'Max % gis CPU Usage','Max % System CPU Usage', 'Mac CPS', 'Max call', 'Abandoned Calls', 'Err Calls');



while (my $data = $sth->fetchrow_hashref) {
    unless ($worksheets{$data->{loadJob_platform}}) {
        $worksheets{$data->{loadJob_platform}} = $workbook->add_worksheet($data->{loadJob_platform});
        $worksheets{$data->{loadJob_platform}}->set_row(0,30);
        $worksheets{$data->{loadJob_platform}}->set_row(1,50);
        $worksheets{$data->{loadJob_platform}}->set_column("A:A", 20);
        $worksheets{$data->{loadJob_platform}}->set_column("B:B", 50);
        $worksheets{$data->{loadJob_platform}}->write(1,0,"Test Case", $formats{subheader});
        $worksheets{$data->{loadJob_platform}}->write(1,1,"Test Description Summary", $formats{subheader});
        $col{$data->{loadJob_platform}}->{total} = 1;
        
        $row{$data->{loadJob_platform}} = 2;
        
    }
    
    unless (defined $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}) {
        $col{$data->{loadJob_platform}}->{$data->{loadJob_release}} = $col{$data->{loadJob_platform}}->{total} + 1;
        
        my $tempRel = $data->{loadJob_release};
        $tempRel =~ s/V//;
        $worksheets{$data->{loadJob_platform}}->merge_range(0,($col{$data->{loadJob_platform}}->{$data->{loadJob_release}} + 1 ),0, ( $col{$data->{loadJob_platform}}->{$data->{loadJob_release}} + 10), "\n$tempRel Data\n", $formats{release});
        
        map { $worksheets{$data->{loadJob_platform}}->write(1,($col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+ $_ + 1 ),$header[$_], $formats{subheader}) } 0..$#header;
        
        $col{$data->{loadJob_platform}}->{total} += 11;
    }
    
    next if (defined $unique{$data->{loadJob_platform}}->{$data->{loadJob_release}}->{$data->{loadtest_testcaseid}});
    
    $unique{$data->{loadJob_platform}}->{$data->{loadJob_release}}->{$data->{loadtest_testcaseid}} = 1;
    
    unless ( defined $unique{$data->{loadJob_platform}}->{$data->{loadtest_testcaseid}}) {
        $row{$data->{loadJob_platform}}++;
        $unique{$data->{loadJob_platform}}->{$data->{loadtest_testcaseid}} = 1;
        $worksheets{$data->{loadJob_platform}}->set_row($row{$data->{loadJob_platform}},60);
        $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, 0, "$data->{loadtest_testcaseid}:$data->{loadtest_name}", $formats{normal});
    
        $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, 1, $data->{loadtest_description}, $formats{normal});        
    }
    
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+1, $data->{avggiscpu}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+2, $data->{maxgismemory}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+3, $data->{avgcpu}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+4, $data->{maxmemory}, $formats{normal});
        
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+5, $data->{maxgiscpu}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+6, $data->{maxcpu}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+7, $data->{maxcps}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+8, $data->{maxcall}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+9, $data->{abndcall}, $formats{normal});
    
    $worksheets{$data->{loadJob_platform}}->write($row{$data->{loadJob_platform}}, $col{$data->{loadJob_platform}}->{$data->{loadJob_release}}+10, $data->{errcall}, $formats{normal});
    
}

$workbook->close();

&Genband::PERF::PerfUtils::executeSqlCmd("update loadsummary set reportpath = \'$url/summary-$timestamp.xls\' where loadsummary_uuid =\'$summaryData->[4]\' ");

1;

