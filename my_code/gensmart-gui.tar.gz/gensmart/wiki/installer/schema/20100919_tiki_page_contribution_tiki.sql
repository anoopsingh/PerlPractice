UPDATE `users_permissions` SET `permName`='tiki_p_page_contribution_view' WHERE `permName`='tiki_p_page-contribution_view';
UPDATE `users_grouppermissions` SET `permName`='tiki_p_page_contribution_view' WHERE `permName`='tiki_p_page-contribution_view';
UPDATE `users_objectpermissions` SET `permName`='tiki_p_page_contribution_view' WHERE `permName`='tiki_p_page-contribution_view';