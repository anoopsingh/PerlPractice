
#2008-09-05 bitey
ALTER TABLE tiki_feature ADD COLUMN `tip` text NULL;

