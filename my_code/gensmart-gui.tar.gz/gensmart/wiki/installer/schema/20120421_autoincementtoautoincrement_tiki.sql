UPDATE tiki_preferences set name = 'trackerfield_autoincrement' where name = 'trackerfield_autoincement';
