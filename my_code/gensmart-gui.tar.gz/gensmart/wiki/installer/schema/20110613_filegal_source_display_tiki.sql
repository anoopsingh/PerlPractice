ALTER TABLE tiki_file_galleries ADD COLUMN show_source CHAR(1) NOT NULL DEFAULT 'o';
