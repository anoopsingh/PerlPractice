ALTER IGNORE TABLE `tiki_language` MODIFY `tran` tinytext;
ALTER IGNORE TABLE `tiki_language` MODIFY `source` tinytext;
