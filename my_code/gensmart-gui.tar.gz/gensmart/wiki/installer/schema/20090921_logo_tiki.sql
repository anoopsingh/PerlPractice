update tiki_preferences set value='img/tiki/tikisitelogo.png' where value='img/tiki/tiki3.png';
