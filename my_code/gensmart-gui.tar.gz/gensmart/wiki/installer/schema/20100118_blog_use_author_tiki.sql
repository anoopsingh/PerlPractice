ALTER TABLE tiki_blogs ADD COLUMN `use_author` char(1) default NULL AFTER `use_title`;
