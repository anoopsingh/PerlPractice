DROP TABLE tiki_page_lists;
DROP TABLE tiki_page_list_types;
DELETE FROM `users_permissions` WHERE `permName` = 'tiki_p_upload_screencast';
