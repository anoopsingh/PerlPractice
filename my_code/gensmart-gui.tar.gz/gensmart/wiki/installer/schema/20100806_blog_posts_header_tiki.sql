# Jyhem
ALTER TABLE `tiki_blogs` ADD `post_heading` TEXT NULL AFTER `heading` ;

