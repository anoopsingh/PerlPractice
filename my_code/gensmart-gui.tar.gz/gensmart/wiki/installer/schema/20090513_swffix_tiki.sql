#sylvieg
update tiki_banners set HTMLData = replace(HTMLData, 'swffix', 'swfobject');