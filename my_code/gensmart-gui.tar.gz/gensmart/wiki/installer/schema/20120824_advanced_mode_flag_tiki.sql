ALTER TABLE `tiki_workspace_templates` ADD COLUMN `is_advanced` CHAR(1) NOT NULL DEFAULT 'n';
