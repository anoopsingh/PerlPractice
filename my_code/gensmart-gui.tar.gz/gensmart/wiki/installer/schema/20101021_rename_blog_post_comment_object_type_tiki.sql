UPDATE `tiki_comments` SET `objectType` = 'blog post' WHERE `objectType` = 'post';
