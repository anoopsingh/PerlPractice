ALTER TABLE `tiki_files` ADD `maxhits` INT( 14 ) NULL DEFAULT NULL AFTER `hits`;
