ALTER TABLE `tiki_file_galleries` ADD `show_deleteAfter` CHAR( 1 ) default NULL AFTER `show_backlinks`;
