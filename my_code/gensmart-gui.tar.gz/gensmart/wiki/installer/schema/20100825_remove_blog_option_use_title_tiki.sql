ALTER TABLE `tiki_blogs` DROP `use_title`;
