
#2008-11-05 rook1666
ALTER TABLE tiki_calendar_items ADD COLUMN allday tinyint(1) NOT NULL default '0';

