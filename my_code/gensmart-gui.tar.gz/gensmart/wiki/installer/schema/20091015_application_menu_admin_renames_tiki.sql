UPDATE `tiki_menu_options` SET `name`='External Feeds' WHERE menuId=42 AND name='RSS Modules';
UPDATE `tiki_menu_options` SET `name`='External Pages Cache' WHERE menuId=42 AND name='Wiki Cache';
