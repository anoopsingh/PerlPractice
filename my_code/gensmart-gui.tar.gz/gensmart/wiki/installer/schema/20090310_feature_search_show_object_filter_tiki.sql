#sylvieg
insert into `tiki_preferences` (name, value) values('feature_search_show_object_filter', 'y'); 
