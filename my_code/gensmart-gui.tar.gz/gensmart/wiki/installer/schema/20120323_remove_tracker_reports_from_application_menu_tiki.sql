DELETE FROM `tiki_menu_options` WHERE `menuId`='42' and `name`='Tracker Reports';
