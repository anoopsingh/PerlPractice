UPDATE `tiki_preferences` SET `name` = 'comments_notitle' WHERE `name` = 'wiki_comments_notitle';
