ALTER TABLE `tiki_rss_feeds` CHANGE  `name` `name` varchar(60) NOT NULL default '';
