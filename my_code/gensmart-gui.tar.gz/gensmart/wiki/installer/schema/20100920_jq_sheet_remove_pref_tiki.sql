DELETE FROM `tiki_preferences` WHERE `tiki_preferences`.`name` =  'feature_jquery_sheet';
