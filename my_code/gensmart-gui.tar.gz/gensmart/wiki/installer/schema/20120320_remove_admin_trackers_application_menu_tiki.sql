DELETE FROM `tiki_menu_options` WHERE `menuId`='42' and `name`='Admin Trackers' and `url`='tiki-admin_trackers.php';
