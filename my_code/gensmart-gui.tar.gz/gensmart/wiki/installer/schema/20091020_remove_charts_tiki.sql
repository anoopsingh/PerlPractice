DELETE FROM `tiki_sefurl_regex_out` WHERE `feature` = 'feature_charts';
