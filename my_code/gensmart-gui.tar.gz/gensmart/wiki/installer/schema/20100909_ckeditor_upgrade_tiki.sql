UPDATE `tiki_preferences` SET `value` =  'y' WHERE `tiki_preferences`.`name` =  'wysiwyg_ckeditor';
