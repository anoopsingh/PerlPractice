INSERT INTO users_permissions (`permName`, `permDesc`, level, type) VALUES ('tiki_p_trust_input', 'Trust all user inputs including plugins (no security checks)', 'admin', 'tiki');
