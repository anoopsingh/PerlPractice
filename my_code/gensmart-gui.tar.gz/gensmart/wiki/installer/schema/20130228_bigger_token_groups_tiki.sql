ALTER TABLE `tiki_auth_tokens` CHANGE `groups` `groups` TEXT NULL;
