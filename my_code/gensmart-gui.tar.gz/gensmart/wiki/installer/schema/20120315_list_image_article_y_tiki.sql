ALTER TABLE `tiki_articles` ADD COLUMN `list_image_y` int(4) default NULL AFTER `list_image_x`;
