DELETE FROM `users_permissions` WHERE `feature_check` = 'feature_workflow';
