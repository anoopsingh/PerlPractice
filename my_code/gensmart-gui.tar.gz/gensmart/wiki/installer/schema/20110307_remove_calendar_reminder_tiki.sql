DROP TABLE IF EXISTS `custom_calendar_reminder`;
