alter table `tiki_file_handlers` modify `mime_type` varchar(128) default NULL;
