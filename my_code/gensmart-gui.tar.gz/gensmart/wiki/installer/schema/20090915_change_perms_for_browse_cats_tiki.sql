UPDATE `tiki_menu_options` SET `perm` = 'tiki_p_view_category' WHERE `perm` = 'tiki_p_view_categories';
