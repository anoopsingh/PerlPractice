DROP TABLE IF EXISTS `tiki_languages`;
