UPDATE `tiki_blog_posts` SET `priv` = 'n' WHERE `priv` IS NULL;
