UPDATE `tiki_modules` SET `name` = 'search',`params` = 'legacy_mode=search' WHERE `name` = 'search_box';
