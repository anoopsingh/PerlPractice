ALTER TABLE `tiki_user_assigned_modules` ADD KEY `id` ( `moduleId` );
