AlTER TABLE `tiki_files` ADD COLUMN `deleteAfter` int(14) default NULL;
