ALTER TABLE `tiki_blogs` ADD COLUMN `show_related` char(1) DEFAULT NULL;
