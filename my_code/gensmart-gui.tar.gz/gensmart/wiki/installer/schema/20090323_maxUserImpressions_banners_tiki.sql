#sylvieg
alter table `tiki_banners` add column `maxUserImpressions` int(8) default -1 after `impressions`;