ALTER TABLE `tiki_rss_modules` ADD `actions` TEXT;
