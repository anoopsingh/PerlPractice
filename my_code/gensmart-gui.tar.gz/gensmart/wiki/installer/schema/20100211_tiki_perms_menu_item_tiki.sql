INSERT INTO `tiki_menu_options` (`menuId`,`type`,`name`,       `url`,                       `position`,`perm`)
                         VALUES ('42',    'o',   'Permissions','tiki-objectpermissions.php','1077',    'tiki_p_admin|tiki_p_admin_objects');
